package com.semaconnect;

import android.text.InputFilter;
import android.text.TextWatcher;

interface Validator extends TextWatcher, InputFilter {
    String getValue();

    boolean isValid();

    boolean hasFullLength();
}
