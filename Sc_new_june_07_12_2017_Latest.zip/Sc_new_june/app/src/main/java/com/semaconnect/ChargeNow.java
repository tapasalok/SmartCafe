package com.semaconnect;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.text.method.KeyListener;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.semaconnect.utility.Config;
import com.semaconnect.utility.RestClient;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by anisha on 22/3/17.
 */

public class ChargeNow extends Activity {
    public EditText serialno;
    private String mURL = "";
    private String searchTxt = "";
    private String checkType = "";
    private Button selectStation;
    private String serialNumber;
    private String serialNo;
    private String stationName, location_name, address,pricing_summary,station_id;
    String chargStation;
    private String mStationId = "";
    private String mResponse = "";
    private double lat;
    private double lon;
    private String status;
    private int id;
    private SharedPreferences settings;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chargenow);

        settings = getSharedPreferences("session_auth", 0);
        editor = settings.edit();
        editor.putBoolean("chargeNowClick", false);
        editor.putBoolean("chargeNowSelectStation", false);
        editor.putBoolean("chargeNow", false);
        editor.putBoolean("donotshowMA", false);
        editor.commit();



        TextView titleTxt = (TextView) findViewById(R.id.top_title_txt);
        serialno = (EditText)findViewById(R.id.serialno_search);
        serialNumber = serialno.getText().toString();

        serialno.setInputType(InputType.TYPE_CLASS_NUMBER);
        KeyListener keyListener = DigitsKeyListener.getInstance("1234567890");
        serialno.setKeyListener(keyListener);
        serialno.setSelected(false);
        serialno.setText("BAE");
        serialno.requestFocus();
//        serialno.requestFocus();
        serialno.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager keyboard = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);
                keyboard.showSoftInput(serialno, 0);
            }
        },200);

        Selection.setSelection(serialno.getText(), serialno.getText().length());

        serialno.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().contains("BAE")){
                    serialno.setText("BAE");

                    Selection.setSelection(serialno.getText(), serialno.getText().length());

                }

            }
        });

        Bundle args = getIntent().getExtras();
        titleTxt.setText("Charge Now");
        selectStation = (Button)findViewById(R.id.select_station);
        selectStation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isUserLoggedIn()) {
                    new GetSerialNumberDetails().execute();
                }else {
                    AlertDialog.Builder alert = new AlertDialog.Builder(getParent());

                    alert.setTitle("Charge Now");
                    alert.setIcon(R.drawable.ic_launcher);
                    alert.setMessage("" +
                            "Please login to start charging.");
                    alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            editor = settings.edit();
                            editor.putBoolean("showLogin", false);
                            editor.putBoolean("chargeNowSelectStation", true);
                            editor.putBoolean("donotshowMA", true);
                            editor.commit();
                            Intent intent = new Intent(ChargeNow.this, StackHome.class);
                            startActivity(intent);
                        }
                    });
                    alert.show();
                }
            }
        });


    }

    private boolean isUserLoggedIn() {
        boolean loggedIn;
        settings = getSharedPreferences("session_auth", 0);
        final String user = settings.getString("username", "");
        final String password = settings.getString("password", "");
        if (!TextUtils.isEmpty(user) && !TextUtils.isEmpty(password) && user.length() > 0 && password.length() > 0) {
            loggedIn = true;
        } else {
            loggedIn = false;
        }
        return loggedIn;
    }

    class GetSerialNumberDetails extends AsyncTask<Void, Void, Void> {
        int mResponse_code;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Config.ViewShow();
            serialNumber = serialno.getText().toString();
            serialno.setEnabled(false);
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {

                String url = Config.BASE_URL +  "stations/" + "serial_number/" + serialNumber + "?key=" + Config.KEY;

                RestClient client = new RestClient(url);
                client.AddHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                client.Execute(RestClient.RequestMethod.GET);
                String response = client.getResponse();
                HttpResponse httpResponse = null;
                HttpGet httpost = new HttpGet(url);
                if (Config.client != null) {
                    httpResponse = Config.client.execute(httpost);
                } else {
                    httpResponse = Config.getThreadSafeClient()
                            .execute(httpost);
                }

                mResponse_code = httpResponse.getStatusLine().getStatusCode();
                if (response != null) {
                    JSONObject json = new JSONObject(response);

                    stationName = json.optString("name");
                    station_id = json.optString("id");
                    serialNo = json.optString("serial_number");

                    JSONArray jCords = json.optJSONArray("coordinates");

                    lat = Double.parseDouble(jCords.optString(0));
                    lon = Double.parseDouble(jCords.optString(1));

                    JSONObject json1 = json.optJSONObject("location");
                    location_name = json1.optString("name");
                    address = json1.optString("address1");

                    JSONObject json2 = json.optJSONObject("pricing");
                    pricing_summary = json2.optString("summary");
                    status = json.optString("status");
                    id = json.optInt("id");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Config.ViewDismiss();
            if(mResponse_code == 200){

                if (serialNumber.length() > 3) {

                    Intent mIntent = new Intent(getParent(),SelectedStationDetails.class);

                    mIntent.putExtra("serial_number", serialNumber);
                    mIntent.putExtra("name", stationName);
                    mIntent.putExtra("location_name", location_name);
                    mIntent.putExtra("address", address);
                    mIntent.putExtra("pricing_summary", pricing_summary);
                    mIntent.putExtra("station_id", station_id);
                    mIntent.putExtra("lat", lat);
                    mIntent.putExtra("lon", lon);
                    mIntent.putExtra("status", status);
                    mIntent.putExtra("id", id);

                    mIntent.putExtra("title", "Selected Station Details");
                    TabGroupActivity parentActivity = (TabGroupActivity) getParent();
                    parentActivity.startChildActivity("selected_station_details", mIntent);

                } else {

                    Toast.makeText(ChargeNow.this, "Please enter a valid station serial number.", Toast.LENGTH_SHORT).show();
                }

            }else if(mResponse_code == 404) {

                AlertDialog.Builder dialog1 = new AlertDialog.Builder(getParent());
                dialog1.setMessage("Enter a valid station serial number.");
                dialog1.setTitle("Invalid serial number!");
                dialog1.setIcon(R.drawable.ic_launcher);
                dialog1.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog1,
                                                int which) {

                                dialog1.dismiss();


                            }
                        });
                dialog1.show();
                serialno.setEnabled(true);
                serialno.setFocusable(true);
            }else if(mResponse_code == 406) {

                AlertDialog.Builder dialog1 = new AlertDialog.Builder(getParent());
                dialog1.setMessage("Only for members.");
                dialog1.setTitle("Private Station");
                dialog1.setIcon(R.drawable.ic_launcher);
                dialog1.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog1,
                                                int which) {

                                dialog1.dismiss();


                            }
                        });
                dialog1.show();
                serialno.setEnabled(true);
                serialno.setFocusable(true);
            }else {

                serialno.setEnabled(true);
                serialno.setFocusable(true);
            }

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getParent(),MapScreen.class);
        i.putExtra("title", "Map Screen");
        TabGroupActivity parentActivity = (TabGroupActivity) TabGroupActivity.sGroup;
        parentActivity.startChildActivity("map_screen", i);

    }
}
