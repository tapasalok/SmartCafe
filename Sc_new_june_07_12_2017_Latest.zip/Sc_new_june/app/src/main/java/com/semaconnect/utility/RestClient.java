package com.semaconnect.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import android.util.Base64;
import android.util.Log;

public class RestClient {
	public static enum RequestMethod {
		GET, POST ;
	}

	private ArrayList<NameValuePair> params;
	private ArrayList<NameValuePair> headers;

	private String url;

	private int responseCode;
	private String message;

	private String response;

	public String getResponse() {
		return response;
	}

	public String getErrorMessage() {
		return message;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public RestClient(String url) {
		this.url = url;// +Config.addSid+Config.sid+"/agent:"+Config.device;
		params = new ArrayList<NameValuePair>();
		headers = new ArrayList<NameValuePair>();
	}

	public void AddParam(String name, String value) {
		params.add(new BasicNameValuePair(name, value));
	}

	public void AddHeader(String name, String value) {
		headers.add(new BasicNameValuePair(name, value));
	}

	public void Execute(RequestMethod method) throws Exception {
		switch (method) {
		case GET: {
			// add parameters
			String combinedParams = "";
			if (!params.isEmpty()) {
				combinedParams += "/";
				for (NameValuePair p : params) {
					// String paramString =
					// URLEncoder.encode(p.getValue(),"ISO-8859-1");
					Log.i("paramstring", p.getValue().replace(" ", "%20"));
					if (combinedParams.length() > 1) {
						combinedParams += "/"
								+ p.getValue().replace(" ", "%20");
					} else {
						combinedParams += p.getValue().replace(" ", "%20");
					}
				}
			}

			HttpGet request = new HttpGet(url + combinedParams);
			/*request.setHeader(
					"Authorization",
					"Basic "
							+ Base64.encodeToString(parameter.getBytes(),
									Base64.NO_WRAP));*/
			Log.v("GET URL", "" + url);
			Log.v("params", "" + combinedParams);

			// add headers
			for (NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			executeRequest(request, url);
			break;
		}
		case POST: {
			Log.v("POST", "post method ...");
			HttpPost request = new HttpPost(url);

			// add headers
			for (NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			Log.v("POST", "Params ::: " + params);
			if (!params.isEmpty()) {
				ArrayList<String> parameters = new ArrayList<String>();
				for (NameValuePair p : params) {
					parameters.add(p.getValue());
				}
				request.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
			}

			executeRequest(request, url);
			break;

		}
		}
	}

	static public String postHTPPRequest(String URL, String parameter) {

		HttpPost httppost = new HttpPost(URL);
		httppost.setHeader(
				"Authorization",
				"Basic "
						+ Base64.encodeToString(parameter.getBytes(),
								Base64.NO_WRAP));

		Log.v("check login", ">>" + URL + "**" + parameter);
		Log.v("anisha", ">>" + URL + "**" + parameter);

		try {
			
			HttpResponse httpResponse = null;

			if (Config.client != null) {
				httpResponse = Config.client.execute(httppost);
			} else {
				httpResponse = Config.getThreadSafeClient().execute(httppost);
			}

			int code = httpResponse.getStatusLine().getStatusCode();
			// httpResponse.
			Config.mStatusCode = code;
			Log.v("", "hello===========" + code);
			/*
			 * if(code == 200) {
			 */
			HttpEntity entity = httpResponse.getEntity();
			if (entity != null) {
				// byte[] Data = new byte[256];
				// int len = 0;
				InputStream input = null;
				input = entity.getContent();
				String res = convertStreamToString(input);

				input.close();

				return res;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	
	static public String getHTPPRequest(String URL, String parameter) {
		
		HttpGet req = new HttpGet(URL);
		req.setHeader("Content-type", "application/json");
		req.setHeader(
				"Authorization",
				"Basic "
						+ Base64.encodeToString(parameter.getBytes(),
								Base64.NO_WRAP));

		try {
			
			HttpResponse httpResponse = null;

			if (Config.client != null) {
				httpResponse = Config.client.execute(req);
			} else {
				httpResponse = Config.getThreadSafeClient().execute(req);
			}

			int code = httpResponse.getStatusLine().getStatusCode();
			Config.mStatusCode = code;
			Log.v("", "hello===========" + code);
			
			HttpEntity entity = httpResponse.getEntity();
			if (entity != null) {
				InputStream input = null;
				input = entity.getContent();
				String res = convertStreamToString(input);

				input.close();
				return res;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	private void executeRequest(HttpUriRequest request, String url) {

		Log.v("***URL***", "" + url);

		HttpResponse httpResponse;

		try {
			if (Config.client != null) {
				httpResponse = Config.client.execute(request);
			} else {
				httpResponse = Config.getThreadSafeClient().execute(request);
			}

			responseCode = httpResponse.getStatusLine().getStatusCode();
			message = httpResponse.getStatusLine().getReasonPhrase();

			HttpEntity entity = httpResponse.getEntity();

			if (entity != null) {

				InputStream instream = entity.getContent();
				response = convertStreamToString(instream);
				Log.i("REQ__Response ", response);
				// Closing the input stream will trigger connection release
				instream.close();
			}

		} catch (ClientProtocolException e) {
			Config.client.getConnectionManager().shutdown();
			e.printStackTrace();
		} catch (IOException e) {
			Config.client.getConnectionManager().shutdown();
			e.printStackTrace();
		}
	}

	private static String convertStreamToString(InputStream is) {
		Log.i("Inside convertstream method", "hello");
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

}
