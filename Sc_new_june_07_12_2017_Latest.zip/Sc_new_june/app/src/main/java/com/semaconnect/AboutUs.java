package com.semaconnect;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class AboutUs extends Fragment{

	private ViewGroup view;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater.inflate(R.layout.about_us, container, false);
		view.setLayoutParams(new ViewGroup.LayoutParams
				(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		TextView titleTxt = (TextView) view.findViewById(R.id.top_title_txt);
		Bundle args = getArguments();
		titleTxt.setText(args.get("title").toString());
	}
}
