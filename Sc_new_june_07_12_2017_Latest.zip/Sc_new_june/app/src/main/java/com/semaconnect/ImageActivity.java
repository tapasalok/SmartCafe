package com.semaconnect;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.semaconnect.utility.Config;

public class ImageActivity extends Fragment {

	View view;
	ImageView gallery_image;
	ProgressBar gallery_progress;
	private String photo_id;
	ImageLoader imageLoader;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater.inflate(R.layout.photo_gal, container,
				false);
		view.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));

		gallery_image = (ImageView) view.findViewById(R.id.photo_gal_image);
		gallery_progress = (ProgressBar) view
				.findViewById(R.id.photo_gal_progressbar);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle bundle) {
		super.onActivityCreated(bundle);

		try{
			Bundle args = getArguments();
			photo_id = args.getString("photo_id");
		}catch(Exception e) {
			Bundle args = getActivity().getIntent().getExtras();
			photo_id = args.getString("photo_id");
		}
	
		imageLoader = new ImageLoader(getActivity());
		String url = Config.BASE_URL + "photos/" + photo_id + "?key="
				+ Config.KEY;
		Log.v("imageLoader ::: ", "" + url);
		imageLoader.DisplayImage(url, gallery_image, gallery_progress);
	}
}
