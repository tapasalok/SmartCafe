package com.semaconnect;

import android.os.Bundle;

public class StackReport extends ActivityInTab {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		navigateTo(new ReportProblem());
	}
	
	
}
