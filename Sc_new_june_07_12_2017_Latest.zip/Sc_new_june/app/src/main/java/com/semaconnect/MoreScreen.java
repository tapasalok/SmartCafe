package com.semaconnect;

import com.semaconnect.utility.Config;
import com.semaconnect.utility.GmailFrom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class MoreScreen extends Fragment {
	private static float currentRating = 5.0f;
	ViewGroup view;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater.inflate(R.layout.more, container, false);
		view.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();
		currentRating = 5.0f;
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				InputMethodManager inputManager = (InputMethodManager) getActivity()
						.getSystemService(Context.INPUT_METHOD_SERVICE);
				inputManager.hideSoftInputFromWindow(getView().getWindowToken(),
						InputMethodManager.HIDE_NOT_ALWAYS);
			}
		}, 300);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

			TextView title_text = (TextView) view.findViewById(R.id.top_title_txt);
		title_text.setText(getString(R.string.tab_more));

		Button aboutUsBtn = (Button) view
				.findViewById(R.id.more_aboutBtn);

		aboutUsBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {

				// Call About Us Page
				AboutUs f = new AboutUs();
				Bundle args = new Bundle();
				args.putString("title", "About Us");
				f.setArguments(args);
				((ActivityInTab) getActivity()).navigateTo(f);

			}
		});

		Button emailUsBtn = (Button) view
				.findViewById(R.id.more_emailBtn);

		emailUsBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Call email Default client

//				custservice@semaconnect.com
				Uri uri = Uri.parse("mailto:custservice@semaconnect.com");
				Intent sendIntent = new Intent(Intent.ACTION_SENDTO, uri);

				sendIntent.putExtra(Intent.EXTRA_SUBJECT,
						"");
				sendIntent.putExtra(Intent.EXTRA_TEXT,
						"");

//				sendIntent.putExtra(Intent.EXTRA_EMAIL, new String[] { "",
//						getString(R.string.emailus) });
//				sendIntent.setType("text/html");
				startActivity(sendIntent);
			}
		});

		Button tellFrndUsBtn = (Button) view
				.findViewById(R.id.more_tellfriendBtn);

		tellFrndUsBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Call email Default client
				Intent sendIntent = new Intent(Intent.ACTION_SEND);
				sendIntent.putExtra(Intent.EXTRA_SUBJECT,
						getString(R.string.tellfriendsub));
				sendIntent.setType("text/plain");
				sendIntent.putExtra(Intent.EXTRA_SUBJECT,
						"I want to tell you about SemaConnect");
				sendIntent.putExtra(Intent.EXTRA_TEXT,
						"SemaConnect is the leading provider of electric vehicle amenities to the North American commercial and residential property market.\n" +
								"Joining the SemaConnect Network gives you convenient and easy access to their EV charging stations and features like real-time charging status, sustainability reporting etc.\n\n" +
								"Download the app at:\n" +
								"\n" +
								"https://play.google.com/store/apps/details?id=com.semaconnect&hl=en");
				startActivity(Intent
						.createChooser(sendIntent, "Tell a Friend:"));
			}
		});

		Button ratingBtn = (Button) view
				.findViewById(R.id.more_rateBtn);

		ratingBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				showRateAppDialogIfNeeded();
			}
		});
		Button sugLocBtn = (Button) view
				.findViewById(R.id.more_location);

		sugLocBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {

				GmailFrom f1 = new GmailFrom();
				Bundle args = new Bundle();
				args.putString("title", "Suggest Location");
				f1.setArguments(args);
				((ActivityInTab) getActivity()).navigateTo(f1);
			}
		});

		Button reportBtn = (Button) view
				.findViewById(R.id.more_report);

		reportBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Call Report Problem Page
				ReportProblem f = new ReportProblem();
				Bundle args = new Bundle();
				args.putString("title", "Report a problem");
				args.putString("navigate", "home");
				f.setArguments(args);
				((ActivityInTab) getActivity()).navigateTo(f);
			}
		});

	}

	private boolean showRateAppDialogIfNeeded() {
//		boolean bool = AppPreferences.getInstance(getActivity()).getAppRate();
//		int i = AppPreferences.getInstance(getActivity()).getLaunchCount();
//		if ((bool) && (i % 1 == 0)) {
			createAppRatingDialog(getString(R.string.rate_app_title), getString(R.string.rate_app_message)).show();
			return true;
//		} else {
//			return false;
//		}
	}

	private AlertDialog createAppRatingDialog(String rateAppTitle, String rateAppMessage) {
		LayoutInflater factory = LayoutInflater.from(getActivity());
		final View deleteDialogView = factory.inflate(R.layout.custom, null);

		RatingBar ratingBar = (RatingBar) deleteDialogView.findViewById(R.id.ratingBar);
		final TextView txtRatingValue = (TextView) deleteDialogView.findViewById(R.id.txtRatingValue);
		final TextView custom_title = (TextView) deleteDialogView.findViewById(R.id.custom_title);
		final TextView custom_message = (TextView) deleteDialogView.findViewById(R.id.custom_message);
		final TextView button1 = (TextView) deleteDialogView.findViewById(R.id.button1);
		final TextView button2 = (TextView) deleteDialogView.findViewById(R.id.button2);
		final TextView button3 = (TextView) deleteDialogView.findViewById(R.id.button3);
		txtRatingValue.setText("Thank you very much for rating us 5 stars!");
		custom_title.setText(rateAppTitle);
		custom_message.setText(rateAppMessage);
		//if rating value is changed,
		//display the current rating value in the result (textview) automatically

		ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
			public void onRatingChanged(RatingBar ratingBar, float rating,
										boolean fromUser) {
				currentRating = rating;

				if (rating <= 3.0f) {
					txtRatingValue.setText("Please leave us feedback so that we can address your issues.");
				} else {
					int ratingInt = (int) rating;
					txtRatingValue.setText("Thank you very much for rating us " + String.valueOf(ratingInt) + " stars!");
				}
			}
		});

		AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(getActivity(), android.R.style.Theme_Holo_Dialog));

		final AlertDialog dialog = builder.create();
		dialog.setCancelable(false);


		button1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				currentRating = 5.0f;
				dialog.dismiss();
				AppPreferences.getInstance(getActivity().getApplicationContext()).resetLaunchCount();
//                finish();
			}

		});
		button2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				currentRating = 5.0f;
				//            openFeedback(MainActivity.this);
				dialog.dismiss();
				AppPreferences.getInstance(getActivity().getApplicationContext()).setAppRate(false);
//				finish();
			}

		});

		button3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (currentRating <= 3.0f) {
					openFeedback(getActivity());
				} else {
					openAppInPlayStore(getActivity());
					AppPreferences.getInstance(getActivity().getApplicationContext()).setAppRate(false);
				}
				dialog.dismiss();
			}

		});
		dialog.setView(deleteDialogView);
//		dialog.setTitle(rateAppTitle);
//		dialog.setMessage(rateAppMessage);
		return dialog;
	}

	public static void openAppInPlayStore(Context paramContext) {
		paramContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.semaconnect&hl=en")));
	}

	public static void openFeedback(Context paramContext) {
		Intent localIntent = new Intent(Intent.ACTION_SEND);
		localIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"custservice@semaconnect.com"});
		localIntent.putExtra(Intent.EXTRA_CC, "");
		String str = null;
		try {
			str = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionName;
			localIntent.putExtra(Intent.EXTRA_SUBJECT, "I Rated the SemaConnect Android app " + currentRating + " stars");
			localIntent.setType("message/rfc822");
			paramContext.startActivity(Intent.createChooser(localIntent, "Choose an Email client :"));
		} catch (Exception e) {
			Log.d("OpenFeedback", e.getMessage());
		}
	}

}
