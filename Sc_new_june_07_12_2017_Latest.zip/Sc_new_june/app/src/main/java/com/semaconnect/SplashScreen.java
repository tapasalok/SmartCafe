package com.semaconnect;

import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import com.semaconnect.utility.Config;

public class SplashScreen extends Activity {
	SharedPreferences settings;
	SharedPreferences.Editor editor;
	private ImageView mSplashImage;
	
	public void detectScreenSize() {
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();
		setScreenSize(width);
		Log.v("hxw", "" + width + "," + height);
	}

	private void setScreenSize(int width) {

		String w = Integer.toString(width);
		
		Config.mapSize 	= w+"x"+w;
		if(width >  1000){
			Config.chartSize 	= "865x346"; // maintain 10:4 aspect ratio and 300000 limit	
		} else {
			Config.chartSize 	= Integer.toString(width -50)+"x"+Integer.toString((width-50)*4/10);
		}
		

	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		settings = getSharedPreferences("session_auth", 0);
		editor = settings.edit();
		editor.putBoolean("chargeNowClick", false);
		editor.putBoolean("chargeNow", false);
		editor.commit();

		if (checkConnection()) {
			setContentView(R.layout.splash);
			mSplashImage = (ImageView) findViewById(R.id.splash_screen);

			AppPreferences.getInstance(getApplicationContext()).incrementLaunchCount();

			Config.mLat = 0.0;
			Config.mLong = 0.0;

			final Animation fadeIn = new AlphaAnimation((float) .2, 1);
			fadeIn.setInterpolator(new DecelerateInterpolator());
			fadeIn.setDuration(500);

			final Animation fadeOut = new AlphaAnimation(1, (float) .4);
			fadeOut.setInterpolator(new AccelerateInterpolator());
			fadeOut.setStartOffset(2500);
			fadeOut.setDuration(500);

			final AnimationSet animation = new AnimationSet(false);
			animation.addAnimation(fadeIn);
			animation.addAnimation(fadeOut);

			mSplashImage.setAnimation(animation);

			new Handler().post(new Runnable() {
				@Override
				public void run() {
					mSplashImage.setVisibility(ImageView.INVISIBLE);
				}
			});

			Timer timer = new Timer();
			TimerTask mTask = new TimerTask() {
				@Override
				public void run() {

					finish();
					startActivity(new Intent(SplashScreen.this,
							TabsFragmentActivity.class));
				}
			};
			timer.schedule(mTask, 3000);
		} else {
			showAlert();
		}

		detectScreenSize();
	}

	private boolean checkConnection() {

		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();

		if (netInfo != null && netInfo.isConnectedOrConnecting()) {
			return true;
		}
		return false;
	}

	/**
	 * Dialog to show network unavailability
	 */
	private void showAlert() {
		AlertDialog.Builder builder = new AlertDialog.Builder(SplashScreen.this);
		builder.setTitle(R.string.network_title);
		builder.setIcon(R.drawable.ic_launcher);
		builder.setMessage(R.string.network_msg).setPositiveButton("Ok",
				new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				});
		builder.create();
		builder.show();
	}

}
