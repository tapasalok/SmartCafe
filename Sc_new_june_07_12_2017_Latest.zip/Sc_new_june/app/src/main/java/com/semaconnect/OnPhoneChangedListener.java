package com.semaconnect;
public interface OnPhoneChangedListener {

    public void onPhoneChanged(String phone);

}
