package com.semaconnect.utility;

import android.content.Context;

import android.util.AttributeSet;
import android.view.GestureDetector;

import android.view.MotionEvent;
import android.widget.Gallery;

public class BetterGallery extends Gallery {
	/* This gets set when we detect horizontal scrolling */
	private boolean scrollingHorizontally = false;

	/*
	 * This gets set during vertical scrolling. We use this to avoid detecting
	 * horizontal scrolling when vertical scrolling is already in progress and
	 * vice versa.
	 */
	private boolean scrollingVertically = false;

	/*
	 * Our own gesture detector, Gallery's mGestureDetector is private. We'll
	 * feed it with motion events from `onInterceptTouchEvent` method.
	 */
	private GestureDetector mBetterGestureDetector;

	public BetterGallery(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		mBetterGestureDetector = new GestureDetector(
				new BetterGestureListener());
	}

	public BetterGallery(Context context, AttributeSet attrs) {
		super(context, attrs);
		mBetterGestureDetector = new GestureDetector(
				new BetterGestureListener());
	}

	public BetterGallery(Context context) {
		super(context);
		mBetterGestureDetector = new GestureDetector(
				new BetterGestureListener());
	}
	
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		return super.onFling(e1, e2, velocityX / 4, velocityY);
	}

	/*
	 * @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float
	 * velocityX, float velocityY) { // Limit velocity so we don't fly over
	 * views return super.onFling(e1, e2, 0, velocityY); }
	 */

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		// Documentation on this method's contract:
		// http://developer.android.com/reference/android/view/ViewGroup.html#onInterceptTouchEvent(android.view.MotionEvent)

		// Reset our scrolling flags if ACTION_UP or ACTION_CANCEL
		switch (ev.getAction()) {
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_CANCEL:
			scrollingHorizontally = false;
			scrollingVertically = false;
		}

		// Feed our gesture detector
		mBetterGestureDetector.onTouchEvent(ev);

		// Intercept motion events if horizontal scrolling is detected
		return scrollingHorizontally;
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// Hack: eat jerky scrolls caused by stale state in mGestureDetector
		// which we cannot directly access
		
		if (Math.abs(distanceX) > 100)
			return false;

		return super.onScroll(e1, e2, distanceX, distanceY);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// Reset our scrolling flags if ACTION_UP or ACTION_CANCEL
		switch (event.getAction()) {
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_CANCEL:
			scrollingHorizontally = false;
			scrollingVertically = false;
		}

		super.onTouchEvent(event);
		return scrollingHorizontally;
	}
	
//	@Override
//	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
//			float velocityY) {
//		
//		return super.onFling(e1, e2, 0, velocityY);
//	}

	private class BetterGestureListener implements
			GestureDetector.OnGestureListener {

		public boolean onDown(MotionEvent e) {
			// TODO Auto-generated method stub
			return false;
		}

		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {
			return false;
		}

		public void onLongPress(MotionEvent e) {
			// TODO Auto-generated method stub

		}

		public boolean onScroll(MotionEvent e1, MotionEvent e2,
				float distanceX, float distanceY) {
			if (scrollingHorizontally || scrollingVertically) {
				// We already know we're scrolling, ignore this callback.
				// This avoids changing scrollingHorizontally /
				// scrollingVertically
				// flags mid-scroll.
				return false;
			}
			scrollingHorizontally |= Math.abs(distanceX) > Math.abs(distanceY);
			// It's a scroll, and if it's not horizontal, then it has to be
			// vertical
			scrollingVertically = !scrollingHorizontally;

			return false;

		}

		public void onShowPress(MotionEvent e) {
			// TODO Auto-generated method stub

		}

		public boolean onSingleTapUp(MotionEvent e) {
			// TODO Auto-generated method stub
			return false;
		}

	}

}
