package com.semaconnect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.semaconnect.utility.Config;
import com.semaconnect.utility.RestClient;

public class SignUp extends Fragment implements OnEditorActionListener {

	ViewGroup view;
	private EditText mFirstName, mLastName, mEmail, mUserName, mPassword;
	private ImageButton mSignUpBtn;
	private final static String TAG = "SIGNUPSCREEN";

	private LinearLayout mBlueMsg;
//	private TextView mTVErrorMsg;

	private TextView lblFName, lblLName, lblEmail, lblUName, lblPass;

	private String mEntity;

	private String mResponse = "";
	private int mResponse_code;
	SharedPreferences settings;
	SharedPreferences.Editor editor;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater.inflate(R.layout.signup, container, false);
		view.setLayoutParams(new ViewGroup.LayoutParams
				(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));

		settings = getActivity().getSharedPreferences("session_auth", 0);
		editor = settings.edit();

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		setView();

		Config.ViewDismiss();

		TextView titleTxt = (TextView) view.findViewById(R.id.top_title_txt);

		Bundle args = getArguments();
		titleTxt.setText(args.get("title").toString());


		mSignUpBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {

				mEntity = "{\"first_name\":" + "\""
						+ mFirstName.getText().toString() + "\""
						+ ",\"last_name\":" + "\""
						+ mLastName.getText().toString() + "\""
						+ ",\"email\":" + "\""
						+ mEmail.getText().toString() + "\""
						+ ",\"username\":" + "\""
						+ mUserName.getText().toString() + "\""
						+ ",\"password\":" + "\""
						+ mPassword.getText().toString() + "\"" + "}";

				Config.auth_para = mUserName.getText().toString() + ":"
						+ mPassword.getText().toString();
				//validate the input fields

				if (mFirstName.length() == 0 ) {
					showDialog("first_name", "");

				}else if( mLastName.length() == 0){
					showDialog("last_name", "");

			}else if(mEmail.length() == 0){
				showDialog("email", "");

			}else if(mUserName.length() == 0) {
					showDialog("username", "");

				}else if(mPassword.length() == 0) {
						showDialog("password", "");


					} else {
						Log.i("anisha","Clicked: Signup");
						new ParseData().execute();
					}
			}
		});

	}

	private void resetValues() {
		mFirstName.setText("");
		mLastName.setText("");
		mEmail.setText("");
		mUserName.setText("");
		mPassword.setText("");
	}

	private void setView() {

		mFirstName = (EditText) view.findViewById(R.id.signup_fname);
		mLastName = (EditText) view.findViewById(R.id.signup_lname);
		mEmail = (EditText) view.findViewById(R.id.signup_email);
		mUserName = (EditText) view.findViewById(R.id.signup_uname);
		mPassword = (EditText) view.findViewById(R.id.signup_pass);
		mSignUpBtn = (ImageButton) view.findViewById(R.id.signup_signupbtn);

		mBlueMsg = (LinearLayout) view.findViewById(R.id.signup_msglay);
//		mErrorMsg = (LinearLayout) view.findViewById(R.id.signup_errorbox);

//		mTVErrorMsg = (TextView) view.findViewById(R.id.error_txt_child);

		lblFName = (TextView) view.findViewById(R.id.signup_label_fn);
		lblLName = (TextView) view.findViewById(R.id.signup_label_ln);
		lblEmail = (TextView) view.findViewById(R.id.signup_label_email);
		lblUName = (TextView) view.findViewById(R.id.signup_label_un);
		lblPass = (TextView) view.findViewById(R.id.signup_label_pass);

		mBlueMsg.setVisibility(LinearLayout.VISIBLE);
//		mErrorMsg.setVisibility(LinearLayout.GONE);

		mPassword.setOnEditorActionListener(this);

	}

	/**
	 * class is used to parse and handle the data
	 * 
	 * @author kipl108
	 * 
	 */
	public class ParseData extends AsyncTask<Void, Void, Void> {

		String currentKey = "";
		String currentValue = "";

		@Override
		protected void onPreExecute() {
			Log.i("anisha"," ParseData onPreExecute");
			super.onPreExecute();
			Config.ViewShow();
			mFirstName.setEnabled(false);
			mLastName.setEnabled(false);
			mEmail.setEnabled(false);
			mPassword.setEnabled(false);
			mUserName.setEnabled(false);
		}

		@Override
		protected Void doInBackground(Void... params) {

			Log.i("anisha"," ParseData doInBackground");

			String url = Config.BASE_URL + "users?key=" + Config.KEY;

			try {

				HttpPost httpost = new HttpPost(url);
				httpost.setEntity(new StringEntity(mEntity));
				// httpost.setHeader("Content-Type", "application/json");
				httpost.setHeader("Content-Type",
						"application/x-www-form-urlencoded");

				Log.v("ENTITY", "" + mEntity);

				HttpResponse httpResponse = null;

				if (Config.client != null) {
					httpResponse = Config.client.execute(httpost);
				} else {
					httpResponse = Config.getThreadSafeClient()
							.execute(httpost);
				}
				mResponse_code = httpResponse.getStatusLine().getStatusCode();
				Log.v("STATUS CODE :: ", ""
						+ httpResponse.getStatusLine().getStatusCode());

				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {

					InputStream input = null;
					input = entity.getContent();
					mResponse = convertStreamToString(input);

					input.close();

					Log.v("STATUS mResponse :: ", "" + mResponse);
					if (mResponse != null) {

						JSONObject json = new JSONObject(mResponse);
						Iterator keys = json.keys();

						while (keys.hasNext()) {
							// loop to get the dynamic key
							currentKey = (String) keys.next();

							// get the value of the dynamic key
							currentValue = json.getString(currentKey);
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onProgressUpdate(Void... values) {
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			Config.ViewDismiss();
			Log.i("anisha"," ParseData onPostExecute");
			Log.i("anisha","mResponse: "+mResponse);
			Log.i("anisha","mResponse_code: "+mResponse_code);
			if (mResponse_code == 201 && mResponse != null) {

				boolean showLogin = settings.getBoolean("showLogin", true);
				if (showLogin){
					Config.signUpFlag = true;
				}else {
					Config.signUpFlag = false;
				}

				boolean chargeNowSelectStation = settings.getBoolean("chargeNowSelectStation", false);
				if (chargeNowSelectStation){
					Config.signUpFlag = false;
				}

				Config.username = mUserName.getText().toString();
				new MakeLogin().execute();
				mFirstName.setEnabled(true);
				mLastName.setEnabled(true);
				mEmail.setEnabled(true);
				mPassword.setEnabled(true);
				mUserName.setEnabled(true);
			} else if (mResponse_code == 406 && mResponse != null){

				if(!TextUtils.isEmpty(currentKey) && !currentKey.equalsIgnoreCase("email") && !currentKey.equalsIgnoreCase("username")){
					mFirstName.setEnabled(true);
					mLastName.setEnabled(true);
					mEmail.setEnabled(true);
					mPassword.setEnabled(true);
					mUserName.setEnabled(true);
					showDialog(currentKey, "Please provide valid "+currentKey);
				}else if (!TextUtils.isEmpty(currentValue)){
					mFirstName.setEnabled(true);
					mLastName.setEnabled(true);
					mEmail.setEnabled(true);
					mPassword.setEnabled(true);
					mUserName.setEnabled(true);
					String emailFromScreen = mEmail.getText().toString();
					String usernameFromScreen = mUserName.getText().toString();
					if ((!TextUtils.isEmpty(emailFromScreen) && emailFromScreen.equals(currentValue)) || (!TextUtils.isEmpty(usernameFromScreen) && usernameFromScreen.equals(currentValue)) ){
						showDialog(currentKey, "Please provide valid "+currentKey);
						Log.i("anisha", "currentValue  :" +currentValue);
					}else {
						showDialog(currentKey, currentValue);
					}

				}else{
					Toast.makeText(getActivity(), "Please provide valid signup details.", Toast.LENGTH_SHORT).show();
					mFirstName.setEnabled(true);
					mLastName.setEnabled(true);
					mEmail.setEnabled(true);
					mPassword.setEnabled(true);
					mUserName.setEnabled(true);
				}
			}else {
				mFirstName.setEnabled(true);
				mLastName.setEnabled(true);
				mEmail.setEnabled(true);
				mPassword.setEnabled(true);
				mUserName.setEnabled(true);
				Log.i("anisha","mResponse" + mResponse);
				Log.i("anisha","currentValue" + currentValue + "   " + currentKey );
				showDialog(currentKey, currentValue);
			}

		}
	}

	private void switchToNext() {

		MyAccount f = new MyAccount();
		Bundle args = new Bundle();
		args.putString("title", "MyAccount");
		f.setArguments(args);
		((ActivityInTab) getActivity()).navigateTo(f);
		resetValues();

	}

	private void switchToHomeScreen() {

		HomeScreen f = new HomeScreen();
		Bundle args = new Bundle();
		args.putString("title", "My Account");
		f.setArguments(args);
		((ActivityInTab) getActivity()).navigateWithoutBack(f);
		resetValues();

	}

	private static String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	public void showDialog(String title, String message) {

//		AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
//		alert.setTitle("Signup unsuccessful");
//		alert.setIcon(R.drawable.ic_launcher);
//		alert.setMessage("Please provide valid information.");
//		alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				dialog.dismiss();
//			}
//		});
//
//		alert.create();
//		alert.show();

		if (TextUtils.isEmpty(message)){
			Toast.makeText(getActivity(), "Please provide valid signup details.", Toast.LENGTH_SHORT).show();
		}else {
			Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
			Log.i("anisha","message A" + message);
		}


		// Showing Error
		mBlueMsg.setVisibility(LinearLayout.VISIBLE);

		resetLabel();

		if (title.equalsIgnoreCase("first_name")) {
			lblFName.setTextAppearance(getActivity(), R.style.error_text);
		} else if (title.equalsIgnoreCase("last_name")) {
			lblLName.setTextAppearance(getActivity(), R.style.error_text);
		} else if (title.equalsIgnoreCase("email")) {
			lblEmail.setTextAppearance(getActivity(), R.style.error_text);
		} else if (title.equalsIgnoreCase("username")) {
			lblUName.setTextAppearance(getActivity(), R.style.error_text);
		} else if (title.equalsIgnoreCase("password")) {
			lblPass.setTextAppearance(getActivity(), R.style.error_text);
		}

	}

	private void resetLabel() {
		lblUName.setTextAppearance(getActivity(), R.style.simple_text_style);
		lblFName.setTextAppearance(getActivity(), R.style.simple_text_style);
		lblLName.setTextAppearance(getActivity(), R.style.simple_text_style);
		lblEmail.setTextAppearance(getActivity(), R.style.simple_text_style);
		lblPass.setTextAppearance(getActivity(), R.style.simple_text_style);
	}

	@Override
	public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		if (actionId == EditorInfo.IME_ACTION_GO) {

//			InputMethodManager imm = (InputMethodManager) v.getContext()
//					.getSystemService(Context.INPUT_METHOD_SERVICE);
//			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

			mEntity = "{\"username\":" + "\"" + mUserName.getText().toString()
					+ "\"" + ",\"password\":" + "\""
					+ mPassword.getText().toString() + "\""
					+ ",\"first_name\":" + "\""
					+ mFirstName.getText().toString() + "\""
					+ ",\"last_name\":" + "\"" + mLastName.getText().toString()
					+ "\"" + ",\"email\":" + "\"" + mEmail.getText().toString()
					+ "\"" + "}"; // + "\""

			new ParseData().execute();
			return true;
		}
		return false;
	}

	private class MakeLogin extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... params) {

			try {
				mResponse = RestClient.postHTPPRequest(Config.BASE_URL
						+ "http-sessions?key=" + Config.KEY, mUserName.getText().toString()
						+ ":"
						+ mPassword.getText().toString());

				Log.v("response >>>", "" + mResponse);

				if (mResponse != null) {

					JSONObject jObject = new JSONObject(mResponse);

					Config.username = jObject.getString("username");
					Config.pwd = mPassword.getText().toString();

					Config.auth_para = Config.username + ":" + Config.pwd;
					Log.v("Config.auth_para", "" + Config.auth_para);

					Config.sid = jObject.getString("id");
					Config.expires = jObject.getString("expires");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			Config.ViewDismiss();

			if (Config.mStatusCode == 200 && mResponse != null) {
				Config.loginChk = true;
				resetValues();

				editor = settings.edit();
				editor.putString("username", Config.username);
				editor.putString("password", Config.pwd);
				editor.commit();

				settings = getActivity().getSharedPreferences("session_auth", 0);
				editor = settings.edit();
				boolean showLogin = settings.getBoolean("showLogin", true);
				boolean chargeNowSelectStation = settings.getBoolean("chargeNowSelectStation", false);

				if (showLogin){
					switchToNext();
				}else if(chargeNowSelectStation) {
					switchToHomeScreen();
				}else {
					switchToHomeScreen();
				}

			} else {
				Toast.makeText(getActivity(), mResponse, Toast.LENGTH_SHORT)
						.show();
				Log.i("anisha","mResponse" + mResponse);
				resetValues();
			}
		}
	}

}
