package com.semaconnect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.text.TextUtilsCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TextView.OnEditorActionListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.semaconnect.utility.Config;

public class ReportProblem extends Fragment implements OnEditorActionListener {

    ViewGroup view;

    private TextView mReportTxt;
    private TextView mSeverTxt;
    private TextView mLedColorTxt;
    private TextView mTitle;

    private EditText errorCode;
    private EditText comments;

    private String mEntity;

    InputMethodManager imm;

    static int spin1_pos;
    static int spin2_pos;
    static int spin3_pos;

    private String mResponse = "";
    private int mResponse_code;
    private String navigate;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (container == null) {
            return null;
        }
        view = (ViewGroup) inflater.inflate(R.layout.report_problem, container,
                false);
        view.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        imm = (InputMethodManager) getActivity().getSystemService(
                Context.INPUT_METHOD_SERVICE);

        view.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                imm.hideSoftInputFromWindow(errorCode.getWindowToken(), 0);
                imm.hideSoftInputFromWindow(comments.getWindowToken(), 0);

            }
        });

        if (getArguments()!=null){
            navigate=getArguments().getString("navigate");
        }
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        Config.ViewDismiss();
//		TextView titleTxt = (TextView) view.findViewById(R.id.top_title_txt);

//		try{
//			Bundle args = getArguments();
//			titleTxt.setText(args.get("title").toString());
//		}catch(Exception e) {
//			Bundle args = getActivity().getIntent().getExtras();
//			titleTxt.setText(args.get("title").toString());
//		}
//

        mReportTxt = (TextView) view.findViewById(R.id.report_prob);
        mSeverTxt = (TextView) view.findViewById(R.id.report_sever);
        mLedColorTxt = (TextView) view.findViewById(R.id.report_led);

        errorCode = (EditText) view.findViewById(R.id.report_errorcode);
        comments = (EditText) view.findViewById(R.id.report_comment);

        comments.setOnEditorActionListener(this);
        mTitle = (TextView) view.findViewById(R.id.top_title_txt);
        mTitle.setText(R.string.report_problem);
        RelativeLayout reportSpin = (RelativeLayout) view
                .findViewById(R.id.report_problay);
        reportSpin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Spinner spinner1 = new Spinner(TabGroupActivity.sGroup);
                spinner1.setTag("spinner1");
                ArrayAdapter<CharSequence> adapter = ArrayAdapter
                        .createFromResource(TabGroupActivity.sGroup,
                                R.array.report_problem,
                                android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner1.setAdapter(adapter);
                spinner1.performClick();
                spinner1.setOnItemSelectedListener(new SpinItemClickListner());

                mReportTxt.setText("" + spinner1.getItemAtPosition(spin1_pos));
                spinner1.setSelection(spin1_pos);

                view.addView(spinner1);
                spinner1.setVisibility(Spinner.INVISIBLE);
            }
        });

        RelativeLayout severSpin = (RelativeLayout) view
                .findViewById(R.id.report_severlay);
        severSpin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Spinner spinner2 = new Spinner(TabGroupActivity.sGroup);
                spinner2.setTag("spinner2");
                ArrayAdapter<CharSequence> adapter = ArrayAdapter
                        .createFromResource(TabGroupActivity.sGroup,
                                R.array.report_severity,
                                android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner2.setAdapter(adapter);
                spinner2.performClick();
                spinner2.setOnItemSelectedListener(new SpinItemClickListner());

                mSeverTxt.setText("" + spinner2.getItemAtPosition(spin2_pos));
                spinner2.setSelection(spin2_pos);


                view.addView(spinner2);
                spinner2.setVisibility(Spinner.INVISIBLE);

            }
        });

        RelativeLayout ledSpin = (RelativeLayout) view
                .findViewById(R.id.report_ledlay);
        ledSpin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Spinner spinner3 = new Spinner(TabGroupActivity.sGroup);
                spinner3.setTag("spinner3");
                ArrayAdapter<CharSequence> adapter = ArrayAdapter
                        .createFromResource(TabGroupActivity.sGroup,
                                R.array.report_ledcolors,
                                android.R.layout.simple_spinner_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner3.setAdapter(adapter);
                spinner3.performClick();
                spinner3.setOnItemSelectedListener(new SpinItemClickListner());

                mLedColorTxt.setText("" + spinner3.getItemAtPosition(spin3_pos));
                spinner3.setSelection(spin3_pos);

                view.addView(spinner3);
                spinner3.setVisibility(Spinner.INVISIBLE);

            }
        });

        ImageButton mBtnSubmit = (ImageButton) view
                .findViewById(R.id.report_subbtn);
        mBtnSubmit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // Collected Data and Send to the server

                if ( TextUtils.isEmpty(mReportTxt.getText().toString())
                        || TextUtils.isEmpty(mSeverTxt.getText().toString())
                        || TextUtils.isEmpty(mLedColorTxt.getText().toString())
                        || TextUtils.isEmpty(comments.getText().toString())) {

                    Toast.makeText(getActivity(), R.string.all_compulsory,
                            Toast.LENGTH_SHORT).show();
                } else {

                    mEntity = "{\"summary\":" + "\""
                            + mReportTxt.getText().toString() + "\"";

                    if(!TextUtils.isEmpty(errorCode.getText().toString())){
                        String errorCodeString = errorCode.getText().toString().trim();
                        mEntity = mEntity + ",\"error\":" + "\""+ errorCodeString + "\"";
                    }

                    mEntity = mEntity + ",\"led_color\":" + "\""
                            + mLedColorTxt.getText().toString() + "\""
                            + ",\"priority\":" + "\""
                            + mSeverTxt.getText().toString() + "\"";

                    if(!TextUtils.isEmpty(comments.getText().toString())){
                        String commentsString = comments.getText().toString().trim();
                            if (TextUtils.isEmpty(commentsString)){
                                Toast.makeText(getActivity(), R.string.all_compulsory,
                                        Toast.LENGTH_SHORT).show();
                                return;
                            }else{
                                mEntity = mEntity + ",\"comments\":" + "\""
                                        + commentsString + "\"";
                            }
                    }

                    mEntity = mEntity  + "}";

                    new ParseData().execute();

                }
            }
        });

    }

    public class ParseData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            Config.ViewShow();
        }

        @Override
        protected Void doInBackground(Void... params) {

            String url = Config.BASE_URL + "problems?key=" + Config.KEY;

            try {

                HttpPost httpost = new HttpPost(url);
                httpost.setEntity(new StringEntity(mEntity));
                httpost.setHeader("Content-Type", "application/json");

                Log.v("ENTITY", "" + mEntity);

                HttpResponse httpResponse = null;

                httpResponse = Config.client.execute(httpost);

                mResponse_code = httpResponse.getStatusLine().getStatusCode();

                HttpEntity entity = httpResponse.getEntity();
                if (entity != null) {
                    InputStream input = null;
                    input = entity.getContent();
                    mResponse = convertStreamToString(input);

                    input.close();

                    Log.i("anisha", ">>>" + mResponse_code + "**" + mResponse);

                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            Config.ViewDismiss();

            Toast.makeText(getActivity(), mResponse, Toast.LENGTH_SHORT).show();

            mReportTxt.setText("");
            mSeverTxt.setText("");
            mLedColorTxt.setText("");

            errorCode.setText("");
            comments.setText("");

            if (mResponse_code == 200){
                if (!TextUtils.isEmpty(navigate) && navigate.equalsIgnoreCase("home")){
                    FragmentManager fm = getActivity().getSupportFragmentManager();
                    fm.popBackStack();
                }else {
                    Intent i = new Intent(getActivity(),
                            MapScreen.class);
                    i.putExtra("title", "Map Screen");
                    TabGroupActivity parentActivity = (TabGroupActivity) TabGroupActivity.sGroup;
                    parentActivity.startChildActivity("map_screen", i);
                }
            }
        }
    }

    private static String convertStreamToString(InputStream is) {
//		Log.i("Inside convertstream method", "hello");
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    private class SpinItemClickListner implements OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> adapter, View view, int pos,
                                   long id) {
            if (adapter.getTag().equals("spinner1")) {
                mReportTxt.setText("" + adapter.getItemAtPosition(pos));
                spin1_pos = pos;
            } else if (adapter.getTag().equals("spinner2")) {
                mSeverTxt.setText("" + adapter.getItemAtPosition(pos));
                spin2_pos = pos;
            } else if (adapter.getTag().equals("spinner3")) {
                mLedColorTxt.setText("" + adapter.getItemAtPosition(pos));
                spin3_pos = pos;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapter) {

        }
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_SEND) {

            InputMethodManager imm = (InputMethodManager) v.getContext()
                    .getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

            if ( TextUtils.isEmpty(mReportTxt.getText().toString())
                    || TextUtils.isEmpty(mSeverTxt.getText().toString())
                    || TextUtils.isEmpty(mLedColorTxt.getText().toString())
                    || TextUtils.isEmpty(comments.getText().toString())) {

                Toast.makeText(getActivity(), R.string.all_compulsory,
                        Toast.LENGTH_SHORT).show();
            } else {

                mEntity = "{\"summary\":" + "\""
                        + mReportTxt.getText().toString() + "\"";

                if(!TextUtils.isEmpty(errorCode.getText().toString())){
                    mEntity = mEntity + ",\"error\":" + "\""+ errorCode.getText().toString() + "\"";
                }

                mEntity = mEntity + ",\"led_color\":" + "\""
                        + mLedColorTxt.getText().toString() + "\""
                        + ",\"priority\":" + "\""
                        + mSeverTxt.getText().toString() + "\"";

                if(!TextUtils.isEmpty(comments.getText().toString())){
                    mEntity = mEntity + ",\"comments\":" + "\""
                            + comments.getText().toString() + "\"";
                }
                mEntity = mEntity  + "}";
                new ParseData().execute();

            }
        }
        return false;
    }
}