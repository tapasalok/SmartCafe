package com.semaconnect;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.Overlay;
import com.semaconnect.utility.Config;
import com.semaconnect.utility.CustomTextView;
import com.semaconnect.utility.MyItemizedOverlay;
import com.semaconnect.utility.RestClient;

public class MyAccount extends Fragment implements SwipeRefreshLayout.OnRefreshListener {

    private View view;

    private CustomTextView firstName;
    private CustomTextView remBalance;
    private CustomTextView chargeCost, chargeTime;
    private CustomTextView chargeStatus;
    private ScrollView mFullLayout;
    private ImageView mChargeIcon;

    private TextView mEnergyCon, mGreenHouse, mMyLocation, mNoGraphDataMsg;

    private WebView graphView;

//    ImageButton refreshButton;

    List<Overlay> mapOverlays;
    Drawable drawable;
    Drawable drawable2;
    MyItemizedOverlay itemizedOverlay;
    MyItemizedOverlay itemizedOverlay2;

    private String mResponse = "";
    ProgressDialog pDialog;
    String first_name;
    String last_name;
    String username;
    String balance;
    String charging_session;
    String account_number;

    String location;
    String status;
    String cost;
    String time;

    String energy;
    String enery_con;
    String fuel_displaced;
    String co2_reduction;

    String statusCharge;
    String app_range;

    String myStatics;

    StringBuilder sb;

    Animation rotation;

    StringBuilder PowerList;
    StringBuilder energyList;
    ArrayList<String> timeList;

    private TextView kTV1, kTV2, kTV3;
    private TextView mlTV1, mlTV2, mlTV3;

    private TextView mStartTimeTxt, mEndTimeTxt, mSubCaption;

    LinearLayout noActBox;
    RelativeLayout noGraphRel;

    ImageView mWebView;

    boolean charging_flag;

    private String mNoDataMsg = "No Data";

    private final String ACTION_DIAL = "android.intent.action.DIAL";

    //    Refresh Screen Every 1 minute
    private int mInterval = 20*60*1000; // 30 seconds by default, can be changed later
    private Handler mHandler;

    // variable to toggle city values on refresh
    private SwipeRefreshLayout swipeView;
	SharedPreferences settings;
	SharedPreferences.Editor editor;

    String userName ;
    String  password;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (container == null) {
            return null;
        }

        settings = getActivity().getSharedPreferences("session_auth", 0);

        view = (ViewGroup) inflater.inflate(R.layout.login_account, container,
                false);
        view.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        mHandler = new Handler();
        startRepeatingTask();

//        Log.i("anisha", "onCreateView");

        return view;
    }

	/**
	 *
	 * @param index
	 * @return
     */
    public static MyAccount newInstance(int index) {
        MyAccount f = new MyAccount();

        // Supply index input as an argument.
        Bundle args = new Bundle();
        args.putInt("index", index);
        f.setArguments(args);

        return f;
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();

        if (Config.authorize) {
            Config.authorize = false;
//            refreshButton.startAnimation(rotation);

//            new ParseData().execute();
//            pDialog.dismiss();

        }
    }

    private void init() {
//        refreshButton = (ImageButton) view.findViewById(R.id.top_title_refresh);
//        refreshButton.setVisibility(ImageButton.VISIBLE);
        swipeView = (SwipeRefreshLayout) view.findViewById(R.id.swipe_view);
        swipeView.setOnRefreshListener(this);
        swipeView.setColorSchemeColors(Color.GRAY, Color.GREEN, Color.BLUE,
                Color.RED, Color.CYAN);
        swipeView.setDistanceToTriggerSync(20);// in dips
        swipeView.setSize(SwipeRefreshLayout.DEFAULT);// LARGE also can be used

        mWebView = (ImageView) view.findViewById(R.id.login_webview);

        graphView = (WebView) view.findViewById(R.id.login_graphview);

        firstName = (CustomTextView) view.findViewById(R.id.first_name);

        remBalance = (CustomTextView) view.findViewById(R.id.login_remBalance);
        chargeCost = (CustomTextView) view.findViewById(R.id.login_charge_cost);
        chargeStatus = (CustomTextView) view.findViewById(R.id.charged_txt);
        chargeTime = (CustomTextView) view.findViewById(R.id.login_charge_time);

        rotation = AnimationUtils.loadAnimation(getActivity(),
                R.anim.clockwise_rotation);
        rotation.setRepeatCount(Animation.INFINITE);

        mFullLayout = (ScrollView) view.findViewById(R.id.login_account_layout);

        kTV1 = (TextView) view.findViewById(R.id.kw_tv1);
        kTV2 = (TextView) view.findViewById(R.id.kw_tv2);
        kTV3 = (TextView) view.findViewById(R.id.kw_tv3);

        mlTV1 = (TextView) view.findViewById(R.id.ml_tv1);
        mlTV2 = (TextView) view.findViewById(R.id.ml_tv2);
        mlTV3 = (TextView) view.findViewById(R.id.ml_tv3);

        mEnergyCon = (TextView) view.findViewById(R.id.login_energy_consumed);
        mGreenHouse = (TextView) view.findViewById(R.id.login_green_house);

        noActBox = (LinearLayout) view.findViewById(R.id.my_account_no_act_box);

        mChargeIcon = (ImageView) view.findViewById(R.id.charged_icon);

        mMyLocation = (TextView) view.findViewById(R.id.login_my_location);

        mStartTimeTxt = (TextView) view
                .findViewById(R.id.login_charge_starttime);
        mEndTimeTxt = (TextView) view.findViewById(R.id.login_charge_endtime);

        mSubCaption = (TextView) view.findViewById(R.id.login_charge_caption);

        noGraphRel = (RelativeLayout) view
                .findViewById(R.id.login_no_graph_lay);
        mNoGraphDataMsg = (TextView) view.findViewById(R.id.no_graph_message);

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
//        Log.i("anisha", "onActivityCreated");
        Config.ViewDismiss();

        init();

		if(Config.signUpFlag == true) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("Do you wish to use fee  based stations?");

            builder.setIcon(R.drawable.ic_launcher);
            builder.setTitle("Thank you for signing up.");

            builder.setPositiveButton("Yes",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int arg1) {
                            Config.ViewShow();
                            PaymentInfo f = new PaymentInfo();
                            Bundle args = new Bundle();
                            args.putString("title", "Payment Info");
                            f.setArguments(args);
                            ((ActivityInTab) getActivity()).navigateTo(f);
                        }
                    });

            builder.setNegativeButton("No",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int arg1) {
                            dialog.dismiss();
                        }
                    });

            builder.create().show();

            Config.signUpFlag = false;

			settings = getActivity().getSharedPreferences("session_auth", 0);
        }

		ImageButton logOff = (ImageButton) view.findViewById(R.id.login_log_off);
        logOff.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Config.ViewShow();

                try {
                    callLogout();
                } catch (IOException e) { // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                FragmentManager fm = getFragmentManager();
                for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                    fm.popBackStack(null,
                            FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }

				settings = getActivity().getSharedPreferences("session_auth", 0);
				editor = settings.edit();
				editor.remove("username");
				editor.remove("password");
				editor.putBoolean("showLogin", true);
				editor.putBoolean("donotshowMA", false);

				editor.commit();

                HomeScreen f = new HomeScreen();
                Bundle args = new Bundle();
                args.putString("title", "My Account");
                f.setArguments(args);
                ((ActivityInTab) getActivity()).navigateTo(f);
            }
        });

        ImageButton mCallSupport = (ImageButton) view
                .findViewById(R.id.login_supportbtn);

        mCallSupport.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // Start Default Calling Application
                startActivity(new Intent(ACTION_DIAL, Uri.parse(getResources()
                        .getString(R.string.tel_no))));
            }
        });

        ImageButton reportBtn = (ImageButton) view
                .findViewById(R.id.login_reportbtn);

        reportBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // Call Report Problem Page
                Config.ViewShow();
                ReportProblem f = new ReportProblem();
                Bundle args = new Bundle();
                args.putString("title", "Report A Problem");
                args.putString("navigate", "home");
                f.setArguments(args);
                ((ActivityInTab) getActivity()).navigateTo(f);
            }
        });

        ImageButton paymentBtn = (ImageButton) view
                .findViewById(R.id.login_paymentBtn);

        paymentBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // Call Report Problem Page
                new GetUserPaymentDetails().execute();

            }
        });

//        refreshButton.setOnClickListener(new OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//
//                refreshButton.startAnimation(rotation);
//                new ParseData().execute();
//            }
//        });
//        new ParseData().execute();

    }

    public void callLogout() throws IOException {

        Config.loginChk = false;

        SharedPreferences settings = getActivity().getSharedPreferences(
                "session_auth", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.remove("username");
        editor.remove("password");
        editor.commit();

        Config.username = "";
        Config.pwd = "";
        Config.auth_para = "";
		/*
         * URL url = new URL(Config.BASE_URL + "/http-sessions/" + Config.sid +
		 * "?key=" + Config.KEY); HttpURLConnection httpCon =
		 * (HttpURLConnection) url.openConnection(); httpCon.setDoOutput(true);
		 * httpCon.setRequestProperty("Content-Type",
		 * "application/x-www-form-urlencoded");
		 * httpCon.setRequestMethod("DELETE"); httpCon.connect();
		 */

        new LogoutTask().execute();

    }

    private class LogoutTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            try {
                URL url = new URL(Config.BASE_URL + "http-sessions/"
                        + Config.sid + "?key=" + Config.KEY);

//                Log.i("anisha", " LogoutTask:  username: " + url +  Config.mStatusCode + mResponse );

                HttpDelete httpDelete = new HttpDelete(url.toString());
                httpDelete.setHeader("Content-Type",
                        "application/x-www-form-urlencoded");

                HttpResponse httpResponse = null;

                if (Config.client != null) {
                    httpResponse = Config.client.execute(httpDelete);
                } else {
                    httpResponse = Config.getThreadSafeClient().execute(
                            httpDelete);
                }

                Log.v("httpResponse", "" + httpResponse);

            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return null;
        }
    }

    public class ParseData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
			// TODO Auto-generated method stsuper.onPreExecute();
//            Config.ViewShow();

//            Log.i("anisha","URL Server Check: "+ Config.BASE_URL + "users/" + Config.username + "?key="
//                    + Config.KEY);
        }

        @Override
        protected Void doInBackground(Void... params) {

            String url = Config.BASE_URL + "users/" + Config.username + "?key="
                    + Config.KEY;

            try {

                RestClient client = new RestClient(url);
                client.AddHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                try {
                    client.Execute(RestClient.RequestMethod.GET);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                mResponse = client.getResponse();

                if (mResponse != null) {
                   Log.i("anisha", "ParseData_mResponse:" +mResponse);
                    JSONObject jObject = new JSONObject(mResponse);

                    first_name = jObject.getString("first_name");
                    last_name = jObject.getString("last_name");
                    username = jObject.getString("username");
                    balance = jObject.getString("balance");
                    charging_session = jObject.getString("charging_session");
                    account_number = jObject.getString("account_number");

                    myStatics = jObject.getString("statistics");
                    JSONObject jStaticObject = new JSONObject(myStatics);

                    String total = jStaticObject.getString("total");

                    Log.v("total", "" + total);

                    JSONObject jTotalObject = new JSONObject(total);

                    enery_con = jTotalObject.getString("energy");
                    fuel_displaced = jTotalObject.getString("fuel_displaced");
                    co2_reduction = jTotalObject.getString("co2_reduction");

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

		/**Display firstName,LastName,remBalance */


			firstName.setText("Welcome,  "+first_name+" "+last_name);
			remBalance.setText("$ " + setTwoDecimalPoint(balance));
		 	Config.ViewDismiss();

            Log.i("anisha","charging_session value from ParseData: "+charging_session);
            if (TextUtils.isEmpty(charging_session) || charging_session.equalsIgnoreCase("null")){
                // Don't call
                if(isAdded()){
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.norecentactivity));
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charged_noact_text_style);
                }

                chargeStatus.setText("NO RECENT ACTIVITY");

                energy = "0";
                enery_con = "0.00 kWh";
                co2_reduction = "0.00 Lbs.";
                mMyLocation.setText("No recent location to display");

                chargeCost.setVisibility(View.VISIBLE);
                chargeTime.setVisibility(View.VISIBLE);

                rotation.cancel();
                rotation.reset();
                charging_flag = true;
                chargeStatus.setText("NO RECENT ACTIVITY");

                noActBox.setVisibility(View.VISIBLE);

                formatingKWH("0");
                formatingMiles("0");


                new UpdateLocationDetail().execute();
            }else {
                Log.i("anisha","Calling GetChargingSessionData from ParseData: "+charging_session);
                new GetChargingSessionData().execute();
            }

        }
    }

    public class ParseDataWithoutCharging extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stsuper.onPreExecute();
//            Config.ViewShow();

//            Log.i("anisha","URL Server Check: "+ Config.BASE_URL + "users/" + Config.username + "?key="
//                    + Config.KEY);
        }

        @Override
        protected Void doInBackground(Void... params) {

            String url = Config.BASE_URL + "users/" + Config.username + "?key="
                    + Config.KEY;

            try {

                RestClient client = new RestClient(url);
                client.AddHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                try {
                    client.Execute(RestClient.RequestMethod.GET);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                mResponse = client.getResponse();

                if (mResponse != null) {
//                   Log.i("anisha", "ParseData_mResponse:" +mResponse);
                    JSONObject jObject = new JSONObject(mResponse);

                    first_name = jObject.getString("first_name");
                    last_name = jObject.getString("last_name");
                    username = jObject.getString("username");
                    balance = jObject.getString("balance");
                    charging_session = jObject.getString("charging_session");
                    account_number = jObject.getString("account_number");

                    myStatics = jObject.getString("statistics");

                    Log.v("myStatics", "" + myStatics);

                    JSONObject jStaticObject = new JSONObject(myStatics);

                    String total = jStaticObject.getString("total");

                    Log.v("total", "" + total);

                    JSONObject jTotalObject = new JSONObject(total);

                    enery_con = jTotalObject.getString("energy");
                    fuel_displaced = jTotalObject.getString("fuel_displaced");
                    co2_reduction = jTotalObject.getString("co2_reduction");

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            /**Display firstName,LastName,remBalance */


            firstName.setText("Welcome,  "+first_name+" "+last_name);
            remBalance.setText("$ " + setTwoDecimalPoint(balance));
            Config.ViewDismiss();

//            Log.i("anisha","GetChargingSessionData ParseData");
//            new GetChargingSessionData().execute();
        }
    }

    public class GetUserPaymentDetails extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
//            Config.ViewShow();
        }

        @Override
        protected String doInBackground(Void... params) {

            String url = Config.BASE_URL + "users/" + Config.username +"/payment_info"+ "?key="
                    + Config.KEY;

            try {

                RestClient client = new RestClient(url);
                client.AddHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                try {
                    client.Execute(RestClient.RequestMethod.GET);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                mResponse = client.getResponse();


//            Log.i("anisha","GetUserPaymentDetails :mResponse " + mResponse);
//                if (mResponse != null) {
//
//                }
                return mResponse;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String mResponse) {
            super.onPostExecute(mResponse);

            /**
             * If response is null,show the empty screen to enter the card details
             */
            if (mResponse.length()< 7){

                showAllCCViews();

            }else{
                /**
                 * If response is not null,show the card details
                 */

                String last4 = "";
                String method = "";
                try {
                    JSONObject jObject = new JSONObject(mResponse);

                    if (jObject!=null){
                        JSONObject creditcardObject = jObject.optJSONObject("creditcard");
                            if (creditcardObject!=null){
                                last4 = creditcardObject.optString("last4");
                            }
                        method = jObject.optString("method");
                    }else {

                    }

                if (TextUtils.isEmpty(last4)){
                    showAllCCViews();
                }else{

                   Config.ViewShow();
                    PaymentInfo f = new PaymentInfo();
                    Bundle args = new Bundle();
                    args.putString("title", "Payment Info");
                    args.putString("username", username);
                    args.putString("last4", last4);
                    args.putString("method", method);
                    f.setArguments(args);
                    ((ActivityInTab) getActivity()).navigateTo(f);
                }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void showAllCCViews() {
        Config.ViewShow();
        PaymentInfo f = new PaymentInfo();
        Bundle args = new Bundle();
        args.putString("title", "Payment Info");
        args.putString("username", username);

        f.setArguments(args);
        ((ActivityInTab) getActivity()).navigateTo(f);

    }


    private void formatingKWH(String eng) {
        try {
            int i = 1;
            int kw = (int) Float.parseFloat(eng);
            if (kw <= 999) {
                while (kw % 10 > 0) {
                    int j = kw % 10;
                    kw = kw / 10;
                    if (i == 1) {
                        kTV3.setText("" + j);
                    } else if (i == 2) {
                        kTV2.setText("" + j);
                    } else if (i == 3) {
                        kTV1.setText("" + j);
                    }
                    i++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void formatingMiles(String eng) {
        try {
            int i = 1;
            int kw = (int) Float.parseFloat(eng);
            if (kw <= 999) {
                while (kw % 10 > 0) {
                    int j = kw % 10;
                    kw = kw / 10;
                    if (i == 1) {
                        mlTV3.setText("" + j);
                    } else if (i == 2) {
                        mlTV2.setText("" + j);
                    } else if (i == 3) {
                        mlTV1.setText("" + j);
                    }
                    i++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class UpdateLocationDetail extends AsyncTask<Void, Void, Void> {

        StringBuilder locBuilder;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            Config.ViewShow();
//            Log.i("anisha","URL Server Check: "+Config.BASE_URL + "locations/" + location + "?key="
//                    + Config.KEY);
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            if (location != null) {
                String url = Config.BASE_URL + "locations/" + location + "?key="
                        + Config.KEY;

                try {

                    RestClient client = new RestClient(url);
                    client.AddHeader(
                            "Authorization",
                            "Basic "
                                    + Base64.encodeToString(
                                    Config.auth_para.getBytes(),
                                    Base64.NO_WRAP));
                    try {
                        client.Execute(RestClient.RequestMethod.GET);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    mResponse = client.getResponse();
                    Log.v("response ", "" + mResponse);

                    if (mResponse != null) {
                        JSONObject jObject = new JSONObject(mResponse);

                        if (jObject != null) {
                            String address1 = jObject.getString("address1");
                            String address2 = jObject.getString("address2");
                            String city = jObject.getString("city");
                            String state = jObject.getString("state");
                            String zip = jObject.getString("zip");

                            JSONArray jCords = jObject.getJSONArray("coordinates");
                            locBuilder = new StringBuilder();

                            locBuilder.append(jCords.getString(0));
                            locBuilder.append(",");
                            locBuilder.append(jCords.getString(1));

                            sb = new StringBuilder("");
                            if (address1.length() > 0) {
                                sb.append(address1);
                                sb.append(", ");
                            }
                            if (address2.length() > 0) {
                                sb.append(address2);
                                sb.append(", ");
                            }
                            if (city.length() > 0) {
                                sb.append(city);
                                sb.append(", ");
                            }
                            if (state.length() > 0) {
                                sb.append(state);
                                sb.append(", ");
                            }
                            if (zip.length() > 0) {
                                sb.append(zip);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            Config.ViewDismiss();
            try {
                mMyLocation.setText(sb.toString());
            } catch (Exception e) {

            }

            mFullLayout.setVisibility(ScrollView.VISIBLE);

            try {
                String url = "http://maps.googleapis.com/maps/api/staticmap?center="
                        + locBuilder.toString().trim()
                        + "&size="
                        + Config.mapSize
                        + "&zoom="
                        + "18"
                        + "&"
                        + "maptype=satellite"
                        + "&markers=size:large|color:yellow|"
                        + locBuilder.toString().trim() + "&sensor=false";

                new DownLoadImageTask().execute(url);
            } catch (Exception e) {

            }

        }
    }

    public class GetChargingSessionData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            Config.ViewShow();
//            Log.i("anisha","URL Server Check: "+Config.BASE_URL + "charging-sessions/"
//                    + charging_session + "?key=" + Config.KEY);
        }

        @Override
        protected Void doInBackground(Void... params) {
            if (charging_session != null) {
                String url = Config.BASE_URL + "charging-sessions/"
                        + charging_session + "?key=" + Config.KEY;
                try {

                    RestClient client = new RestClient(url);
                    client.AddHeader(
                            "Authorization",
                            "Basic "
                                    + Base64.encodeToString(
                                    Config.auth_para.getBytes(),
                                    Base64.NO_WRAP));

                    try {
                        client.Execute(RestClient.RequestMethod.GET);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    mResponse = client.getResponse();

                    Log.v("response ", "" + mResponse);
//                    Log.v("anisha", "GetChargingSessionData:Mresponse " + mResponse);
                    if (mResponse != null) {
//                        Log.v("anisha", "GetChargingSessionData:Mresponse " + mResponse);
                        JSONObject jObject = new JSONObject(mResponse);

                        location = jObject.getString("location");
                        status = jObject.getString("status");
                        cost = jObject.getString("cost");
                        time = jObject.getString("duration");

                        try {
                            String[] mTime = time.split(":");
                            int hour = Integer.parseInt(mTime[0]);
                            int min = Integer.parseInt(mTime[1]);
                            if (hour > 0) {
                                if (min > 0) {
                                    time = hour + " hr " + min + " min";
                                } else {
                                    time = "0";
                                }
                            } else {
                                if (min > 0 && min < 10) {
                                    time = min + " minute";
                                    if (min > 9) {
                                        time = min + " minutes";
                                    }
                                }
                            }
                        } catch (Exception e) {

                        }

                        energy = jObject.getString("energy");
                        JSONArray range = jObject.getJSONArray("approx_range");
                        app_range = range.get(0).toString();

                        // myStatics = jObject.getString("statistics");

                        JSONObject jsObject = jObject.getJSONObject("statistics");
                        JSONArray powerArray = jsObject.getJSONArray("power");
                        PowerList = new StringBuilder(powerArray.length());
                        for (int i = 0; i < powerArray.length(); i++) {
                            PowerList.append(powerArray.getString(i));
                            if (i == powerArray.length() - 1) {
                                //
                            } else {
                                PowerList.append(",");
                            }
                        }
                        Log.v("PowerList", "" + PowerList);

                        JSONArray timeArray = jsObject.getJSONArray("times");
                        timeList = new ArrayList<String>();
                        for (int i = 0; i < timeArray.length(); i++) {
                            timeList.add(i, timeArray.getString(i));
                        }
                        Log.v("timeList", "" + timeList);

                        JSONArray energyArray = jsObject.getJSONArray("energy");
                        energyList = new StringBuilder(energyArray.length());
                        for (int i = 0; i < energyArray.length(); i++) {
                            energyList.append(energyArray.getString(i));
                            if (i == energyArray.length() - 1) {
                                //
                            } else {
                                energyList.append(",");
                            }
                        }
                        Log.v("energyList", "" + energyList);
                    }
                } catch (Exception e) {

                    charging_flag = true;
                    e.printStackTrace();
                }
            } else if (mResponse == null || charging_session == null) {
                // No Recent Activity

            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            // TODO Auto-generated method stub
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            Config.ViewDismiss();
            if (mResponse == null || charging_session == null) {
                if(isAdded()){
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.norecentactivity));
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charged_noact_text_style);
                }

                chargeStatus.setText("NO RECENT ACTIVITY");

                energy = "0";
                enery_con = "0.00 kWh";
                co2_reduction = "0.00 Lbs.";
                mMyLocation.setText("No recent location to display");

                chargeCost.setVisibility(View.INVISIBLE);
                chargeTime.setVisibility(View.INVISIBLE);
            }
            try {

                formatingKWH(energy);
                formatingMiles(app_range);

//				firstName.setText("Welcome,  " + first_name + " " + last_name);
//				remBalance.setText("$ " + setTwoDecimalPoint(balance));
                chargeCost.setText("Total: $ " + String.format("%.2f", Float.parseFloat(cost)));
                chargeTime.setText("Status : " + time);

                mEnergyCon.setText(enery_con + " kWh");
                mGreenHouse.setText(co2_reduction + " Lbs.");

                if (status.equalsIgnoreCase("Charge-done")) {
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.chargedicon));
                    chargeStatus.setText("CHARGED");
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charged_text_style);
                    if (timeList.size() > 0 && timeList != null) {
                        mStartTimeTxt.setText(getTimeHourMin(timeList.get(0)));
                        mEndTimeTxt.setText(getTimeHourMin(timeList
                                .get(timeList.size() - 1)));
                    }

                } else if (status.equalsIgnoreCase("Charging")) {
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.charging));
                    chargeStatus.setText("CHARGING");
                    mSubCaption.setText("");
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charging_text_style);
                    if (timeList.size() > 0 && timeList != null) {
                        mStartTimeTxt.setText(getTimeHourMin(timeList.get(0)));
                        mEndTimeTxt.setText(getTimeHourMin(timeList
                                .get(timeList.size() - 1)));
                    }
                } else if (status.equalsIgnoreCase("fault")) {
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.chargingfault));
                    chargeStatus.setText("Charging Fault");
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charge_fault_text_style);
                    mSubCaption.setText("Charging Error");
                    mSubCaption.setVisibility(View.VISIBLE);
                    chargeTime.setText("Please call support for more details");
                    chargeCost.setVisibility(View.GONE);
                    noGraphRel.setVisibility(View.VISIBLE);
                    graphView.setVisibility(View.GONE);

                } else if (status.equalsIgnoreCase("complete")) {
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.completed));
                    chargeStatus.setText("COMPLETED");
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charged_text_style);
                    mSubCaption.setText("Session Complete");
                    mSubCaption.setVisibility(View.VISIBLE);
                } else if (status.equalsIgnoreCase("authorized")) {
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.authorized));
                    chargeStatus.setText("AUTHORIZED");
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charge_auth_text_style);
                    mSubCaption.setVisibility(View.VISIBLE);
                    mSubCaption.setText("Waiting for station");
                    chargeTime.setText("Make sure your vehicle is Pluged In");
                    chargeCost.setVisibility(View.GONE);

                    noGraphRel.setVisibility(View.VISIBLE);
                    graphView.setVisibility(View.GONE);
                    mNoDataMsg = "When your charging session begins the details will be displayed here.";
                    charging_flag = true;
                } else if (status.equalsIgnoreCase("timeout")) {
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.timeout));
                    chargeStatus.setText("TIME OUT");
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charge_fault_text_style);
                    noActBox.setVisibility(View.GONE);
                    mSubCaption.setText("No Plug-in detected");
                    mSubCaption.setVisibility(View.VISIBLE);
                    chargeCost
                            .setText("Please plug in your car and reauthorize this.");
                    chargeTime.setVisibility(View.GONE);
                    charging_flag = true;
                    mNoDataMsg = "When your charging session begins the details will be displayed here.";
                    noGraphRel.setVisibility(View.VISIBLE);
                    graphView.setVisibility(View.GONE);
                } else {
                    mNoDataMsg = "NO DATA";
                    charging_flag = true;
                    mChargeIcon.setBackgroundDrawable(getResources()
                            .getDrawable(R.drawable.informationerror));
                    chargeStatus.setTextAppearance(getActivity(),
                            R.style.charge_no_data_text_style);
                    mSubCaption.setText("Information Error");
                    mSubCaption.setVisibility(View.VISIBLE);
                    chargeCost.setText("Please check your connection");
                    chargeTime.setVisibility(View.GONE);
                    noGraphRel.setVisibility(View.VISIBLE);
                    graphView.setVisibility(View.GONE);
                }

                rotation.cancel();
                rotation.reset();

            } catch (Exception e) {
                e.printStackTrace();
                Config.ViewDismiss();
                rotation.cancel();
                rotation.reset();
                charging_flag = true;
                chargeStatus.setText("NO RECENT ACTIVITY");

                if(isAdded()){
                    mChargeIcon.setBackground(getResources().getDrawable(R.drawable.norecentactivity));
                    chargeStatus.setTextAppearance(getActivity(), R.style.charged_noact_text_style);
                }


                chargeCost.setVisibility(View.GONE);
                chargeTime.setVisibility(View.GONE);
                noActBox.setVisibility(View.VISIBLE);

                formatingKWH("0");
                formatingMiles("0");

            } finally {
                if (charging_flag) {
                    noGraphRel.setVisibility(View.VISIBLE);
                    mNoGraphDataMsg.setText(mNoDataMsg);
                    mStartTimeTxt.setText("");
                    mEndTimeTxt.setText("");
                } else {
                    showGraph();
                    charging_flag = false;
                }
                // noActBox.setVisibility(View.VISIBLE);
                new UpdateLocationDetail().execute();

            }

        }
    }

    private void showGraph() {
        try {
            if (charging_session != null) {
                if (PowerList.length() > 0 || energyList.length() > 0) {

					/*
					 * String mUrl = "http://chart.apis.google.com/chart?" +
					 * "cht=lc&" + "chs=" + resol + "&chd=t:" + PowerList + "|"
					 * + energyList + "&" + "chxr=1,0,4000|2,0.0000,2.9999&" +
					 * "chds=0,4000,0,0.2999&" + "chco=8dc63f,39b54a&" +
					 * "chls=5,1,0|3,1,3&" + "chg=0,6.67,5,5|.5,.5,.5";
					 */

                    String mUrl = "http://chart.googleapis.com/chart?"
                            + "chf=bg,lg,5,FFFFFF,0,FFFFFF,1&"
                            // + "chxl=0:|0|5|10|1:|0|5|10|15|2:|0|3|6|9&"
                            + "chxl=0:|0|0|1:|0|5|10|15|2:|0|3|6|9&"
                            + "chxr=1,0,15|2,0,10&"
                            + "chxs=0,000000,10,0.5,lt,000000|1,000000,10,0,lt,000000|2,000000,10,0,lt,000000&"
                            + "chxt=x,r,y&" + "chs=" + Config.chartSize + "&"
                            + "cht=lc&" + "chco=1BB241,00B327&"
                            + "chds=0,10,0,10,0,15&" + "chd=t:" + PowerList
                            + "|" + energyList + "&" + "chg=20,25,5,0&"
                            + "chls=4|2,3,5&" + "chma=5,5,5,5&"
                            + "chxs=2,000000,18|1,000000,18|0,000000,18";

//                    Log.v("anisha", "Graph : " + mUrl);

                    graphView.setVisibility(View.VISIBLE);
                    noGraphRel.setVisibility(View.GONE);

                    String HTML_SRC = "<img width=\"100%\"  src = \"";
                    String HTML_IMG = HTML_SRC.concat(mUrl).concat("\" />");

                    graphView.getSettings().setJavaScriptEnabled(true);
                    graphView.getSettings().setDefaultZoom(
                            WebSettings.ZoomDensity.FAR);

                    graphView.loadDataWithBaseURL("", HTML_IMG, "text/html", "UTF-8", "");
                    //graphView.loadUrl(mUrl);

                    graphView.setWebViewClient(new MyWebView());

                    if (timeList.size() > 0 && timeList != null) {
                        mStartTimeTxt.setText(getTimeHourMin(timeList.get(0)));
                        mEndTimeTxt.setText(getTimeHourMin(timeList
                                .get(timeList.size() - 1)));
//                        Log.v("anisha", "ShowGraph : " + timeList.size() +timeList +timeList +mEndTimeTxt +mNoDataMsg +graphView);
                    }
                }
            } else {
                graphView.setVisibility(View.GONE);
                noGraphRel.setVisibility(View.VISIBLE);
                mNoGraphDataMsg.setText(mNoDataMsg);
            }

        } catch (Exception e) {
            graphView.setVisibility(View.GONE);
            noGraphRel.setVisibility(View.VISIBLE);
            mNoGraphDataMsg.setText(mNoDataMsg);
        }

    }

    private class MyWebView extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private String getTimeHourMin(String time) {
        long miliTime = Long.parseLong(time);

        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                "Aug", "Sep", "Oct", "Nov", "Dec"};

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(miliTime * 1000);
        Date date = new Date(miliTime * 1000);
        SimpleDateFormat sdf = new SimpleDateFormat("K:mm a");

        String formattedTime = sdf.format(date);

		/*int mHour = cal.get(Calendar.HOUR);
		int mMIn = cal.get(Calendar.MINUTE);*/
//		String am_pm = cal.get(Calendar.AM_PM) == 0 ? " am" : " pm";

        int day = cal.get(Calendar.DATE);
        String month = months[cal.get(Calendar.MONTH)];

		/*return month + " " + day + ", " + mHour + ":"
				+ (mMIn < 10 ? "0" + mMIn : mMIn) + am_pm;*/
        return month + " " + day + ", " + formattedTime;
    }

    private class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {

        private Bitmap bMap;
        ProgressBar pBar;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            Config.ViewShow();
//            pBar = (ProgressBar) view.findViewById(R.id.login_web_progress);
//            pBar.setVisibility(View.GONE);

        }

        @Override
        protected Bitmap doInBackground(String... params) {
            return loadImgFromNetwork(params[0]);
        }

        public Bitmap loadImgFromNetwork(String url) {

            Log.d("ImageManager", "download begining");
            Log.d("ImageManager", "download url:" + url);

            try {
                URL imgurl = new URL(url);
                URLConnection ucon = imgurl.openConnection();
                if (ucon == null) {
                    //Do nothing
                }
                InputStream is = ucon.getInputStream();
                BufferedInputStream bis = new BufferedInputStream(is);

                bMap = BitmapFactory.decodeStream(bis);

                if (is != null) {
                    is.close();
                }
                if (bis != null) {
                    bis.close();
                }
            } catch (IOException e) {
                e.printStackTrace();

//                pBar.setVisibility(View.GONE);
            }

            return bMap;
        }

        protected void onPostExecute(Bitmap result) {
            Config.ViewDismiss();
            if (result != null) {
                mWebView.setScaleType(ScaleType.CENTER_CROP);
                mWebView.setImageBitmap(result);

            }
//            pBar.setVisibility(View.GONE);
        }
    }

    private String setTwoDecimalPoint(String txtAmt) {
        BigDecimal roundedBigDecimal = new BigDecimal(0.0);
        try{
            BigDecimal bigDecimal = new BigDecimal(txtAmt);
            roundedBigDecimal = bigDecimal.setScale(2,
                    RoundingMode.HALF_UP);
        }catch (Exception e){
            roundedBigDecimal = new BigDecimal(0.0);
        }

        return "" + roundedBigDecimal;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        stopRepeatingTask();
    }

    Runnable mStatusChecker = new Runnable() {
        @Override
        public void run() {
            try {
//                Log.i("anisha","mStatusChecker ParseData call");
                new ParseData().execute();

            } finally {
                // 100% guarantee that this always happens, even if
                // your update method throws an exception
                mHandler.postDelayed(mStatusChecker, mInterval);

            }
        }
    };

    void startRepeatingTask() {
        mStatusChecker.run();
    }

    void stopRepeatingTask() {
        mHandler.removeCallbacks(mStatusChecker);
    }

    Handler handler1 = new Handler() {
        public void handleMessage(android.os.Message msg) {

            checkParaWithoutCharging();

            swipeView.postDelayed(new Runnable() {

                @Override
                public void run() {
//                    Toast.makeText(getActivity(),
//                            "My Account got refreshed !!!", Toast.LENGTH_SHORT).show();
//                    Log.i("anisha","GetChargingSessionData swipeView.postDelayed(");
                    new GetChargingSessionData().execute();
            swipeView.setRefreshing(false);
                }
            }, 1000);
        };
    };
    @Override
    public void onRefresh() {

        swipeView.postDelayed(new Runnable() {

            @Override
            public void run() {
                swipeView.setRefreshing(true);
                handler1.sendEmptyMessage(0);
//                new GetChargingSessionData().execute();
//                new ParseData().execute();
            }
        }, 1000);
    }

    private void checkPara() {

        settings = getActivity().getSharedPreferences("session_auth", 0);

        userName = settings.getString("username", "");
        password = settings.getString("password", "");

        if (userName.length() == 0 || userName.equals("")) {
            Toast.makeText(getActivity(), "Please provide a valid Username or Email.", Toast.LENGTH_SHORT).show();
        }else if( password.length() == 0 || password.equals("")){

            Toast.makeText(getActivity(), "Please provide a valid password.", Toast.LENGTH_SHORT).show();
        }else {
            Bundle args = new Bundle();
            args.putString("username", userName);

            new GetData().execute();
        }
    }

    private void checkParaWithoutCharging() {

        settings = getActivity().getSharedPreferences("session_auth", 0);

        userName = settings.getString("username", "");
        password = settings.getString("password", "");

        if (userName.length() == 0 || userName.equals("")) {
            Toast.makeText(getActivity(), "Please provide a valid Username or Email.", Toast.LENGTH_SHORT).show();
        }else if( password.length() == 0 || password.equals("")){

            Toast.makeText(getActivity(), "Please provide a valid password.", Toast.LENGTH_SHORT).show();
        }else {
            Bundle args = new Bundle();
            args.putString("username", userName);

            new GetDataWithoutCharging().execute();
        }
    }

    class GetDataWithoutCharging extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            Config.ViewShow();
            Log.i("anisha","URL Server Check: "+Config.BASE_URL
                    + "http-sessions?key=" + Config.KEY+ "("+ userName + ":"
                    + password +")");
        }

        @Override
        protected Void doInBackground(Void... params) {

            try {
                mResponse = RestClient.postHTPPRequest(Config.BASE_URL
                        + "http-sessions?key=" + Config.KEY, userName + ":"
                        + password);

                if (mResponse != null) {
//                    Log.v("anisha", "GetData:mResponse" + mResponse);
                    JSONObject jObject = new JSONObject(mResponse);

                    Config.username = jObject.getString("username");
                    Config.pwd = password;

                    Config.auth_para = Config.username + ":" + Config.pwd;
                    Log.v("Config.auth_para", "" + Config.auth_para);

                    Config.sid = jObject.getString("id");
                    Config.expires = jObject.getString("expires");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            Config.ViewDismiss();

            if (Config.username.equals("") || Config.sid.equals("")){
                if(isAdded() && Config.loginButtonClicked) {
                    Toast.makeText(getActivity(),
                            getResources().getString(R.string.invalid_crdential),
                            Toast.LENGTH_SHORT).show();

                }
                if (Config.mStatusCode == 401 && mResponse != null) {
                    Config.loginChk = false;
                    deleteValuesFromSharedPreference();
                }

                HomeScreen f = new HomeScreen();
                Bundle args = new Bundle();
                args.putString("title", "My Account");
                f.setArguments(args);
                ((ActivityInTab) getActivity()).navigateWithoutBack(f);
            } else {
                if (Config.mStatusCode == 200 && mResponse != null) {
                    Config.loginChk = true;
                    editor = settings.edit();
                    editor.putString("username", Config.username);
                    editor.putString("password", Config.pwd);
                    editor.commit();
//                    Log.i("anisha","GetData ParseData call");
                    new ParseDataWithoutCharging().execute();
                } else {
                    Toast.makeText(getActivity(), mResponse, Toast.LENGTH_SHORT)
                            .show();
                    deleteValuesFromSharedPreference();

                    HomeScreen f = new HomeScreen();
                    Bundle args = new Bundle();
                    args.putString("title", "My Account");
                    f.setArguments(args);
                    ((ActivityInTab) getActivity()).navigateWithoutBack(f);
                }
            }
        }
    }

    class GetData extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            Config.ViewShow();
            Log.i("anisha","URL Server Check: "+Config.BASE_URL
                    + "http-sessions?key=" + Config.KEY+ "("+ userName + ":"
                    + password +")");
        }

        @Override
        protected Void doInBackground(Void... params) {

            try {
                mResponse = RestClient.postHTPPRequest(Config.BASE_URL
                        + "http-sessions?key=" + Config.KEY, userName + ":"
                        + password);

                if (mResponse != null) {
//                    Log.v("anisha", "GetData:mResponse" + mResponse);
                    JSONObject jObject = new JSONObject(mResponse);

                    Config.username = jObject.getString("username");
                    Config.pwd = password;

                    Config.auth_para = Config.username + ":" + Config.pwd;
                    Log.v("Config.auth_para", "" + Config.auth_para);

                    Config.sid = jObject.getString("id");
                    Config.expires = jObject.getString("expires");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            Config.ViewDismiss();

            if (Config.username.equals("") || Config.sid.equals("")){
                if(isAdded() && Config.loginButtonClicked) {
                    Toast.makeText(getActivity(),
                            getResources().getString(R.string.invalid_crdential),
                            Toast.LENGTH_SHORT).show();

                }
                if (Config.mStatusCode == 401 && mResponse != null) {
                    Config.loginChk = false;
                    deleteValuesFromSharedPreference();
                }

                HomeScreen f = new HomeScreen();
                Bundle args = new Bundle();
                args.putString("title", "My Account");
                f.setArguments(args);
                ((ActivityInTab) getActivity()).navigateWithoutBack(f);
            } else {
                if (Config.mStatusCode == 200 && mResponse != null) {
                    Config.loginChk = true;
                    editor = settings.edit();
                    editor.putString("username", Config.username);
                    editor.putString("password", Config.pwd);
                    editor.commit();
                    Log.i("anisha","GetData ParseData call");
                    new ParseData().execute();
                } else {
                    Toast.makeText(getActivity(), mResponse, Toast.LENGTH_SHORT)
                            .show();
                    deleteValuesFromSharedPreference();

                    HomeScreen f = new HomeScreen();
                    Bundle args = new Bundle();
                    args.putString("title", "My Account");
                    f.setArguments(args);
                    ((ActivityInTab) getActivity()).navigateWithoutBack(f);
                }
            }
        }
    }

    private void deleteValuesFromSharedPreference() {
        settings = getActivity().getSharedPreferences("session_auth", 0);
        editor = settings.edit();
        editor.remove("username");
        editor.remove("password");
        editor.putBoolean("showLogin", true);
        editor.putBoolean("donotshowMA", false);
        editor.commit();
    }

}
