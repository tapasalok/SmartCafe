package com.semaconnect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.regex.Pattern;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
import com.semaconnect.utility.Config;

public class ForgetPassword extends Fragment implements OnEditorActionListener {

	ViewGroup view;

	private String mEntity;
	private LinearLayout mMsgBox, mErrBox;
	private TextView mLblEmail;

	private String mResponse = "";
	private int mResponse_code;

	private final String ACTION_DIAL = "android.intent.action.DIAL";
	private final Pattern EMAIL_ADDRESS_PATTERN = Pattern
			.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@"
					+ "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\."
					+ "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+");

	private ImageButton mSendResetInstrucion, mCallSupport;
	private EditText mEmailTxt;
	private boolean mEmailFlag;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater.inflate(R.layout.lost_passwd, container,
				false);
		view.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));

		return view;
	}

	private boolean checkEmail(String email) {
		return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		initView();

		Config.ViewDismiss();

		mCallSupport.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Start Default Calling Application
				startActivity(new Intent(ACTION_DIAL, Uri
						.parse("tel:6365551212")));
			}
		});

		mSendResetInstrucion.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Send Email Reset Instruction

				mEmailFlag = checkEmail(mEmailTxt.getText().toString());
				if (mEmailFlag) {
					mEntity = "{\"email\":" + "\""
							+ mEmailTxt.getText().toString() + "\"}";

					new ParseData().execute();
				} else {

					Toast.makeText(getActivity(), "Please provide a valid Email.",
							Toast.LENGTH_SHORT).show();

				}
			}
		});

	}

	private void initView() {

		TextView titleTxt = (TextView) view.findViewById(R.id.top_title_txt);
		Bundle args = getArguments();
		titleTxt.setText(args.get("title").toString());

		mSendResetInstrucion = (ImageButton) view
				.findViewById(R.id.lostpass_reset);
		mCallSupport = (ImageButton) view
				.findViewById(R.id.lostpass_callsupport);

		mEmailTxt = (EditText) view.findViewById(R.id.lostpass_email);
		mEmailTxt.setOnEditorActionListener(this);

		mMsgBox = (LinearLayout) view.findViewById(R.id.lost_pass_msg_box);
		mErrBox = (LinearLayout) view.findViewById(R.id.lost_pass_error_box);

//		mTVErrMsg = (TextView) view.findViewById(R.id.lost_pass_error_msg);
		mLblEmail = (TextView) view.findViewById(R.id.lost_pass_lable_email);

		mMsgBox.setVisibility(View.VISIBLE);
		mErrBox.setVisibility(View.GONE);
		mLblEmail.setTextAppearance(getActivity(), R.style.normal_text_style);

	}

	public class ParseData extends AsyncTask<Void, Void, Void> {

		String email_res = "";

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			Config.ViewShow();
		}

		@Override
		protected Void doInBackground(Void... params) {

			String url = Config.BASE_URL + "passwords?key=" + Config.KEY;

			Log.v("url", "" + url);

			try {

				HttpPost httpost = new HttpPost(url);
				httpost.setEntity(new StringEntity(mEntity));
				// httpost.setHeader("Content-Type", "application/json");
				httpost.setHeader("Content-Type",
						"application/x-www-form-urlencoded");

				Log.v("ENTITY", "" + mEntity);

				HttpResponse httpResponse = null;

				if (Config.client != null) {
					httpResponse = Config.client.execute(httpost);
				} else {
					httpResponse = Config.getThreadSafeClient()
							.execute(httpost);
				}

				mResponse_code = httpResponse.getStatusLine().getStatusCode();

				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					// byte[] Data = new byte[256];
					// int len = 0;
					InputStream input = null;
					input = entity.getContent();
					mResponse = convertStreamToString(input);

					input.close();

					if (mResponse != null) {

						JSONObject json = new JSONObject(mResponse);

						Iterator keys = json.keys();

						email_res = json.getString("email");

						Log.v("Response", ">>>" + email_res + mResponse_code
								+ "**" + mResponse);

					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onProgressUpdate(Void... values) {
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);

			Config.ViewDismiss();

			if (mResponse_code == 202) {
				showSuccessDialog("Success", mResponse);

			} else {
				showDialog("Email", email_res);

			}

			mEmailTxt.setText("");

		}
	}

	private static String convertStreamToString(InputStream is) {
//		Log.i("Inside convertstream method", "hello");
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	public void showSuccessDialog(String title, String message) {
		AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
		alert.setTitle("Password reset instructions.");
		alert.setIcon(R.drawable.ic_launcher);
		alert.setMessage(message);
		alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				Config.toggle(getActivity());
			}
		});

		alert.create();
		alert.show();

		mMsgBox.setVisibility(View.VISIBLE);
		mErrBox.setVisibility(View.GONE);
	}

	public void showDialog(String title, String message) {

		AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
		alert.setTitle("Account not found!");
		alert.setMessage(message);
		alert.setIcon(R.drawable.ic_launcher);

		alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

				dialog.dismiss();

			}
		});

		alert.create();
		alert.show();
		mMsgBox.setVisibility(View.GONE);
		mErrBox.setVisibility(View.VISIBLE);
//		mTVErrMsg.setText(message);
		mLblEmail.setTextAppearance(getActivity(), R.style.error_text);
	}

	@Override
	public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		if (actionId == EditorInfo.IME_ACTION_SEND) {

//			InputMethodManager imm = (InputMethodManager) v.getContext()
//					.getSystemService(Context.INPUT_METHOD_SERVICE);
//			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

			mEmailFlag = checkEmail(mEmailTxt.getText().toString());
			if (mEmailFlag) {
				mEntity = "{\"email\":" + "\"" + mEmailTxt.getText().toString()
						+ "\"}";

				new ParseData().execute();
				return true;
			} else {

				AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
				alert.setTitle("Forgot password!");
				alert.setIcon(R.drawable.ic_launcher);
				alert.setMessage("Please provide valid details.");
				alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
				return false;
			}

		}
		return false;
	}
}
