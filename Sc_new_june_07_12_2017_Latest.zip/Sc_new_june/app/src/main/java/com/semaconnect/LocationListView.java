package com.semaconnect;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.semaconnect.utility.Config;

import java.util.ArrayList;

public class LocationListView extends Activity {

	private static ListView mListView;
	private static LocListAdapter locListAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		Log.i("anisha", "keyboard14");
		setContentView(R.layout.location_list);
		initView();
		TextView titleTxt = (TextView) findViewById(R.id.top_title_txt);

		Bundle args = getIntent().getExtras();
		titleTxt.setText(args.get("title").toString());
		showList();
	}

	private void initView() {
		mListView = (ListView) findViewById(R.id.location_listview);
		mListView.setDivider(null);
		mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int pos,
					long arg3) {

                Config.listButtonClicked = false;
				Intent i = new Intent(getParent(), StationDetails.class);
				i.putExtra("title", "Location Details");
				i.putExtra("id", MapScreen.mData.get(pos).get(0));
				i.putExtra("name", MapScreen.mData.get(pos).get(1));
				i.putExtra("miles", MapScreen.mData.get(pos).get(7));
				i.putExtra("lat", MapScreen.mData.get(pos).get(9));
				i.putExtra("longi", MapScreen.mData.get(pos).get(10));

				i.putExtra("total", MapScreen.mAvail.get(pos).get(0));
				i.putExtra("status", MapScreen.mAvail.get(pos).get(1));
				i.putExtra("available", MapScreen.mAvail.get(pos).get(2));

				TabGroupActivity parentActivity = (TabGroupActivity) getParent();
				parentActivity.startChildActivity("station_detail", i);
			}
		});

	}

	@Override
	protected void onResume() {
		super.onResume();
		Config.listButtonClicked = true;
//		Log.i("anisha", "keyboard15");
	}

	private void showList() {
//		Log.i("anisha", "keyboard16");
		Log.v("anisha", "ListView :"+ mListView+ MapScreen.mData);

		if (mListView != null) {
			if (MapScreen.mData.size() > 0) {

			/*
			*  Removing duplicates starts here
			* */
//				ArrayList<ArrayList<String>> mData1 = new ArrayList<>();
//				for(ArrayList<String> tempArrayList : MapScreen.mData){
//					if(!mData1.contains(tempArrayList)){
//						mData1.add(tempArrayList);
//					}
//				}
//				MapScreen.mData = mData1;
//
//
//				ArrayList<ArrayList<String>> mDataAvail = new ArrayList<>();
//				for(ArrayList<String> mAvailArrayList : MapScreen.mAvail){
//					if(!mDataAvail.contains(mAvailArrayList)){
//						mDataAvail.add(mAvailArrayList);
//					}
//				}
//				MapScreen.mAvail = mDataAvail;


			/*
			*  Removing duplicates ends here
			* */

				locListAdapter = new LocListAdapter(getParent());
				mListView.setAdapter(locListAdapter);

				Log.i("anisha","Number of Stations in List: "+mListView.getCount());
			}
		}
		Config.ViewDismiss();
	}

	private class LocListAdapter extends BaseAdapter {

		private LayoutInflater mInflater;
		Context mCtx;

		public LocListAdapter(Context ctx) {
			mCtx = ctx;
			mInflater = LayoutInflater.from(mCtx);
		}

		@Override
		public int getCount() {
			return MapScreen.mData.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;

			if (convertView == null || convertView.getTag() == null) {
				convertView = mInflater.inflate(R.layout.list_view, null);
				holder = new ViewHolder();

				holder.milesTxt = (TextView) convertView
						.findViewById(R.id.list_milesTxt);
				holder.titleTxt = (TextView) convertView
						.findViewById(R.id.list_title);
				holder.addTxt1 = (TextView) convertView
						.findViewById(R.id.list_address1);
				holder.addTxt2 = (TextView) convertView
						.findViewById(R.id.list_address2);
				holder.timeTxt = (TextView) convertView
						.findViewById(R.id.list_time);
				holder.avail = (TextView) convertView.findViewById(R.id.list_);
				holder.pinImg = (ImageView) convertView
						.findViewById(R.id.list_greenimg);

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			Log.i("anisha","Number of Stations in ListView: "+MapScreen.mData.size());

//			for (ArrayList<String> duplicateCheck: MapScreen.mData){
////                for (String duplicateCheckString : duplicateCheck){
//                    Log.i("anishaStations","Stations in mData: "+duplicateCheck.toString());
////                }
//            }

			if (MapScreen.mData.size() > 0) {

				holder.milesTxt.setText(MapScreen.mData.get(position).get(7));
				holder.titleTxt.setText(MapScreen.mData.get(position).get(1));
				holder.addTxt1.setText(MapScreen.mData.get(position).get(2));
				holder.addTxt2.setText(MapScreen.mData.get(position).get(4)
						+ ", " + MapScreen.mData.get(position).get(5) + ", "
						+ MapScreen.mData.get(position).get(6));
				holder.avail.setText(MapScreen.mAvail.get(position).get(2)
						+ "/" + MapScreen.mAvail.get(position).get(0));

				holder.timeTxt.setText(MapScreen.mData.get(position).get(8));
			}

			return convertView;
		}
	}

	static class ViewHolder {
		TextView milesTxt;
		TextView titleTxt;
		TextView addTxt1, addTxt2;
		TextView timeTxt, avail;
		ImageView pinImg;
	}

	public static void refreshList() {
//		Log.i("anisha", "keyboard17");
		if (locListAdapter !=null){
			locListAdapter.notifyDataSetChanged();
		}

		if (mListView !=null){
			mListView.invalidateViews();
		}
	}


}
