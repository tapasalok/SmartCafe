package com.semaconnect.utility;

import android.content.Context;
import android.util.AttributeSet;

import com.google.android.maps.MapView;

public class MyMapView extends MapView {

	private MapViewListener mMapViewListener;

	public MapViewListener getMapViewListener() {
		return mMapViewListener;
	}

	public void setMapViewListener(MapViewListener value) {
		mMapViewListener = value;
	}

	public MyMapView(Context context, String apiKey) {
		super(context, apiKey);

	}

	public MyMapView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyMapView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

	}

	
}
