package com.semaconnect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

public class StackHome extends ActivityInTab {
   private SharedPreferences settings;
   private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        settings = getSharedPreferences("session_auth", 0);
        editor = settings.edit();

        navigateTo(new HomeScreen());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        Toast.makeText(this, "onBackPressed !!!", Toast.LENGTH_SHORT).show();
        editor.putBoolean("chargeNowClick", false);
        editor.putBoolean("chargeNowSelectStation", false);
        editor.putBoolean("chargeNow", false);
        editor.putBoolean("donotshowMA", false);
        editor.commit();
    }
}