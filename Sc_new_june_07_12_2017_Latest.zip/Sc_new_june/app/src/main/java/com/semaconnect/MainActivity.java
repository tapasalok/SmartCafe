package com.semaconnect;

import android.os.Bundle;

public class MainActivity extends TabsFragmentActivity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
