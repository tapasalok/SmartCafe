package com.semaconnect;

import android.os.Bundle;

public class StackGallery extends ActivityInTab {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		navigateTo(new ImageActivity());
	}
	
	
}
