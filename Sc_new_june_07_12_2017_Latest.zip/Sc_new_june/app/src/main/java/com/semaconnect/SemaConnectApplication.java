package com.semaconnect;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

/**
 * Created by anisha on 6/13/2017.
 */

public class SemaConnectApplication extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
}
