package com.semaconnect.utility;




import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.semaconnect.R;
import java.util.ArrayList;
import java.util.List;


public class GmailFrom extends Fragment {
    private Button button;
    private EditText name;
    private EditText email;
    private EditText street;
    private EditText city;
    private EditText zip;
    private EditText state;
    private EditText comments;
    private EditText propertyname;
    private Spinner propertytype;
    private TextView title_email,title_city,title_street,title_state,title_zip;
    private TextView mTitle;
    ViewGroup view;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (container == null) {
            return null;
        }
        view = (ViewGroup) inflater.inflate(R.layout.gmailform, container, false);
        view.setLayoutParams(new ViewGroup.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));

        return view;
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
        button = (Button) view.findViewById(R.id.button);
        name = (EditText) view.findViewById(R.id.editText);
        email = (EditText) view.findViewById(R.id.editText1);
        street = (EditText) view.findViewById(R.id.editText3);
        city = (EditText) view.findViewById(R.id.editText2);
        zip = (EditText) view.findViewById(R.id.editText5);
        state = (EditText) view.findViewById(R.id.editText4);
        comments = (EditText) view.findViewById(R.id.editText6);
        propertyname = (EditText) view.findViewById(R.id.editText7);
        propertytype = (Spinner) view.findViewById(R.id.spinner);
        title_email = (TextView) view.findViewById(R.id.title_email);
        title_street = (TextView) view.findViewById(R.id.title_street);
        title_city = (TextView) view.findViewById(R.id.title_city);
        title_state = (TextView) view.findViewById(R.id.title_state);
        title_zip = (TextView) view.findViewById(R.id.title_zip);
        mTitle = (TextView) view.findViewById(R.id.top_title_txt);
        mTitle.setText(R.string.suggest_location);


        List<String> list = new ArrayList<String>();

        list.add("Business");
        list.add("Commercial");
        list.add("Residential");
        list.add("Parking Lot");
        list.add("Others");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.simple_spinner_item, list);

        dataAdapter.setDropDownViewResource
                (android.R.layout.simple_spinner_dropdown_item);

        propertytype.setAdapter(dataAdapter);
        // Spinner item selection Listener
        addListenerOnSpinnerItemSelection();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
            }

        });
    }

// Add spinner data

    public void addListenerOnSpinnerItemSelection() {

        propertytype.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }

    private void sendEmail() {
        String name1 = name.getText().toString();
        String emailid = email.getText().toString();
        String street1 = street.getText().toString();
        String city1 = city.getText().toString();
        String zip1 = zip.getText().toString();
        String state1 = state.getText().toString();
        String cmts1 = comments.getText().toString();
        String propertyname1 = propertyname.getText().toString();
        String spinner1 = propertytype.getSelectedItem().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        String mailContent = "";
        String mailContentproperty = "";
        String mailContentlocation = "";
        String comments = "";


        if (TextUtils.isEmpty(name1)) {

        } else {
            mailContent =  "\n " + name1;
        }

        if (emailid.matches(emailPattern) && emailid.length() > 0) {
            mailContent = mailContent + "\n " + emailid;
            title_email.setTextAppearance(getActivity(), R.style.normal_text_style);
        } else {

            title_email.setTextAppearance(getActivity(), R.style.error_text);
            Toast.makeText(getActivity(), "Please provide a valid Email.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(street1)) {
            title_street.setTextAppearance(getActivity(), R.style.error_text);
            Toast.makeText(getActivity(), "Please provide the Address.", Toast.LENGTH_SHORT).show();
            return;
        } else {
            mailContentlocation =   "\n " + street1;
            title_street.setTextAppearance(getActivity(), R.style.normal_text_style);
        }
        if (TextUtils.isEmpty(city1)) {
            title_city.setTextAppearance(getActivity(), R.style.error_text);
            Toast.makeText(getActivity(), "Please provide the City.", Toast.LENGTH_SHORT).show();
            return;
        } else {
            mailContentlocation = mailContentlocation + "\n " + city1;
            title_city.setTextAppearance(getActivity(), R.style.normal_text_style);
        }
        if (TextUtils.isEmpty(state1)) {
            title_state.setTextAppearance(getActivity(), R.style.error_text);
            Toast.makeText(getActivity(), "Please provide the State.", Toast.LENGTH_SHORT).show();
            return;
        } else {
            mailContentlocation = mailContentlocation + "\n " + state1;
            title_state.setTextAppearance(getActivity(), R.style.normal_text_style);
        }
        if (TextUtils.isEmpty(zip1)) {

            title_zip.setTextAppearance(getActivity(), R.style.error_text);
            Toast.makeText(getActivity(), "Please provide the Zipcode.", Toast.LENGTH_SHORT).show();
            return;
        } else {
            mailContentlocation = mailContentlocation + "\n " + zip1;
            title_zip.setTextAppearance(getActivity(), R.style.normal_text_style);
        }

        if (TextUtils.isEmpty(cmts1)) {

        } else {
            comments =  "\n " + cmts1;
        }
        if (TextUtils.isEmpty(propertyname1)) {

        } else {
            mailContentproperty = "\n " + propertyname1;
        }
        if (TextUtils.isEmpty(spinner1)) {

        } else {
            mailContentproperty = mailContentproperty + "\n " + spinner1;
        }

        Uri uri = Uri.parse("mailto:suggest@semaconnect.com");
        Intent myActivity2 = new Intent(Intent.ACTION_SENDTO, uri);
        myActivity2.putExtra(Intent.EXTRA_SUBJECT,
                "Suggest Location");


        myActivity2.putExtra(Intent.EXTRA_TEXT,"Contact Details" + mailContent + "\n\n"+ "PropertyDetails(Name & Type)"+
                mailContentproperty +  "\n\n" + "Location Details" + mailContentlocation +"\n\n"+ comments + "\n\n" +
               "I believe having an EV Station at this location would make a lot of EV Drivers happy and inviting.");


        try {
            startActivity(myActivity2);

            Log.i("Sema" + "semaconnect", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getActivity(), "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }

    }

}
