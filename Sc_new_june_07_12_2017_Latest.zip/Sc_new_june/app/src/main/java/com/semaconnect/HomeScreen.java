package com.semaconnect;

import org.json.JSONObject;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.semaconnect.utility.Config;
import com.semaconnect.utility.RestClient;

public class HomeScreen extends Fragment {

	ViewGroup view;
	private EditText mUserName;
	private EditText mPassword;

	private String mResponse;
	InputMethodManager imm;

	SharedPreferences settings;
	SharedPreferences.Editor editor;

	String userName;
	String password;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater.inflate(R.layout.myaccount, container,
				false);
		view.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));

		imm = (InputMethodManager) getActivity().getSystemService(
				Context.INPUT_METHOD_SERVICE);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		Config.ViewDismiss();

		settings = getActivity().getSharedPreferences("session_auth", 0);

		mUserName = (EditText) view.findViewById(R.id.my_account_uname);
		mPassword = (EditText) view.findViewById(R.id.my_account_passwd);

		ImageButton forgetPassBtn = (ImageButton) view
				.findViewById(R.id.my_account_forpass);
		forgetPassBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				ForgetPassword f = new ForgetPassword();
				Bundle args = new Bundle();
				args.putString("title", "Forgot Password");
				f.setArguments(args);
				((ActivityInTab) getActivity()).navigateTo(f);
			}
		});

		ImageButton signUpBtn = (ImageButton) view
				.findViewById(R.id.my_account_signup);
		signUpBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {

				Config.ViewShow();

				SignUp f = new SignUp();
				Bundle args = new Bundle();
				args.putString("title", "Signup");
				f.setArguments(args);
				((ActivityInTab) getActivity()).navigateTo(f);
			}
		});

		ImageButton loginBtn = (ImageButton) view
				.findViewById(R.id.my_account_login);
		loginBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Config.loginButtonClicked = true;
				Log.i("anisha" , "username" + mUserName + "password"+ mPassword  );
				imm.hideSoftInputFromWindow(mUserName.getWindowToken(), 0);
				imm.hideSoftInputFromWindow(mPassword.getWindowToken(), 0);

					checkPara();

			}
		});

		try {
			String user = settings.getString("username", "");
			Log.v("User ::: ", "" + user);
				if (user.length() > 0) {
					Config.loginChk = true;
					checkPara();
				}
		} catch (Exception e) {
			e.printStackTrace();
			Config.loginChk = false;
		}
	}


    private void resetValues() {
        mUserName.setText("");
        mPassword.setText("");
    }
    //Display MyAccount page
    private void switchToNext() {

		try {
			getFragmentManager().popBackStack();
			MyAccount f = new MyAccount();
			Bundle args = new Bundle();
			args.putString("title", "MyAccount");
			f.setArguments(args);
			((ActivityInTab) getActivity()).navigateTo(f);
			resetValues();
		} catch (Exception e) {

		}
	}

    @Override
    public void onResume() {
        super.onResume();


        /** check showLogin preference whether to show login page or not if true do nothing.
         * If false, directly enter into the next page without showing the login page */
        boolean showLogin = settings.getBoolean("showLogin", true);
        if (!showLogin) {
            try {
                String user = settings.getString("username", "");
                Log.v("User ::: ", "" + user);
                if (user.length() > 0) {
                    Config.loginChk = true;

//                    editor = settings.edit();
//                    editor.putBoolean("showLogin", false);
//                    editor.commit();

					checkPara();
				}
			} catch (Exception e) {
				e.printStackTrace();
				Config.loginChk = false;
			}
		}
	}

	@Override
	public void onDetach() {
		super.onDetach();
	}

	private void checkPara() {

		if (!Config.loginChk) {
			userName = mUserName.getText().toString();
			password = mPassword.getText().toString();
		} else {
			userName = settings.getString("username", "");
			password = settings.getString("password", "");
		}

		if (userName.length() == 0 || userName.equals("")) {

			Toast.makeText(getActivity(), "Please provide a valid Username or Email.", Toast.LENGTH_SHORT).show();
		}else if( password.length() == 0 || password.equals("")){
            mPassword.requestFocus();
			Toast.makeText(getActivity(), "Please provide a valid password.", Toast.LENGTH_SHORT).show();
		}else {
			Bundle args = new Bundle();
				args.putString("username", userName);

				new GetData().execute();
		}

	}

	class GetData extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			Config.ViewShow();
		}

		@Override
		protected Void doInBackground(Void... params) {

			try {
				mResponse = RestClient.postHTPPRequest(Config.BASE_URL
						+ "http-sessions?key=" + Config.KEY, userName + ":"
						+ password);

				if (mResponse != null) {

					JSONObject jObject = new JSONObject(mResponse);

					Config.username = jObject.getString("username");
					Config.pwd = password;

					Config.auth_para = Config.username + ":" + Config.pwd;
					Log.v("Config.auth_para", "" + Config.auth_para);

					Config.sid = jObject.getString("id");
					Config.expires = jObject.getString("expires");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);

			Config.ViewDismiss();
			editor = settings.edit();
			editor.putBoolean("chargeNow", false);
			editor.commit();

			if (Config.username.equals("") || Config.sid.equals("")){

				if(isAdded() && Config.loginButtonClicked) {
					Toast.makeText(getActivity(),
							getResources().getString(R.string.invalid_crdential),
							Toast.LENGTH_SHORT).show();
					mUserName.requestFocus();

					Config.loginButtonClicked = false;
				}
				if (Config.mStatusCode == 401 && mResponse != null) {
					Config.loginChk = false;
					deleteValuesFromSharedPreference();
				}

                resetValues();
            } else {
				{
                    Config.loginChk = true;
                    editor = settings.edit();
                    editor.putString("username", Config.username);
                    editor.putString("password", Config.pwd);
                    editor.commit();

            //Check User is loggedIn
                    boolean donotshowMA = settings.getBoolean("donotshowMA", false);
					Log.i("anisha","HomeScreen donotshowMA: "+donotshowMA);
                    if (donotshowMA) {
                        editor = settings.edit();
                        editor.putBoolean("donotshowMA", false);
                        editor.putBoolean("chargeNowSelectStation", false);
                        editor.commit();
                        if (getActivity() != null)
                            getActivity().finish();
                    } else {
            //Take to MyAccount Page
                        switchToNext();
                    }
                }
                if (Config.mStatusCode == 200 && mResponse != null) {
                    Config.loginChk = true;
                    editor = settings.edit();
                    editor.putString("username", Config.username);
                    editor.putString("password", Config.pwd);
					editor.putBoolean("chargeNow", true);
                    editor.commit();

            //Check User is loggedIn
                    boolean donotshowMA = settings.getBoolean("donotshowMA", false);
					Log.i("anisha","HomeScreen Config.mStatusCode == 200  donotshowMA: "+donotshowMA);
                    if (donotshowMA) {
                        editor = settings.edit();
                        editor.putBoolean("chargeNowSelectStation", false);
                        editor.putBoolean("donotshowMA", false);
                        editor.commit();
                        if (getActivity() != null)
                            getActivity().finish();
                    } else {
            //Take to MyAccount Page
                        switchToNext();
                    }
                } else {
                    Toast.makeText(getActivity(), mResponse, Toast.LENGTH_SHORT)
                            .show();

                    resetValues();
                }
            }
        }
    }

	private void deleteValuesFromSharedPreference() {
		settings = getActivity().getSharedPreferences("session_auth", 0);
		editor = settings.edit();
		editor.remove("username");
		editor.remove("password");
//		editor.putBoolean("showLogin", true);
//		editor.putBoolean("donotshowMA", false);
		editor.commit();
	}

}
