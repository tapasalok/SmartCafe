package com.semaconnect.utility;

import org.apache.http.HttpVersion;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerPNames;
import org.apache.http.conn.params.ConnPerRouteBean;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import android.app.Activity;
import android.support.v4.app.FragmentManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import com.google.android.maps.GeoPoint;
import com.semaconnect.TabsFragmentActivity;

public class Config {

	public static double mLat = 0.0;
	public static double mLong = 0.0;

	public static GeoPoint mUpperLeft;
	public static GeoPoint mBottomRight;

	public static boolean signUpFlag = false;

	public static String username = "";
	public static String pwd = "";
	public static String sid = "";
	public static String expires = "";

	public static String auth_para = "";

	public static int mStatusCode = 0;
	
	public static FragmentManager fragManager;

	public static final String RADIUS = "10";

	//Live Server
   public static String BASE_URL = "https://api.semacharge.com/v0.9.2/";
  public static final String KEY="NeVY6E5y8edYMEvy";

	//Demo Server
//	public static String BASE_URL = "https://dev.semacharge.com/api/v0.9.2/index.php/";
	public static String BASE_URL1 = "https://dev.semacharge.com/girish/api/v0.9.2/index.php/";

	FragmentManager manager;

	public static boolean loginChk = false;
	public static String mapSize = "480x800";
	public static String chartSize = "400x160";
	public static String pi_Graph = "200x150";
	public static boolean authorize = false;

	public static final String INVALID_CREDENTIAL = "Invalid Credentials";

	public static final String LOC_LAT_LONG = "LocationsNearLatLong";
	public static final String LOC_LAT_LONG_EDIT = "LocationsNearLatLongEdit";
	public static final String LOC_NEAR_ADD = "LocationsNearAddress";
	public static final String LOC_BOX = "LocationsInBoundingBox";

	public static DefaultHttpClient client = getThreadSafeClient();

	public static boolean comingFromLocationSettings = false;

	// Flag to check whether the List View Button is clicked or not in MapScreen
	public static boolean listButtonClicked = false;
	public static boolean loginButtonClicked = false;

	public synchronized static DefaultHttpClient getThreadSafeClient() {

		if (client != null)
			return client;

		SchemeRegistry schemeRegistry = new SchemeRegistry();
		schemeRegistry.register(new Scheme("http", PlainSocketFactory
				.getSocketFactory(), 80));

		// https scheme
		schemeRegistry.register(new Scheme("https", new EasySSLSocketFactory(),
				443));
		HttpParams params = new BasicHttpParams();

		params.setParameter(ConnManagerPNames.MAX_TOTAL_CONNECTIONS, 30);
		params.setParameter(ConnManagerPNames.MAX_CONNECTIONS_PER_ROUTE,
				new ConnPerRouteBean(30));
		params.setParameter(HttpProtocolParams.USE_EXPECT_CONTINUE, false);
		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);

		ClientConnectionManager mgr = new ThreadSafeClientConnManager(params,
				schemeRegistry);

		client = new DefaultHttpClient(mgr, params);

		return client;
	}

	public static void ViewShow() {
		TabsFragmentActivity.pgBack.setVisibility(ImageView.VISIBLE);
		TabsFragmentActivity.pgDialog.setVisibility(ProgressBar.VISIBLE);
	}

	public static void ViewDismiss() {
		TabsFragmentActivity.pgBack.setVisibility(ImageView.GONE);
		TabsFragmentActivity.pgDialog.setVisibility(ProgressBar.GONE);
	}
	public static void toggle(Activity activity){
		InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
		if (imm.isActive()){
			imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0); // hide
		} else {
			imm.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY); // show
		}
	}

}
