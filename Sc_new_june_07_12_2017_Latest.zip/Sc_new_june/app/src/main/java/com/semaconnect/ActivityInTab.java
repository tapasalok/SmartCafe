package com.semaconnect;

import com.semaconnect.utility.Config;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListView;

abstract class ActivityInTab extends FragmentActivity{

	View mListViewContainer;
	ListView mListView;
	FragmentManager manager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_in_tab);

		// List View
		mListViewContainer = LayoutInflater.from(this).inflate(
				R.layout.location_list, null);
		mListView = (ListView) mListViewContainer
				.findViewById(R.id.location_listview);
	}

	protected void navigateTo(Fragment newFragment) {
		manager = getSupportFragmentManager();
		Config.fragManager = manager;
		FragmentTransaction ft = manager.beginTransaction();
		ft.add(R.id.content, newFragment);
		ft.addToBackStack(null);
		ft.commitAllowingStateLoss();
	}

	protected void navigateWithoutBack(Fragment newFragment) {
		manager = getSupportFragmentManager();
		Config.fragManager = manager;
		FragmentTransaction ft = manager.beginTransaction();
		ft.add(R.id.content, newFragment);
		ft.commitAllowingStateLoss();
	}

	@Override
	public void onBackPressed() {
		manager = getSupportFragmentManager();
		if (manager.getBackStackEntryCount() > 1) {
			super.onBackPressed();
		} else {
			finish();
			// Otherwise, ask user if he wants to leave :)
			// showExitDialog();
		}
	}
	
	public FragmentManager getMyFragmentManager(){
		return getSupportFragmentManager();
	}

}
