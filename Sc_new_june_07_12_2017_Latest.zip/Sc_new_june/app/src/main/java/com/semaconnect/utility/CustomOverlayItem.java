package com.semaconnect.utility;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

public class CustomOverlayItem extends OverlayItem {

	public int position;
	public boolean balloonLock;
	
	
	public CustomOverlayItem(GeoPoint point, String title, String snippet) {
		super(point, title, snippet);
	}	
	
	public CustomOverlayItem(GeoPoint point, String title, String snippet,int pos,boolean lockFlag) {
		super(point, title, snippet);
		position=pos;
		balloonLock = lockFlag;
		
	}	
	
	public int getPosition(){
		return position;
	}
	
	public boolean getBalloonLock(){
		return balloonLock;
	}
		
}
