package com.semaconnect;

import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabWidget;
import android.widget.TextView;
import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import com.semaconnect.utility.Config;

public class TabsFragmentActivity extends TabActivity {
    private static float currentRating = 5.0f;
    public static TabHost tabHost;
    public static TabWidget tabWidget;
    public static ProgressBar pgDialog;
    public static ImageView pgBack;
    private Button mHomeBtn, mMapBtn, mMoreBtn;
    TabHost.TabSpec spec;

    /**
     * Id to identity READ_CONTACTS permission request.
     */
    private static final int REQUEST_READ_LOCATION = 0;
    private static final int REQUEST_READ_LOCATION_1 = 1;
    private static final int REQUEST_CALL_PHONE = 2;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mayRequestCourseLocation();
        mayRequestFineLocation();
//        mayRequestCallPhone();

        init();
        setTabs();

        mHomeBtn = (Button) findViewById(R.id.btn_home);
        mMapBtn = (Button) findViewById(R.id.btn_map);
        mMoreBtn = (Button) findViewById(R.id.btn_more);
        mHomeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fm = ((ActivityInTab) getCurrentActivity())
                        .getMyFragmentManager();
                if (fm.getBackStackEntryCount() > 1 && !Config.loginChk) {
                    for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                        fm.popBackStack();
                    }

                    HomeScreen f = new HomeScreen();
                    ((ActivityInTab) getCurrentActivity()).navigateTo(f);
                }
            }
        });

        mMapBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v("###", "mMapBtn");
                TabGroupActivity tab = (TabGroupActivity) getCurrentActivity();
                tab.onBackPressed();
            }
        });

        mMoreBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fm = ((ActivityInTab) getCurrentActivity())
                        .getMyFragmentManager();
                if (fm.getBackStackEntryCount() > 1) {
                    for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                        fm.popBackStack();
                    }

                    MoreScreen f = new MoreScreen();
                    Bundle args = new Bundle();
                    args.putString("title", "Suggest Location");
                    f.setArguments(args);

                    ((ActivityInTab) getCurrentActivity()).navigateTo(f);
                }
            }
        });

        tabHost.setOnTabChangedListener(new OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if (tabId.equals("tabhome")) {
                    mHomeBtn.setVisibility(View.VISIBLE);
                    mMapBtn.setVisibility(View.INVISIBLE);
                    mMoreBtn.setVisibility(View.INVISIBLE);
                } else if (tabId.equals("tabmap")) {
                    mHomeBtn.setVisibility(View.INVISIBLE);
                    mMapBtn.setVisibility(View.VISIBLE);
                    mMoreBtn.setVisibility(View.INVISIBLE);
                } else if (tabId.equals("tabmore")) {
                    mHomeBtn.setVisibility(View.INVISIBLE);
                    mMapBtn.setVisibility(View.INVISIBLE);
                    mMoreBtn.setVisibility(View.VISIBLE);
                }
            }
        });

        showRateAppDialogIfNeeded();
    }

    private boolean mayRequestCourseLocation() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(ACCESS_COARSE_LOCATION)) {
            requestPermissions(new String[]{ACCESS_COARSE_LOCATION}, REQUEST_READ_LOCATION);
        } else {
            requestPermissions(new String[]{ACCESS_COARSE_LOCATION}, REQUEST_READ_LOCATION);
        }
        return false;
    }

    private boolean mayRequestFineLocation() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
            requestPermissions(new String[]{ACCESS_FINE_LOCATION}, REQUEST_READ_LOCATION_1);
        } else {
            requestPermissions(new String[]{ACCESS_FINE_LOCATION}, REQUEST_READ_LOCATION_1);
        }
        return false;
    }

//    private boolean mayRequestCallPhone() {
//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
//            return true;
//        }
//        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
//            return true;
//        }
//        if (shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE)) {
//            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PHONE);
//        } else {
//            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PHONE);
//        }
//        return false;
//    }

    /**
     * Callback received when a permissions request has been completed.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_READ_LOCATION) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this, "Permission for Course location granted !!!", Toast.LENGTH_SHORT).show();
            }
        }

        if (requestCode == REQUEST_READ_LOCATION_1) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this, "Permission for Fine location granted !!!", Toast.LENGTH_SHORT).show();
            }
        }

//        if (requestCode == REQUEST_CALL_PHONE) {
//            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this, "Permission for Call Phone granted !!!", Toast.LENGTH_SHORT).show();
//            }
//        }

    }


    public void init() {

        tabWidget = (TabWidget) findViewById(android.R.id.tabs);
        tabHost = getTabHost();
        pgDialog = (ProgressBar) findViewById(R.id.indicatorProgress);
        pgBack = (ImageView) findViewById(R.id.indicatorImage);
    }

    private void setTabs() {

        addTab("home", 1);
        addTab("map", 2);
        addTab("more", 3);
    }

    public static void switchTab(int indexTabToSwitchTo) {
        tabHost.setCurrentTab(indexTabToSwitchTo);
    }

    public static int getTabIndex() {
        return tabHost.getCurrentTab();
    }

    private void addTab(String labelId, int id) {

        Intent intent = null;
        spec = tabHost.newTabSpec("tab" + labelId);

        View tabIndicator = (View) LayoutInflater.from(
                TabsFragmentActivity.this).inflate(R.layout.tab_indicator,
                tabWidget, false);

        ImageView tab_image = (ImageView) tabIndicator
                .findViewById(R.id.tab_image);

        if (id == 1) {

            intent = new Intent(TabsFragmentActivity.this, StackHome.class);
            tab_image.setBackgroundDrawable(getResources().getDrawable(
                    R.drawable.myaccount));
        } else if (id == 2) {
            intent = new Intent(TabsFragmentActivity.this, StackMap.class);
            tab_image.setBackgroundDrawable(getResources().getDrawable(
                    R.drawable.maptab));
        } else if (id == 3) {
            intent = new Intent(TabsFragmentActivity.this, StackMore.class);
            tab_image.setBackgroundDrawable(getResources().getDrawable(
                    R.drawable.moretab));
        }

        spec.setIndicator(tabIndicator);
        spec.setContent(intent);
        tabHost.addTab(spec);
        tabHost.setCurrentTab(1);
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        return super.onKeyDown(keyCode, event);
    }

    private boolean showRateAppDialogIfNeeded() {
        boolean bool = AppPreferences.getInstance(getApplicationContext()).getAppRate();
        int i = AppPreferences.getInstance(getApplicationContext()).getLaunchCount();
        if ((bool) && (i % 5 == 0)) {
            createAppRatingDialog(getString(R.string.rate_app_title), getString(R.string.rate_app_message)).show();
            return true;
        } else {
            return false;
        }
    }

    private AlertDialog createAppRatingDialog(String rateAppTitle, String rateAppMessage) {
        LayoutInflater factory = LayoutInflater.from(this);
        final View deleteDialogView = factory.inflate(
                R.layout.custom, null);

        RatingBar ratingBar = (RatingBar) deleteDialogView.findViewById(R.id.ratingBar);
        final TextView txtRatingValue = (TextView) deleteDialogView.findViewById(R.id.txtRatingValue);
        final TextView custom_title = (TextView) deleteDialogView.findViewById(R.id.custom_title);
        final TextView custom_message = (TextView) deleteDialogView.findViewById(R.id.custom_message);
        final TextView button1 = (TextView) deleteDialogView.findViewById(R.id.button1);
        final TextView button2 = (TextView) deleteDialogView.findViewById(R.id.button2);
        final TextView button3 = (TextView) deleteDialogView.findViewById(R.id.button3);
        txtRatingValue.setText("Thank you very much for rating us 5 stars!");
        custom_title.setText(rateAppTitle);
        custom_message.setText(rateAppMessage);
        //if rating value is changed,
        //display the current rating value in the result (textview) automatically
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                currentRating = rating;

                if (rating <= 3.0f) {
                    txtRatingValue.setText("Please leave us feedback so that we can address your issues.");
                } else {
                    int ratingInt = (int) rating;
                    txtRatingValue.setText("Thank you very much for rating us " + String.valueOf(ratingInt) + " stars!");
                }
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Holo_Dialog));

        //		builder.setPositiveButton(getString(R.string.dialog_app_rate), new DialogInterface.OnClickListener() {
//			public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
//				if (currentRating <= 3.0f){
//					openFeedback(TabsFragmentActivity.this);
//				}else{
//					openAppInPlayStore(TabsFragmentActivity.this);
//					AppPreferences.getInstance(TabsFragmentActivity.this.getApplicationContext()).setAppRate(false);
//				}
////				finish();
//			}
//		}).setNegativeButton(getString(R.string.dialog_your_feedback), new DialogInterface.OnClickListener() {
//			public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
////                openFeedback(MainActivity.this);
//				AppPreferences.getInstance(TabsFragmentActivity.this.getApplicationContext()).setAppRate(false);
////				finish();
//			}
//		}).setNeutralButton(getString(R.string.dialog_ask_later), new DialogInterface.OnClickListener() {
//			public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
//				paramAnonymousDialogInterface.dismiss();
//				AppPreferences.getInstance(TabsFragmentActivity.this.getApplicationContext()).resetLaunchCount();
////				finish();
//			}
//		});
        final AlertDialog dialog = builder.create();
        dialog.setCancelable(false);

        button1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                AppPreferences.getInstance(TabsFragmentActivity.this.getApplicationContext()).resetLaunchCount();
//                finish();
            }

        });
        button2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //            openFeedback(MainActivity.this);
                dialog.dismiss();
                AppPreferences.getInstance(TabsFragmentActivity.this.getApplicationContext()).setAppRate(false);
//				finish();
            }

        });

        button3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentRating <= 3.0f) {
                    openFeedback(TabsFragmentActivity.this);
                } else {
                    openAppInPlayStore(TabsFragmentActivity.this);
                    AppPreferences.getInstance(TabsFragmentActivity.this.getApplicationContext()).setAppRate(false);
                }
                dialog.dismiss();
            }

        });
        dialog.setView(deleteDialogView);
//		dialog.setTitle(rateAppTitle);
//		dialog.setMessage(rateAppMessage);
        return dialog;
    }

    public static void openAppInPlayStore(Context paramContext) {
        paramContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.semaconnect&hl=en")));
    }

    public static void openFeedback(Context paramContext) {
        Intent localIntent = new Intent(Intent.ACTION_SEND);
        localIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"customerservice@semaconnect.com"});
        localIntent.putExtra(Intent.EXTRA_CC, "");
        String str = null;
        try {
            str = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionName;
            localIntent.putExtra(Intent.EXTRA_SUBJECT, "I Rated the SemaConnect Android app " + currentRating + " stars");
            localIntent.setType("message/rfc822");
            paramContext.startActivity(Intent.createChooser(localIntent, "Choose an Email client :"));
        } catch (Exception e) {
            Log.d("OpenFeedback", e.getMessage());
        }
    }
}
