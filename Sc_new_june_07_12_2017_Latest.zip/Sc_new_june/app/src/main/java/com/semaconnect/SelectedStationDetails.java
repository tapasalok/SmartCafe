package com.semaconnect;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.ContextThemeWrapper;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.semaconnect.utility.Config;
import com.semaconnect.utility.RestClient;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import static android.content.Intent.ACTION_DIAL;

/**
 * Created by anisha on 22/3/17.
 */

public class SelectedStationDetails extends AppCompatActivity implements GoogleMap.OnMarkerClickListener,
        GoogleMap.OnInfoWindowClickListener,
        GoogleMap.OnMarkerDragListener,
        OnMapReadyCallback,
        GoogleMap.OnInfoWindowLongClickListener,
        GoogleMap.OnInfoWindowCloseListener {
    private Button startCharging;
    String chargStation;
    private String mStationId = "";
    private String mResponse = "";
    Drawable drawable;
    private String serialNo;
    private ArrayList<String> mData = null;
    private ArrayList<String> mCords = null;
    private TextView serial_num, station_name, location, loc_address,pricingsummery;
    private String stationName, location_name, address,pricing_summary,station_id;
    private String name = "";
    private String status = "";
    private static LatLng SINGLE_LOCATION = new LatLng(0, 0);
    private static LatLng CURRENT_LOCATION = new LatLng(Config.mLat, Config.mLong);
    private GoogleMap mMap;
    private Marker mBrisbane;
    private Marker currentLocation;
    private ImageButton station_reportbtn;
    private ImageButton station_supportbtn;
    StringBuilder PowerList, energyList;
    ArrayList<String> timeList;
    private SharedPreferences settings;
    private SharedPreferences.Editor editor;
    /**
     * Keeps track of the last selected marker (though it may no longer be selected).  This is
     * useful for refreshing the info window.
     */
    private Marker mLastSelectedMarker;
    private final List<Marker> mMarkerRainbow = new ArrayList<Marker>();

    // Map implementation
    private TextView mTopText;
    private TextView mTagText;

    private double lat;
    private double lon;
    private int mId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selectedstationdetails);

        settings = getSharedPreferences("session_auth", 0);

        station_supportbtn = (ImageButton) findViewById(R.id.station_supportbtn);
        station_reportbtn = (ImageButton) findViewById(R.id.station_reportbtn);
        TextView titleTxt = (TextView) findViewById(R.id.top_title_txt);
        serial_num = (TextView) findViewById(R.id.serial_num);
        station_name = (TextView) findViewById(R.id.station_name);
        location = (TextView) findViewById(R.id.location);
        loc_address = (TextView) findViewById(R.id.address);
        pricingsummery = (TextView) findViewById(R.id.pricingsummery);

        Bundle args = getIntent().getExtras();
        serialNo = args.getString("serial_number");
        stationName = args.getString("name");
        name = args.getString("name");
        lat = args.getDouble("lat");
        lon = args.getDouble("lon");
        mId = args.getInt("id");

        Double latDouble = 0.0;
        Double longiDouble = 0.0;
        try {
            latDouble = lat;
            longiDouble = lon;
        } catch (Exception e) {
            latDouble = 0.0;
            longiDouble = 0.0;
        }

        SINGLE_LOCATION = new LatLng(latDouble, longiDouble);

        DisplayMetrics metrics = new DisplayMetrics();
        getParent().getWindowManager().getDefaultDisplay().getMetrics(metrics);

        location_name = args.getString("location_name");
        address = args.getString("address");
        pricing_summary = args.getString("pricing_summary");
        station_id = args.getString("station_id");
        mStationId = station_id;

        status = args.getString("status");

//        Log.i("anisha", "station_id" + station_id + chargStation +"status: "+status);
        serial_num.setText(serialNo);
        station_name.setText(stationName);
        location.setText(location_name);
        loc_address.setText(address);
        pricingsummery.setText(pricing_summary.replace(", ",",\n"));


        station_reportbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent mIntent = new Intent(SelectedStationDetails.this, StackReport.class);
                mIntent.putExtra("title", "Report A Problem");
                TabGroupActivity parentActivity = (TabGroupActivity) getParent();
                parentActivity.startChildActivity("report_problem", mIntent);
            }
        });
        station_supportbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(ACTION_DIAL, Uri
                            .parse(getResources().getString(R.string.tel_no))));
                } catch (Exception e) {
                }
            }
        });

        titleTxt.setText("Station Details");
        startCharging = (Button)findViewById(R.id.start_charging);
        startCharging.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isUserLoggedIn()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(getParent());

                    alert.setTitle(stationName);
                    alert.setIcon(R.drawable.ic_launcher);
                    alert.setMessage("Authorize charging session here?");
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new GetChargingSessionFromChargeNow().execute();
                        }
                    });
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();
                }else{
                    AlertDialog.Builder alert = new AlertDialog.Builder(getParent());

                    alert.setTitle("Station Details");
                    alert.setIcon(R.drawable.ic_launcher);
                    alert.setMessage("" +
                            "Please login to start charging.");
                    alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            editor = settings.edit();
                            editor.putBoolean("showLogin", false);
                            editor.putBoolean("chargeNowSelectStation", true);
                            editor.putBoolean("donotshowMA", true);
                            editor.commit();
                            Intent intent = new Intent(SelectedStationDetails.this, StackHome.class);
                            startActivity(intent);
                        }
                    });
                    alert.show();

                }


            }
        });

        new DummyCall().execute();

        // New Map implementation starts here
        mTagText = (TextView) findViewById(R.id.tag_text);
        if (mMap == null){
            SupportMapFragment mapFragment =
                    (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
        }

    }

    /*
	returns true if user is already logged in else it will return false
    */
    private boolean isUserLoggedIn() {
        boolean loggedIn;
        settings = getSharedPreferences("session_auth", 0);
        final String user = settings.getString("username", "");
        final String password = settings.getString("password", "");
        if (!TextUtils.isEmpty(user) && !TextUtils.isEmpty(password) && user.length() > 0 && password.length() > 0) {
            loggedIn = true;
        } else {
            loggedIn = false;
        }
        return loggedIn;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
//        Toast.makeText(this, "Click Info Window", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onInfoWindowClose(Marker marker) {
//        Toast.makeText(this, "Close Info Window", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onInfoWindowLongClick(Marker marker) {
//        Toast.makeText(this, "Info Window long click", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onMarkerDragStart(Marker marker) {
        mTopText.setText("onMarkerDragStart");
    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
        mTopText.setText("onMarkerDragEnd");
    }

    @Override
    public void onMarkerDrag(Marker marker) {
        mTopText.setText("onMarkerDrag.  Current Position: " + marker.getPosition());
    }

    @Override
    public void onMapReady(GoogleMap map) {
//        Log.i("anisha", "onMapReady map: "+map);
        try {
            if (map != null) {
                mMap = map;

                // Hide the zoom controls as the button panel will cover it.
                mMap.getUiSettings().setZoomControlsEnabled(false);

                // Add lots of markers to the map.
                addMarkersToMap();


                // Setting an info window adapter allows us to change the both the contents and look of the
                // info window.
                mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter());

                // Set listeners for marker events.  See the bottom of this class for their behavior.
                mMap.setOnMarkerClickListener(this);
                mMap.setOnInfoWindowClickListener(this);
                mMap.setOnMarkerDragListener(this);
                mMap.setOnInfoWindowCloseListener(this);
                mMap.setOnInfoWindowLongClickListener(this);
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                // Override the default content description on the view, for accessibility mode.
                // Ideally this string would be localised.
                map.setContentDescription("Map with lots of markers.");

                // Pan to see all markers in view.
                // Cannot zoom to bounds until the map has a size.
                final View mapView = getSupportFragmentManager().findFragmentById(R.id.map).getView();

                if (mapView.getViewTreeObserver().isAlive()) {

                    mapView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @SuppressWarnings("deprecation") // We use the new method when supported
                        @SuppressLint("NewApi") // We check which build version we are using.
                        @Override
                        public void onGlobalLayout() {
                            LatLngBounds bounds = new LatLngBounds.Builder()
                                    .include(SINGLE_LOCATION)
                                    .build();
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                                mapView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                            } else {
                                mapView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            }
                            //mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 50));

                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(SINGLE_LOCATION.latitude, SINGLE_LOCATION.longitude), 16.0f));
                        }
                    });
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            Log.e("Error" , "GOOGLE MAPS NOT LOADED");
        }


        //mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(new LatLng(SINGLE_LOCATION.latitude,SINGLE_LOCATION.longitude) , 16.0f) );
    }

    private void addMarkersToMap() {
        // Uses a colored icon.
//
//		Toast.makeText(StationDetails.this, "total: "+total, Toast.LENGTH_SHORT).show();
//		Toast.makeText(StationDetails.this, "status: "+status, Toast.LENGTH_SHORT).show();
//		Toast.makeText(StationDetails.this, "available: "+available, Toast.LENGTH_SHORT).show();
//        Log.i("anisha", "status: "+status);
        if (TextUtils.isEmpty(status)){
            drawable = getResources().getDrawable(
                    R.drawable.map_pin_oos);
            mBrisbane = mMap.addMarker(new MarkerOptions()
                    .position(SINGLE_LOCATION)
                    .title(name)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        }else {
            if (status.equals("available")) {
                drawable = getResources().getDrawable(
                        R.drawable.map_pin_available);

                mBrisbane = mMap.addMarker(new MarkerOptions()
                        .position(SINGLE_LOCATION)
                        .title(name)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
            } else if (status.equals("offline")) {
                drawable = getResources().getDrawable(
                        R.drawable.map_pin_offline);
                BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(R.drawable.graymappeddot);
                mBrisbane = mMap.addMarker(new MarkerOptions()
                        .position(SINGLE_LOCATION)
                        .title(name)
                        .icon(icon));
//				.icon(BitmapDescriptorFactory.defaultMarker(0.0f)));
            } else if (status.equals("in use")) {
                drawable = getResources().getDrawable(
                        R.drawable.map_pin_in_use);

                mBrisbane = mMap.addMarker(new MarkerOptions()
                        .position(SINGLE_LOCATION)
                        .title(name)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
            } else {
                drawable = getResources().getDrawable(
                        R.drawable.map_pin_oos);
                mBrisbane = mMap.addMarker(new MarkerOptions()
                        .position(SINGLE_LOCATION)
                        .title(name)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
            }
        }

        currentLocation = mMap.addMarker(new MarkerOptions()
                .position(CURRENT_LOCATION)
                .title("Current Location")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));

    }

    @Override
    public boolean onMarkerClick(final Marker marker) {
        // Markers have a z-index that is settable and gettable.
        float zIndex = marker.getZIndex() + 1.0f;
        marker.setZIndex(zIndex);
//        Toast.makeText(this, marker.getTitle() + " z-index set to " + zIndex,
//                Toast.LENGTH_SHORT).show();

        // Markers can store and retrieve a data object via the getTag/setTag methods.
        // Here we use it to retrieve the number of clicks stored for this marker.
        Integer clickCount = (Integer) marker.getTag();
        // Check if a click count was set.
        if (clickCount != null) {
            clickCount = clickCount + 1;
            // Markers can store and retrieve a data object via the getTag/setTag methods.
            // Here we use it to store the number of clicks for this marker.
            marker.setTag(clickCount);
            mTagText.setText(marker.getTitle() + " has been listButtonClicked " + clickCount + " times.");
        } else {
            mTagText.setText("");
        }

        mLastSelectedMarker = marker;
        // We return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).

        if (marker.isInfoWindowShown()){
            marker.hideInfoWindow();
        }else{
            marker.showInfoWindow();
        }

        return false;
    }


    class GetChargingSessionFromChargeNow extends AsyncTask<Void, Void, Void> {

        int mResponse_code;
        String currentKey = "";
        String currentValue = "";
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = ProgressDialog.show(getParent(), "", "Authorizing....");
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            String url = Config.BASE_URL + "charging-sessions" + "?key="
                    + Config.KEY;

            String mEntity = "{ \"station_id\" : " + mStationId + " }";

            try {

                HttpPost httpost = new HttpPost(url);
                httpost.setEntity(new StringEntity(mEntity));
                httpost.setHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                HttpResponse httpResponse = null;

                if (Config.client != null) {
                    httpResponse = Config.client.execute(httpost);
                } else {
                    httpResponse = Config.getThreadSafeClient()
                            .execute(httpost);
                }

                mResponse_code = httpResponse.getStatusLine().getStatusCode();

                Log.v("STATUS CODE :: ", ":: " + mResponse_code);

                HttpEntity entity = httpResponse.getEntity();
                if (entity != null) {

                    InputStream input = null;
                    input = entity.getContent();
                    mResponse = convertStreamToString(input);

                    input.close();
                    Log.v("response ", "" + mResponse);
//                    Log.v("anisha", "GetChargingSessionFromChargeNow" + mResponse);

                    if (mResponse != null) {
                        JSONObject jObject = new JSONObject(mResponse);

                        // myStatics = jObject.getString("statistics");
                        Iterator keys = jObject.keys();

                        while (keys.hasNext()) {
                            // loop to get the dynamic key
                            currentKey = (String) keys.next();

                            // get the value of the dynamic key
                            currentValue = jObject.getString(currentKey);

                            Log.v("dynamic key", currentKey + "****"
                                    + currentValue);

                        }

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                pDialog.dismiss();
            }
            return null;

        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stubstation_id
            super.onPostExecute(result);

            pDialog.dismiss();

            AlertDialog.Builder dialog = new AlertDialog.Builder(
                    new ContextThemeWrapper(getParent(), android.R.style.Theme_Dialog));
            if (mResponse_code == 201) {
                dialog.setMessage("Charging session authorized at "
                        + stationName
                        + "\n\n Plug in your car to begin charging.");
                dialog.setIcon(R.drawable.ic_launcher);
                dialog.setTitle(stationName);
                dialog.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                Config.authorize = true;
                                finish();
                                TabsFragmentActivity.switchTab(0);
                                dialog.dismiss();
                            }
                        });

            } else if (mResponse_code == 406) {
                dialog.setMessage(currentValue);
                dialog.setIcon(R.drawable.ic_launcher);
                dialog.setTitle(stationName);
//                Log.i("anisha" ,"406" + currentValue);
                dialog.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                finish();
                                dialog.dismiss();
                            }
                        });
            } else if (mResponse_code == 503) {
                dialog.setMessage(currentValue);
                dialog.setIcon(R.drawable.ic_launcher);
                dialog.setTitle(stationName);
//                Log.i("anisha" ,"503" + currentValue);
                dialog.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                finish();
                                dialog.dismiss();
                            }
                        });
            } else {
                dialog.setMessage("Authorization Failed:");
                dialog.setIcon(R.drawable.ic_launcher);
                dialog.setTitle(stationName);
//                Log.i("anisha" ,"Authorization Failed:" + currentValue);
                dialog.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                dialog.dismiss();
                                finish();
                            }
                        });
            }

            dialog.create().show();

        }
    }
    private static String convertStreamToString(InputStream is) {
        Log.i("Inside convertstream", "hello");
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }


    /**
     * Demonstrates converting a {@link Drawable} to a {@link BitmapDescriptor},
     * for use as a marker icon.
     */
    private BitmapDescriptor vectorToBitmap(@DrawableRes int id, @ColorInt int color) {
        Drawable vectorDrawable = ResourcesCompat.getDrawable(getResources(), id, null);
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),
                vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        DrawableCompat.setTint(vectorDrawable, color);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

        // These are both viewgroups containing an ImageView with id "badge" and two TextViews with id
        // "title" and "snippet".
        private final View mWindow;

        private final View mContents;

        CustomInfoWindowAdapter() {
            mWindow = getLayoutInflater().inflate(R.layout.custom_info_window, null);
            mContents = getLayoutInflater().inflate(R.layout.custom_info_contents, null);
        }

        @Override
        public View getInfoWindow(Marker marker) {
            render(marker, mWindow);
            return mWindow;
        }

        @Override
        public View getInfoContents(Marker marker) {
            render(marker, mContents);
            return mContents;
        }

        private void render(Marker marker, View view) {
            int badge;
            // Use the equals() method on a Marker to check for equals.  Do not use ==.
            if (marker.equals(mBrisbane)) {
//				badge = R.drawable.badge_qld;
            } else if(marker.equals(currentLocation)){
//				badge = R.drawable.badge_qld;
            }else {
                // Passing 0 to setImageResource will clear the image view.
                badge = 0;
            }
//			((ImageView) view.findViewById(R.id.badge)).setImageResource(badge);

            String title = marker.getTitle();
            TextView titleUi = ((TextView) view.findViewById(R.id.title));
            if (title != null) {
                // Spannable string allows us to edit the formatting of the text.
                SpannableString titleText = new SpannableString(title);
                titleText.setSpan(new ForegroundColorSpan(Color.RED), 0, titleText.length(), 0);
                titleUi.setText(titleText);
            } else {
                titleUi.setText("");
            }

//			String snippet = marker.getSnippet();
//			TextView snippetUi = ((TextView) view.findViewById(R.id.snippet));
//			if (snippet != null && snippet.length() > 12) {
//				SpannableString snippetText = new SpannableString(snippet);
//				snippetText.setSpan(new ForegroundColorSpan(Color.MAGENTA), 0, 10, 0);
//				snippetText.setSpan(new ForegroundColorSpan(Color.BLUE), 12, snippet.length(), 0);
//				snippetUi.setText(snippetText);
//			} else {
//				snippetUi.setText("");
//			}
        }
    }
    private boolean checkReady() {
        if (mMap == null) {
//            Toast.makeText(this, R.string.map_not_ready, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /**
     * Called when the Clear button is listButtonClicked.
     */
    public void onClearMap(View view) {
        if (!checkReady()) {
            return;
        }
        mMap.clear();
    }

    /**
     * Called when the Reset button is listButtonClicked.
     */
    public void onResetMap(View view) {
        if (!checkReady()) {
            return;
        }
        // Clear the map because we don't want duplicates of the markers.
        mMap.clear();
        addMarkersToMap();
    }

    /**
     * Called when the Reset button is listButtonClicked.
     */
    public void onToggleFlat(View view) {
        if (!checkReady()) {
            return;
        }

        for (Marker marker : mMarkerRainbow) {
            marker.setFlat(true);
        }
    }

    class DummyCall extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Config.ViewShow();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                String url = Config.BASE_URL + "locations/" + mId + "?key="
                        + Config.KEY;
                RestClient client = new RestClient(url);
                client.AddHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                client.Execute(RestClient.RequestMethod.GET);
                String response = client.getResponse();

                if (response != null) {

                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Config.ViewDismiss();

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        Log.i("anisha", "keyboard18");
    }
}
