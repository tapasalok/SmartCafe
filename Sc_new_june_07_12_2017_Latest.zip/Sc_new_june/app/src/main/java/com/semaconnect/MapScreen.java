package com.semaconnect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import android.widget.ZoomControls;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.semaconnect.utility.BalloonItemizedOverlay;
import com.semaconnect.utility.BalloonOverlayView;
import com.semaconnect.utility.Config;
import com.semaconnect.utility.CustomOverlayItem;
import com.semaconnect.utility.MyLocation;
import com.semaconnect.utility.MyMapView;
import com.semaconnect.utility.PlaceJSONParser;
import com.semaconnect.utility.RestClient;
import com.semaconnect.utility.MyLocation.LocationResult;
import com.semaconnect.utility.RestClient.RequestMethod;
import com.semaconnect.utility.Utils;
import pl.droidsonroids.gif.GifTextView;

public class MapScreen extends MapActivity {

    private View mMapViewContainer;
    private MapView mMapView;
    PlacesTask placesTask;
    ParserTask parserTask;
    private AutoCompleteTextView mEdit;
    private RelativeLayout mTopLayout;
    private GifTextView ajax_loader;
    private String mURL = "";
    private String searchTxt = "";
    private String checkType = "";

    boolean userIsPanning = false;
    boolean panTouch = false;
    private Button mListView;
    private Button mChargeNow;
    private ZoomControls zoomCtrl;

    private ImageButton mCurLoc, mSearch;
    public static ArrayList<ArrayList<String>> mData = null;
    public static ArrayList<GeoPoint> mCordinates = null;
    public static ArrayList<ArrayList<String>> mAvail = null;

    private static Handler handler = new Handler();
    private static boolean isInflating = false;

    List<Overlay> mapOverlays;
    Drawable drawable;
    MyItemizedOverlay itemizedOverlay;

    MyItemizedOverlay itemizedOverlay_cur;
    MyItemizedOverlay itemizedOverlay_items;

    InputMethodManager imm;
    StackMap mapActivity;
    GeoPoint mapCenter;
    Handler messageHandler;

    GestureDetector gestureDetector;
    long start;
    long stop;
    GestureDetector gesture;

    boolean isPop = false;

    private double mLat;
    private double mLong;

    private ProgressDialog pDialog;
    private static List<HashMap<String, String>> places = null;
    private String mId;
    private MyMapView mMapViewListener;

//    Refresh Screen Every 1 minute
//    private int mInterval = 5*60*1000; // 5 seconds by default, can be changed later
////    private int mInterval = 30*1000; // 30 seconds by default, can be changed later
//    private Handler mHandler;


    SharedPreferences settings;
    SharedPreferences.Editor editor;


    @Override
    protected void onResume() {
        super.onResume();
        resumeMap();
//        Log.i("anisha", "keyboard1");
        if (settings.getBoolean("chargeNowClick", false) && settings.getBoolean("chargeNow", false)){
            chargeNowButton(true);
			
			settings = getSharedPreferences("session_auth", 0);
			editor = settings.edit();
			editor.putBoolean("chargeNowClick", false);
			editor.putBoolean("chargeNow", false);
			editor.commit();
			
        }
    }

    private void resumeMap() {

//        Log.i("anisha", "keyboard2");

        Config.listButtonClicked = false;
        if (Utils.checkGpsAvailable(getParent())) {
            pDialog = ProgressDialog.show(getParent(), "",
                    "Waiting for location");
            pDialog.setCancelable(true);
//                updateLocation();;
            if (Config.comingFromLocationSettings == true){
                updateLocation();
                Config.comingFromLocationSettings = false;
            }else if (Config.mLat == 0.0 && Config.mLong == 0.0) {
                updateLocation();

                if (pDialog.isShowing()){
                    pDialog.cancel();
                }

            }else {
                if (pDialog.isShowing()){
                    pDialog.cancel();
                }
            }
        } else {
            if (Config.comingFromLocationSettings == true){
                showWashingtonLocation();
                Config.comingFromLocationSettings = false;
            }
        }
    }

    // Get Current Location
    private void updateLocation() {
//        Log.i("anisha", "keyboard3");
        try {
            LocationResult locationResult = new LocationResult() {
                @Override
                public void gotLocation(Location location) {
                    // Got the location!
                
                    if (location != null) {

                        if (pDialog.isShowing()) {
                            pDialog.cancel();
                        }

                        mLat = location.getLatitude();
                        mLong = location.getLongitude();
                        Config.mLat = mLat;
                        Config.mLong = mLong;

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showCurrentLocation();
                            }
                        });
                    }
                }
            };
            MyLocation myLocation = new MyLocation();
            myLocation.getLocation(this, locationResult);
        } catch (Exception e) {
            if (pDialog.isShowing()) {
                pDialog.dismiss();
            }
        }
    }

    private void setCurrentBox() {
//        Log.i("anisha", "keyboard4");
        GeoPoint newTopLeft = mMapView.getProjection().fromPixels(0, 0);
        GeoPoint newBottomRight = mMapView.getProjection().fromPixels(
                mMapView.getWidth(), mMapView.getHeight());

        Config.mUpperLeft = newTopLeft;
        Config.mBottomRight = newBottomRight;
//        Log.i("anisha", "setCurrentBox" +newTopLeft + newBottomRight );
    }
    private void chargeNowButton(final boolean isAdapterRequired) {
//        Log.i("anisha", "keyboard5");
        settings = getSharedPreferences("session_auth", 0);
        String user = settings.getString("username", "");
        String password = settings.getString("password", "");

        editor = settings.edit();
        editor.putBoolean("donotshowMA", false);
        editor.commit();

        try {
            if (isUserLoggedIn()) {

                    Intent i = new Intent(MapScreen.this,
                            ChargeNow.class);
                    i.putExtra("title", "Charge Now");
                    TabGroupActivity parentActivity = (TabGroupActivity) getParent();
                    parentActivity.startChildActivity("charge_now", i);

            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(getParent());

                builder.setMessage("Please login to start charging.").setTitle("Charge now")
                        .setIcon(R.drawable.ic_launcher)
                        .setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog,
                                        final int id) {
                        dialog.cancel();
                        editor = settings.edit();
                        editor.putBoolean("showLogin", false);
                        editor.putBoolean("donotshowMA", true);
                        editor.commit();
                        Intent intent = new Intent(MapScreen.this, StackHome.class);
                        startActivity(intent);
                    }
                });

                final AlertDialog alert = builder.create();
                alert.show();
            }
        } catch (Exception e) {

        }
    }
    private boolean isUserLoggedIn() {
        boolean loggedIn;
        settings = getSharedPreferences("session_auth", 0);
        final String user = settings.getString("username", "");
        final String password = settings.getString("password", "");
        if (!TextUtils.isEmpty(user) && !TextUtils.isEmpty(password) && user.length() > 0 && password.length() > 0) {
            loggedIn = true;
        } else {
            loggedIn = false;
        }
        return loggedIn;
    }

    @Override
    protected void onCreate(Bundle icicle) {
//        Log.i("anisha", "keyboard6");
        super.onCreate(icicle);
        setContentView(R.layout.map);
        onCreateMapScreen(true);
        settings = getSharedPreferences("session_auth", 0);

    }

    private void onCreateMapScreen(final boolean showGPSAlert) {
//        Log.i("anisha", "keyboard7");
        mEdit = (AutoCompleteTextView) findViewById(R.id.map_top_search);
        ajax_loader = (GifTextView) findViewById(R.id.ajax_loader);

        mTopLayout = (RelativeLayout) findViewById(R.id.map_top_lay);
        mTopLayout.requestFocus();

        mListView = (Button) findViewById(R.id.map_listview);
        mChargeNow = (Button) findViewById(R.id.map_chargenow);
        mCurLoc = (ImageButton) findViewById(R.id.map_locBtn);

        mData = new ArrayList<ArrayList<String>>();
        refreshListIfClicked();

        mCordinates = new ArrayList<GeoPoint>();
        mAvail = new ArrayList<ArrayList<String>>();

        mSearch = (ImageButton) findViewById(R.id.map_searchBtn);
        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        mMapView = (MapView) findViewById(R.id.map_webview);

        zoomCtrl = (ZoomControls) findViewById(R.id.map_zoomControl);

        mEdit.setOnEditorActionListener((OnEditorActionListener) new DoneOnEditorActionListener());
        mEdit = (AutoCompleteTextView) findViewById(R.id.map_top_search);
        mEdit.setThreshold(1);

        mEdit.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                placesTask = new PlacesTask();
                placesTask.execute(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }
        });

        mEdit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    updateGoogleMap();
                    imm.hideSoftInputFromWindow(mEdit.getWindowToken(), 0);
                    getLOcationFromSearchTxt();

            }
        });
            Log.i("",""+imm);
        // Go to List View Fragment
        mListView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Config.listButtonClicked = true;
                imm.hideSoftInputFromWindow(mListView.getWindowToken(), 0);
                if (mData.size() > 0) {

                    Intent i = new Intent(MapScreen.this,
                            LocationListView.class);
                    i.putExtra("title", "List View");
                    TabGroupActivity parentActivity = (TabGroupActivity) getParent();
                    parentActivity.startChildActivity("list_view", i);
                } else {
                    Toast.makeText(getParent(), "No Stations found in this region",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        // Charge using SerialNo
        mChargeNow.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
				settings = getSharedPreferences("session_auth", 0);
				editor = settings.edit();
				editor.putBoolean("chargeNowClick", true);
				editor.commit();
			
                chargeNowButton(true);

            }
        });
        // Set Current Location
        mCurLoc.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Utils.checkGpsAvailable(getParent())) {
                    pDialog = ProgressDialog.show(getParent(), "",
                            "Please wait... Fetching your current location");
                    pDialog.setCancelable(true);
                    updateLocation();
                    pDialog.dismiss();
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showWashingtonLocation();
                        }
                    });
                }
            }
        });

        // Search the Specific Location
        mSearch.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

               getLOcationFromSearchTxt();
            }
        });

        mMapView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                int actionId = event.getAction();

                if (actionId == MotionEvent.ACTION_UP) {
                    stop = event.getEventTime();
                   //  userIsPanning = true;
                } else if (actionId == MotionEvent.ACTION_DOWN) {
                    start = event.getEventTime();
                }

                return gesture.onTouchEvent(event);
            }
        });

        zoomCtrl.setOnZoomInClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mMapView.getController().zoomIn();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setCurrentBox();
                        checkType = Config.LOC_BOX;
                        mURL = Config.BASE_URL + "locations?box="
                                + (Config.mUpperLeft.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mUpperLeft.getLongitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLongitudeE6() / 1E6)
                                + "&radius=" + Config.RADIUS + "&key="
                                + Config.KEY;
                        new GetData().execute();
                    }
                }, 500);

            }
        });

        zoomCtrl.setOnZoomOutClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mMapView.getController().zoomOut();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setCurrentBox();
                        checkType = Config.LOC_BOX;
                        mURL = Config.BASE_URL + "locations?box="
                                + (Config.mUpperLeft.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mUpperLeft.getLongitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLongitudeE6() / 1E6)
                                + "&radius=" + Config.RADIUS + "&key="
                                + Config.KEY;
                        new GetData().execute();
                    }
                }, 500);
            }
        });

        gesture = new GestureDetector(new MyGesture());

        if (showGPSAlert){
            if (Utils.checkGpsAvailable(getParent())) {

            } else {
                enableGpsAlert("Please make sure the Location Services is turned on in the device's setting which is required to show charging stations near you.");
            }
        }else{
            if (Utils.checkGpsAvailable(getParent())) {
                Config.comingFromLocationSettings = true;
            } else {
                showWashingtonLocation();
            }
        }

//        mHandler = new Handler();
//        startRepeatingTask();
    }

    public void enableGpsAlert(String message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getParent());

        builder.setMessage(message).setTitle("Cannot get current location!")
                .setIcon(R.drawable.ic_launcher)
                .setCancelable(false).setPositiveButton("Go To Settings", new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog,
                                final int id) {
                dialog.cancel();

                Config.comingFromLocationSettings = true;

                Intent intent = new Intent(
                        Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        }).setNegativeButton("Cancel",  new DialogInterface.OnClickListener() {
            public void onClick(final DialogInterface dialog,
                                final int id) {
                dialog.cancel();
                showWashingtonLocation();

            }
        });

        final AlertDialog alert = builder.create();
        alert.show();
    }
    private void getLOcationFromSearchTxt() {
//        Log.i("anisha", "keyboard8");
        // Check Network Connection
        if (checkConnection()) {
            mData = new ArrayList<ArrayList<String>>();

            refreshListIfClicked();

            mCordinates = new ArrayList<GeoPoint>();
            mAvail = new ArrayList<ArrayList<String>>();

            searchTxt = mEdit.getText().toString();

            // Validating the Search Field
            if (searchTxt.equalsIgnoreCase(" ")) {
                Toast.makeText(getParent(), R.string.search_empty,
                        Toast.LENGTH_SHORT).show();
            } else if (searchTxt.trim().length() > 0) {
                //If searchTxt lengh is more than 0
                checkType = Config.LOC_NEAR_ADD;
                mURL = Config.BASE_URL + "locations?loc=" + searchTxt
                        + "&key=" + Config.KEY;
                mMapView.getMapCenter();
                new GetData().execute();
            }
        } else {
            //No Network
            Toast.makeText(getParent(), "No Network Connection Found",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ( ( line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
//			Log.i("Exception while downloading url", e.toString());
        } finally {
            if (iStream !=null){
                iStream.close();
            }

            if (urlConnection!=null){
                urlConnection.disconnect();
            }
        }
        return data;
    }

    private class MyGesture extends SimpleOnGestureListener {
        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            Log.v("###", "onSingleTapUp");
            return super.onSingleTapUp(e);
        }

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
                               float velocityY) {

            Log.v("###", "onFling :: " + (stop - start));

            if ((stop - start) > 100) {

               //  userIsPanning = false;
               //  panTouch = true;pr
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setCurrentBox();
                        checkType = Config.LOC_BOX;
                        mURL = Config.BASE_URL + "locations?box="
                                + (Config.mUpperLeft.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mUpperLeft.getLongitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLongitudeE6() / 1E6)
                                + "&radius=" + Config.RADIUS + "&key="
                                + Config.KEY;
                        new GetData().execute();
                    }
                }, 500);
            }

            return super.onFling(e1, e2, velocityX, velocityY);
        }

    }

    // Set Current Location
    public View showCurrentLocation() {
        try {
            if (mMapView != null) {

                mapOverlays = mMapView.getOverlays();
                drawable = getResources().getDrawable(R.drawable.loc_anim);
                // drawable = getResources().getDrawable(R.drawable.loc_anim);
                AnimationDrawable frameAnimation = (AnimationDrawable) drawable;
                // frameAnimation.setCallback(image);
                frameAnimation.setVisible(true, true);
                frameAnimation.start();

                itemizedOverlay_cur = new MyItemizedOverlay(drawable, mMapView);

                GeoPoint currentpoint = new GeoPoint((int) (Config.mLat * 1E6),
                        (int) (Config.mLong * 1E6));

                CustomOverlayItem curoverlayItem = new CustomOverlayItem(
                        currentpoint, "Current Location", "", 0, false);

                itemizedOverlay_cur.addOverlay(curoverlayItem);
                mapOverlays.add(itemizedOverlay_cur);

                final MapController mc = mMapView.getController();
                mc.animateTo(currentpoint);
                mc.setZoom(18);
               
                mMapView.invalidate();

                // Call Nearest Locations .......

                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        setCurrentBox();
                        checkType = Config.LOC_BOX;
                        mURL = Config.BASE_URL + "locations?box="
                                + (Config.mUpperLeft.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mUpperLeft.getLongitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLongitudeE6() / 1E6)
                                + "&radius=" + Config.RADIUS + "&key="
                                + Config.KEY;
                        new GetData().execute();
                    }
                }, 1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mMapViewContainer;
    }

    class DoneOnEditorActionListener implements OnEditorActionListener {

        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                InputMethodManager imm = (InputMethodManager) v.getContext()
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

                searchTxt = mEdit.getText().toString();
                if (searchTxt.equalsIgnoreCase(" ")) {
                    Toast.makeText(getParent(), R.string.search_empty,
                            Toast.LENGTH_SHORT).show();
                } else {
                    checkType = Config.LOC_NEAR_ADD;
                    mURL = Config.BASE_URL + "locations?loc=" + searchTxt
                            + "&key=" + Config.KEY;
                    new GetData().execute();
                }
                return true;
            }
            return false;
        }
    }

    class GetData extends AsyncTask<Void, Void, String> {

        GeoPoint goePoint;
        ProgressDialog progressDialog = new ProgressDialog(getParent());

        @Override
        protected void onPreExecute() {
//            Log.i("anisha", "keyboard9");
            super.onPreExecute();
            progressDialog.setCancelable(false);
            progressDialog.setMessage("Please wait");
            progressDialog.show();

//            Log.i("anisha", "dialog show");

            isPop = true;
            if (checkType.equalsIgnoreCase(Config.LOC_NEAR_ADD) || checkType.equalsIgnoreCase(Config.LOC_LAT_LONG_EDIT)) {
				//Config.ViewShow();
                ajax_loader.setVisibility(View.VISIBLE);
            }
//            ajax_loader.setVisibility(View.VISIBLE);
            if (mData != null) {
                mData.clear();

                refreshListIfClicked();
            }

            mCordinates = new ArrayList<GeoPoint>();
            mAvail = new ArrayList<ArrayList<String>>();
            mData = new ArrayList<>();
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
               Log.v("anisha", "mURL: " + mURL);

                RestClient client = new RestClient(
                        (mURL).replaceAll(" ", "%20"));

                client.AddHeader(
                        "Authorization",
                        "Basic "
                                + Base64.encodeToString(
                                Config.auth_para.getBytes(),
                                Base64.NO_WRAP));

                 client.Execute(RequestMethod.GET);
                String response = client.getResponse();
                Log.v("anisha", "response: " + response);
                return response;

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            Config.ViewDismiss();
            progressDialog.dismiss();
            mCordinates = new ArrayList<GeoPoint>();
            mAvail = new ArrayList<ArrayList<String>>();
            mData = new ArrayList<>();
            try{
                if (response != null) {
                    ArrayList<String> item = null;
                    ArrayList<String> singleCords = null;
                    ArrayList<String> singleAvail = null;

                    JSONArray jArray = new JSONArray(response);

                    Log.i("anisha", "Number of Stations from Server: " + jArray.length());

                    for (int i = 0; i < jArray.length(); i++) {

                        item = new ArrayList<String>();
                        singleCords = new ArrayList<String>();
                        singleAvail = new ArrayList<String>();

                        JSONObject json = jArray.getJSONObject(i);

                        item.add(json.getString("id"));
                        item.add(json.getString("name"));
                        item.add(json.getString("address1"));
                        item.add(json.getString("address2"));
                        item.add(json.getString("city"));
                        item.add(json.getString("state"));
                        item.add(json.getString("zip"));
                        item.add(json.getString("distance"));
                        item.add(json.getString("cost"));

                        JSONArray jCords = json.getJSONArray("coordinates");

                        singleCords.add(jCords.getString(0));
                        singleCords.add(jCords.getString(1));

                        double lat = Double.parseDouble(jCords.getString(0));
                        double lon = Double.parseDouble(jCords.getString(1));

                        goePoint = new GeoPoint((int) (lat * 1E6),
                                (int) (lon * 1E6));

                        JSONObject jAvails = json.getJSONObject("availability");
                        singleAvail.add(jAvails.getString("total"));
                        singleAvail.add(jAvails.getString("status"));
                        singleAvail.add(jAvails.getString("available"));

                        mCordinates.add(goePoint);
                        mAvail.add(singleAvail);

                        item.add(" " + lat);
                        item.add(" " + lon);

                        mData.add(item);

                    }

                    refreshListIfClicked();
                }
            }catch (Exception e){

            }
//            Log.i("anisha", "dialog dismiss");

            ajax_loader.setVisibility(View.GONE);
            panTouch = false;
			mEdit.setText("");
            if (checkType.equalsIgnoreCase(Config.LOC_LAT_LONG)) {
                showCurrentLocation();

            } else if (checkType.equalsIgnoreCase(Config.LOC_NEAR_ADD) || checkType.equalsIgnoreCase(Config.LOC_LAT_LONG_EDIT)) {
				mEdit.setText("");

                if (mAvail.size() > 0) {
                    showMap();

                      new Handler().postDelayed(new Runnable() {

					  @Override public void run() { setCurrentBox(); checkType
					  = Config.LOC_BOX; mURL = Config.BASE_URL +
					  "locations?box=" + (Config.mUpperLeft.getLatitudeE6() /
					  1E6) + "," + (Config.mUpperLeft.getLongitudeE6() / 1E6) +
					  "," + (Config.mBottomRight.getLatitudeE6() / 1E6) + "," +
					  (Config.mBottomRight.getLongitudeE6() / 1E6) + "&radius="
					  + Config.RADIUS + "&key=" + Config.KEY; 
                          mMapView.getMapCenter();
                          new GetData().execute();
                      } }, 1000);

                } else {
                    if (searchTxt.length() == 0 || searchTxt == null || TextUtils.isEmpty(searchTxt) || searchTxt.equalsIgnoreCase(" ")) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(
                                getParent());
                        builder.setTitle("Search stations");
                        builder.setIcon(R.drawable.ic_launcher);
                        builder.setMessage("Provide a valid zipcode, city or state to locate stations.");
                        builder.setPositiveButton(" Ok ",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        dialog.dismiss();

                                    }
                                });
                        builder.create().show();

                    } else if(searchTxt.length() > 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(
                                getParent());
                        builder.setTitle("Search stations");
                        builder.setIcon(R.drawable.ic_launcher);
                        builder.setMessage("Cannot locate or no stations found near " + searchTxt);
                        builder.setPositiveButton(" Ok ",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        dialog.dismiss();
                                        onCreateMapScreen(false);
                                        resumeMap();
                                    }
                                });
                        builder.create().show();

                    }
                }
            } else {
                showMap();
            }

            isPop = false;

            refreshListIfClicked();
        }
    }

    private void refreshListIfClicked(){
//        Log.i("anisha", "keyboard10");
        if (Config.listButtonClicked == true){

            runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
//                  Toast.makeText(MapScreen.this,"Refreshing List",Toast.LENGTH_SHORT).show();
                    Config.listButtonClicked = false;
                    LocationListView.refreshList();
                }
            });

        }
    }

    private View showMap() {
//        Log.i("anisha", "keyboard11");
        if (mMapView != null) {

            if (mapOverlays != null) {
                if (itemizedOverlay != null) {
                    itemizedOverlay.hideAllBalloons();
                }
                mapOverlays.clear();
                mMapView.getOverlays().clear();
            }

            mapOverlays = mMapView.getOverlays();

            drawable = getResources().getDrawable(R.drawable.loc_anim);

            // drawable = getResources().getDrawable(R.drawable.loc_anim);
            // AnimationDrawable frameAnimation = (AnimationDrawable)
            // draw_anim.getDrawable();
            AnimationDrawable frameAnimation = new AnimationDrawable();

            // frameAnimation.addFrame(getResources().getDrawable(R.drawable.location_off),
            // 150);
            frameAnimation.addFrame(
                    getResources().getDrawable(R.drawable.loc_anim), 150);
            frameAnimation.setCallback(frameAnimation);
            frameAnimation.setOneShot(false);
            frameAnimation.setVisible(true, true);
            frameAnimation.start();

            itemizedOverlay_cur = new MyItemizedOverlay(frameAnimation,
                    mMapView);

            GeoPoint currentpoint = new GeoPoint((int) (Config.mLat * 1E6),
                    (int) (Config.mLong * 1E6));

            CustomOverlayItem curoverlayItem = new CustomOverlayItem(
                    currentpoint, "Current Location", "", 0, false);

            itemizedOverlay_cur.addOverlay(curoverlayItem);

            mapOverlays.add(itemizedOverlay_cur);
//            Log.i("anisha","mCordinates: "+mCordinates);

            if (mCordinates != null) {

                for (int i = 0; i < mCordinates.size(); i++) {
//                    Log.i("anisha","mAvail" + mAvail + i);
                    if (mAvail.get(i).get(1).equals("available")) {
                        drawable = getResources().getDrawable(
                                R.drawable.map_pin_available);
                    } else if (mAvail.get(i).get(1).equals("offline")) {
                        drawable = getResources().getDrawable(
                                R.drawable.map_pin_offline);
                    } else if (mAvail.get(i).get(1).equals("in use")) {
                        drawable = getResources().getDrawable(
                                R.drawable.map_pin_in_use);
                    } else {
                        drawable = getResources().getDrawable(
                                R.drawable.map_pin_oos);
                    }


                    itemizedOverlay = new MyItemizedOverlay(drawable, mMapView);
                    int w = drawable.getIntrinsicWidth();
                    int h = drawable.getIntrinsicHeight();
                    drawable.setBounds(-w / 2, -h, w / 2, 0);
                    CustomOverlayItem overlayItem = new CustomOverlayItem(
                            mCordinates.get(i), mData.get(i).get(1) + " "
                            + mData.get(i).get(3),
                            mData.get(i).get(8) + " | "
                                    + mAvail.get(i).get(2) + " of "
                                    + mAvail.get(i).get(0)
                                    + " Available", i, true);
                    itemizedOverlay.addOverlay(overlayItem);
                    mapOverlays.add(itemizedOverlay);

                    final MapController mc = mMapView.getController();
                    if (checkType.equalsIgnoreCase(Config.LOC_NEAR_ADD)) {
                        mc.animateTo(mCordinates.get(0));
                        mMapView.getZoomButtonsController();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                setCurrentBox();
                            }
                        }, 500);
                    }
                    // mc.setZoom(13);

                }

                // /// ADD Current Location
                // LayoutInflater anim_inflate =
                // LayoutInflater.from(getActivity());
                // View v = anim_inflate.inflate(R.layout.anim_draw, null);
                // ImageView draw_anim = (ImageView)
                // v.findViewById(R.id.anim_drawable);

                mMapView.invalidate();

            } else {
                showCurrentLocation();
            }

        }
        return mMapViewContainer;
    }

    private class GestureListener extends
            SimpleOnGestureListener {

        @Override
        public boolean onDoubleTap(MotionEvent e) {

            final MapController mc = mMapView.getController();
            mc.zoomIn();

            return false;
        }
    }

    private boolean checkConnection() {

        ConnectivityManager cm = (ConnectivityManager) getParent()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        }
        return false;
    }

    private static Runnable finishBalloonInflation = new Runnable() {
        public void run() {
            isInflating = false;
        }
    };

    public class MyItemizedOverlay extends
            BalloonItemizedOverlay<CustomOverlayItem> {

        private ArrayList<CustomOverlayItem> m_overlays = new ArrayList<CustomOverlayItem>();
        private Context c;

        MapView mapView ;
        MapController mc;

        /*@Override
        public void draw(android.graphics.Canvas canvas, MapView mapView, boolean shadow) {
            super.draw(canvas, mapView, false);
        }		*/
        public MyItemizedOverlay(Drawable defaultMarker, MapView mapView) {
            super(boundCenter(defaultMarker), mapView);

            c = mapView.getContext();
            this.mapView = mapView;
            hideAllBalloons();
            viewOffset = 0;
            mc = mapView.getController();
            mapView.invalidate();
        }

        protected void animateTo(int index, GeoPoint center) {
            mc.animateTo(center);
        }

        public void bringBalloonToFront() {
            if (balloonView != null) {
                balloonView.bringToFront();
            }
        }

        public void hideBalloon() {
            if (balloonView != null) {
                balloonView.setVisibility(View.GONE);
            }
            currentFocusedItem = null;
        }

        public void setBalloonBottomOffset(int pixels) {
            viewOffset = pixels;
        }

        public int getBalloonBottomOffset() {
            return viewOffset;
        }

        public void addOverlay(CustomOverlayItem overlay) {
            m_overlays.add(overlay);
            populate();
        }

        @Override
        protected CustomOverlayItem createItem(int i) {
            return m_overlays.get(i);
        }

        @Override
        public int size() {
            return m_overlays.size();
        }

        @Override
        protected BalloonOverlayView<CustomOverlayItem> createBalloonOverlayView() {
            // TODO Auto-generated method stub
           // return super.createBalloonOverlayView();
            return new BalloonOverlayView<CustomOverlayItem>(getMapView().getContext(), getBalloonBottomOffset());
        }

        private BalloonOverlayView<CustomOverlayItem> balloonView;
        private View clickRegion;
        private View closeRegion;
        private int viewOffset;
        private boolean showClose = true;
        private CustomOverlayItem currentFocusedItem;
        private int currentFocusedIndex;
        private int pos;
        private boolean ballonLock = true;
        private boolean snapToCenter = true;
        private boolean showDisclosure = false;

        private boolean createAndDisplayBalloonOverlay() {
            boolean isRecycled;
            if (balloonView == null) {
                balloonView = createBalloonOverlayView();
                clickRegion = (View) balloonView
                        .findViewById(R.id.balloon_inner_layout);
                clickRegion.setOnTouchListener(createBalloonTouchListener());
                closeRegion = (View) balloonView
                        .findViewById(R.id.balloon_close);

                if (closeRegion != null) {
                    if (!showClose) {
                        closeRegion.setVisibility(View.GONE);
                    } else {
                        closeRegion.setOnClickListener(new OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                hideBalloon();
                            }
                        });
                    }
                }
                // if (showDisclosure && !showClose) {
                View v = balloonView.findViewById(R.id.balloon_disclosure);
                if (v != null) {
                    v.setVisibility(View.VISIBLE);
                }
                v.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        callNewFrag();
                    }
                });
                // }
                isRecycled = false;
            } else {
                isRecycled = true;
            }

            balloonView.setVisibility(View.GONE);

            List<Overlay> mapOverlays = mapView.getOverlays();
            if (mapOverlays.size() > 1) {
                hideOtherBalloons(mapOverlays);
            }

            if (currentFocusedItem != null)
                pos = currentFocusedItem.getPosition();
            ballonLock = currentFocusedItem.getBalloonLock();
            balloonView.setData(currentFocusedItem);

            GeoPoint point = currentFocusedItem.getPoint();
            MapView.LayoutParams params = new MapView.LayoutParams(
                    LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                    point, MapView.LayoutParams.BOTTOM_CENTER);
            params.mode = MapView.LayoutParams.MODE_MAP;

            balloonView.setVisibility(View.VISIBLE);

            if (isRecycled) {
                balloonView.setLayoutParams(params);
            } else {
                mapView.addView(balloonView, params);
            }

            return isRecycled;
        }

        private OnTouchListener createBalloonTouchListener() {
            return new OnTouchListener() {

                float startX;
                float startY;

                public boolean onTouch(View v, MotionEvent event) {

                    View l = ((View) v.getParent())
                            .findViewById(R.id.balloon_main_layout);
                    Drawable d = l.getBackground();

                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        if (d != null) {
                            int[] states = {android.R.attr.state_pressed};
                            if (d.setState(states)) {
                                d.invalidateSelf();
                            }
                        }
                        startX = event.getX();
                        startY = event.getY();
                        return true;
                    } else if (event.getAction() == MotionEvent.ACTION_UP) {
                        if (d != null) {
                            int newStates[] = {};
                            if (d.setState(newStates)) {
                                d.invalidateSelf();
                            }
                        }
                        if (Math.abs(startX - event.getX()) < 40
                                && Math.abs(startY - event.getY()) < 40) {
                            onBalloonTap(currentFocusedIndex,
                                    currentFocusedItem);
                        }
                        callNewFrag();
                        return true;
                    } else {
                        return false;
                    }

                }
            };
        }

        private void hideOtherBalloons(List<Overlay> overlays) {
            for (Overlay overlay : overlays) {
                if (overlay instanceof BalloonItemizedOverlay<?>
                        && overlay != this) {
                    ((BalloonItemizedOverlay<?>) overlay).hideBalloon();
                }
            }
        }

        private void callNewFrag() {
            try {
                if (MapScreen.mData.size() > 0) {
                    if (MapScreen.mData.get(pos) != null) {
                        Intent i = new Intent(MapScreen.this,
                                StationDetails.class);
                        i.putExtra("title", "Location Details");
                        i.putExtra("id", MapScreen.mData.get(pos).get(0));
                        i.putExtra("name", MapScreen.mData.get(pos).get(1));
                        i.putExtra("miles", MapScreen.mData.get(pos).get(7));
                        i.putExtra("lat", MapScreen.mData.get(pos).get(9));
                        i.putExtra("longi", MapScreen.mData.get(pos).get(10));

                        i.putExtra("total", MapScreen.mAvail.get(pos).get(0));
                        i.putExtra("status", MapScreen.mAvail.get(pos).get(1));
                        i.putExtra("available", MapScreen.mAvail.get(pos).get(2));

                        TabGroupActivity parentActivity = (TabGroupActivity) getParent();
                        parentActivity.startChildActivity("station_detail", i);
                    }
                } else {
                    Log.e("###", "No data ###");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static final long BALLOON_INFLATION_TIME = 300;

        protected boolean onTap(int index) {

            handler.removeCallbacks(finishBalloonInflation);
            isInflating = true;
            handler.postDelayed(finishBalloonInflation, BALLOON_INFLATION_TIME);

            currentFocusedIndex = index;
            currentFocusedItem = createItem(index);
            setLastFocusedIndex(index);

            onBalloonOpen(index);
            if (!isPop) {
                if (ballonLock) {
                    createAndDisplayBalloonOverlay();
                }
            }

            if (snapToCenter) {
                animateTo(index, currentFocusedItem.getPoint());
            }

            return true;
        }
        protected MyMapView getMapViewListener(){
            return mMapViewListener;
        }


        @Override
        public void setFocus(CustomOverlayItem item) {
            super.setFocus(item);
            currentFocusedIndex = getLastFocusedIndex();
            currentFocusedItem = item;
            if (currentFocusedItem == null) {
                hideAllBalloons();
            } else {
                createAndDisplayBalloonOverlay();
            }
        }

        public void setShowClose(boolean showClose) {
            this.showClose = showClose;
        }

        public void setShowDisclosure(boolean showDisclosure) {
            this.showDisclosure = showDisclosure;
        }

        public void setSnapToCenter(boolean snapToCenter) {
            this.snapToCenter = snapToCenter;
        }
    }

    public static boolean isInflating() {
        return isInflating;
    }

    @Override
    protected boolean isRouteDisplayed() {
        // TODO Auto-generated method stub
        return false;
    }

    private class PlacesTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... place) {
//            Log.i("anisha", "keyboard12");
            // For storing data from web service
            String data = "";

            // Obtain browser key from https://code.google.com/apis/console
            String key = "key=" + getString(R.string.google_maps_auto_api_key);

            String input="";

            try {
                input = "input=" + URLEncoder.encode(place[0], "utf-8");
            } catch (UnsupportedEncodingException e1) {
                e1.printStackTrace();
            }


            // place type to be searched
            String types = "types=geocode";

            // Sensor enabled
            String sensor = "sensor=false";

            // Building the parameters to the web service
            String parameters = input+"&"+types+"&"+sensor+"&"+key;

            // Output format
            String output = "json";

            // Building the url to the web service
            String url = "https://maps.googleapis.com/maps/api/place/autocomplete/"+output+"?"+parameters;

            Log.i("semaconnect", "URL: " + url);

            try {
                // Fetching the data from web service in background
                data = downloadUrl(url);
            } catch (Exception e) {
                Log.i("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Creating ParserTask
            parserTask = new ParserTask();

            // Starting Parsing the JSON string returned by Web Service
            parserTask.execute(result);
        }
    }


    /**
     * A class to parse the Google Places in JSON format
     */
    private class ParserTask extends AsyncTask<String, Integer, List<HashMap<String, String>>> {

        JSONObject jObject;

        @Override
        protected List<HashMap<String, String>> doInBackground(String... jsonData) {
            places = null;

            PlaceJSONParser placeJsonParser = new PlaceJSONParser();

            try {
                jObject = new JSONObject(jsonData[0]);

                // Getting the parsed data as a List construct
                places = placeJsonParser.parse(jObject);
            } catch (Exception e) {
                Log.i("Exception", e.toString());
            }
            return places;
        }

        @Override
        protected void onPostExecute(List<HashMap<String, String>> result) {
//            Log.i("anisha", "keyboard13");
            if (result == null || result.size()<=0){
                // Do Nothing. We don't have Result
            }else {
                String[] from = new String[]{"description"};
                int[] to = new int[]{android.R.id.text1};

                // Creating a SimpleAdapter for the AutoCompleteTextView
                SimpleAdapter adapter = new SimpleAdapter(getBaseContext(), result, R.layout.simple_list_dropdown, from, to);

                // Setting the adapter
                mEdit.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        }
    }


    /**
     * A class to parse the Longitude and Latitude
     */
    private class LatLongTask extends AsyncTask<String, Integer, Double[]> {

        JSONObject jObject;

        @Override
        protected Double[] doInBackground(String... jsonData) {
            return getLatLong(jsonData[0]);
        }

        @Override
        protected void onPostExecute(Double[] result) {
            if (result == null){
                Toast.makeText(MapScreen.this, "Please select the correct Location !!!", Toast.LENGTH_SHORT).show();
                return;
            }else{
                checkType = Config.LOC_LAT_LONG_EDIT;
                mURL = Config.BASE_URL + "locations?loc=" + result[0]+","+result[1]
                        + "&key=" + Config.KEY;
                new GetData().execute();
            }
        }
    }

    public Double[] getLatLong(String placeId) {
        Double[] latLng = new Double[2];
        HttpURLConnection conn = null;
        String jsonResults = "";

        try {
            StringBuilder sb = new StringBuilder("https://maps.googleapis.com/maps/api/place/details/json");
            sb.append("?key=" + getString(R.string.google_maps_auto_api_key));
            sb.append("&placeid=" + URLEncoder.encode(placeId, "utf8"));

            Log.i("semaconnect", "URL: " + sb.toString());

            jsonResults = downloadUrl(sb.toString());
        } catch (MalformedURLException e) {
            Log.e("semaconnect", "Error processing Places API URL", e);
            return latLng;
        } catch (IOException e) {
            Log.e("semaconnect", "Error connecting to Places API", e);
            return latLng;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        try {
            // Log.i(TAG, jsonResults.toString());

            // Create a JSON object hierarchy from the results
            Log.i("semaconnect", "jsonResults: " + jsonResults);
            JSONObject jsonObj = new JSONObject(jsonResults.toString());
            JSONObject resultObj = jsonObj.optJSONObject("result");
            JSONObject geometryJSONObject = resultObj.optJSONObject("geometry");
            JSONObject locationJSONObject = geometryJSONObject
                    .optJSONObject("location");

            double latitude = locationJSONObject.optDouble("lat");
            double longitude = locationJSONObject.optDouble("lng");

            latLng[0] = latitude;
            latLng[1] = longitude;

            Log.i("semaconnect", "latLng: " + latLng);
        } catch (JSONException e) {
            Log.e("semaconnect", "Cannot process JSON results", e);
        }

        return latLng;

    }

    private void updateGoogleMap() {
//        Toast.makeText(MapScreen.this, "Selected: " + mEdit.getText().toString(), Toast.LENGTH_SHORT).show();
        String selectedLocation = mEdit.getText().toString();
        if (TextUtils.isEmpty(selectedLocation)) {
            Toast.makeText(MapScreen.this, "Fetching Current Location !!!", Toast.LENGTH_SHORT).show();
            Log.i("semaconnect", "selectedLocation: " + selectedLocation);
            showCurrentLocation();
            return;
        } else {
            String placeId = "";

            if (places == null || places.isEmpty()){

            }else{
                for (HashMap<String, String> hashMap : places) {
                    placeId = hashMap.get(selectedLocation);
                    if (TextUtils.isEmpty(placeId)) {

                    } else {
                        break;
                    }
                }

                if (TextUtils.isEmpty(placeId)) {
                   // Toast.makeText(MapScreen.this, "Please select the correct Location !!!", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    new LatLongTask().execute(placeId);
                }
            }
        }

    }

//    Runnable mStatusChecker = new Runnable() {
//        @Override
//        public void run() {
//            try {
////                updateGoogleMap(); //this function can change value of mInterval.
//                mEdit.setText("");
//                imm.hideSoftInputFromWindow(mEdit.getWindowToken(), 0);
//                showCurrentLocation();
//            } finally {
//                // 100% guarantee that this always happens, even if
//                // your update method throws an exception
//                mHandler.postDelayed(mStatusChecker, mInterval);
//            }
//        }
//    };
//
//    void startRepeatingTask() {
//        mStatusChecker.run();
//    }
//
//    void stopRepeatingTask() {
//        mHandler.removeCallbacks(mStatusChecker);
//    }

//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        stopRepeatingTask();
//    }

    public View showWashingtonLocation() {
        try {
            if (mMapView != null) {
                mapOverlays = mMapView.getOverlays();
                drawable = getResources().getDrawable(R.drawable.loc_anim);
                // drawable = getResources().getDrawable(R.drawable.loc_anim);
                AnimationDrawable frameAnimation = (AnimationDrawable) drawable;
                // frameAnimation.setCallback(image);
                frameAnimation.setVisible(true, true);
                frameAnimation.start();

                itemizedOverlay_cur = new MyItemizedOverlay(drawable, mMapView);

                GeoPoint currentpoint = new GeoPoint((int) (38.889931 * 1E6),
                        (int) (-77.009003 * 1E6));

                CustomOverlayItem curoverlayItem = new CustomOverlayItem(
                        currentpoint, "Current Location", "", 0, false);

                itemizedOverlay_cur.addOverlay(curoverlayItem);
                mapOverlays.add(itemizedOverlay_cur);

                final MapController mc = mMapView.getController();
                mc.animateTo(currentpoint);
                mc.setZoom(18);
            
                mMapView.invalidate();

                // Call Nearest Locations .......

                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        setCurrentBox();
                        checkType = Config.LOC_BOX;
                        mURL = Config.BASE_URL + "locations?box="
                                + (Config.mUpperLeft.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mUpperLeft.getLongitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLatitudeE6() / 1E6)
                                + ","
                                + (Config.mBottomRight.getLongitudeE6() / 1E6)
                                + "&radius=" + Config.RADIUS + "&key="
                                + Config.KEY;
                        new GetData().execute();
                    }
                }, 1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mMapViewContainer;
    }

}
