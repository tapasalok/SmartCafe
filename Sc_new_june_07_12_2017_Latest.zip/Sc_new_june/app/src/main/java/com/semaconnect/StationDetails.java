package com.semaconnect;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONObject;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.maps.Overlay;
import com.semaconnect.utility.Config;
import com.semaconnect.utility.MyItemizedOverlay;
import com.semaconnect.utility.RestClient;
import com.semaconnect.utility.RestClient.RequestMethod;

public class StationDetails extends AppCompatActivity implements OnItemSelectedListener ,GoogleMap.OnMarkerClickListener,
		GoogleMap.OnInfoWindowClickListener,
		GoogleMap.OnMarkerDragListener,
		OnMapReadyCallback,
		GoogleMap.OnInfoWindowLongClickListener,
		GoogleMap.OnInfoWindowCloseListener {

	private View pi_View;
	private WebView pi_Graph;
    private Button mChargeBtn;
	private ImageButton station_reportbtn;
	private ImageButton station_supportbtn;
	public ImageLoader imageLoader;

	public static int mGalleryPos;

	private int mPos;
	int index;
	boolean firstFlag = false;

	private TextView mTitle, mTop_text, mAdd1, mAdd2, mMiles, mAvail_status,
			city, mon, tue, wed, thu, fri, sat, sun;

	private TextView charge;
	private TextView station_notes;
	private TextView station_notes_head;

	private String mId, mGet_Miles;

	private LinearLayout mMsgBox1;
	private RelativeLayout mMsgBox2, mMsgBox3;

	private TextView mStOnePrice, mStTwoPrice, mStThreePrice;
	private TextView mStOneMsg1, mStOneMsg2, mStOneMsg3;
	private TextView mStTwoMsg1, mStTwoMsg2, mStTwoMsg3;

	private ArrayList<String> mData = null;
	private ArrayList<String> mCords = null;
	private ArrayList<String> mStatCords = null;
	private ArrayList<String> mAvailable = null;
	private ArrayList<ArrayList<String>> mStations = null;
	private ArrayList<String> mHour = null;
	private ArrayList<String> mPhotoList = null;
	private ArrayList<ArrayList<String>> mPriceList = null;

	private ArrayList<String> item = null;
	private ArrayList<String> pItem = null;

	private String mResponse = "";
	String notes;

	private String mStationId = "";
	private int mTotal, mAvailable_st, mInuse, mOffline, mOutOfService;

	private ImageView mStationWebView;
	private ScrollView fullPage;

	private RelativeLayout stationGridLay;
	List<Overlay> mapOverlays;
	Drawable drawable;
	MyItemizedOverlay itemizedOverlay;
	private Gallery mStationGallery;

	private Gallery mGridView;

	String chargStation;

	private final String ACTION_DIAL = "android.intent.action.DIAL";

	StringBuilder PowerList, energyList;
	ArrayList<String> timeList;

	LazyAdapter adapter;

//	New Map implementation starts here

	private static LatLng SINGLE_LOCATION = new LatLng(0, 0);
	private static LatLng CURRENT_LOCATION = new LatLng(Config.mLat, Config.mLong);
	private GoogleMap mMap;
	private Marker mBrisbane;
	private Marker currentLocation;
	/**
	 * Keeps track of the last selected marker (though it may no longer be selected).  This is
	 * useful for refreshing the info window.
	 */
	private Marker mLastSelectedMarker;
	private final List<Marker> mMarkerRainbow = new ArrayList<Marker>();
	private TextView mTopText;
	private TextView mTagText;
	private final Random mRandom = new Random();
	private String lat = "0";
	private String longi = "0";
	private String name = "";
	private String total = "";
	private String status = "";
	private String available = "";
    private SharedPreferences settings;
	private SharedPreferences.Editor editor;
    int remainingSize;

	FragmentManager manager;
	@Override
	protected void onResume() {
		super.onResume();
		try {
			mChargeBtn.setVisibility(View.VISIBLE);
			// GridView and Gallery Adapter call is not required
            changeChargingButton(false);

			// Go to the First Gallery with Login To Charge Button i.e. position 0 if User is logged out (Not Logged in)
			if (!isUserLoggedIn()) {
				((MGalleryAdapter) (mGridView.getAdapter())).notifyDataSetChanged();
				mGridView.setSelection(0);
				mGalleryPos = 0;
				((MGalleryAdapter) (mGridView.getAdapter()))
						.notifyDataSetChanged();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

  
    /**
     * This method is used for changing the Button to "Login to Charge" or "Charge Now" depending on whether the user is logged in or not.
     * and It will affect the GridView and Gallery of the Station Names.
     */
    private void changeChargingButton(final boolean isAdapterRequired) {
        settings = getSharedPreferences("session_auth", 0);
        String user = settings.getString("username", "");
        String password = settings.getString("password", "");

        editor = settings.edit();
        editor.putBoolean("donotshowMA", false);
        editor.commit();

        try{
            mChargeBtn = (Button) pi_View.findViewById(R.id.pi_charge_now_btn);

            /**
             * check for userName & password field is empty or not & length is more than 0 or not
             * display chargeNow button & StationGrid
             */
            if (isUserLoggedIn()) {
                mChargeBtn.setText("");
				mChargeBtn.setBackground(getResources().getDrawable(R.drawable.chargenowbtn));

				if (isAdapterRequired){
                mGridView.setAdapter(new MGalleryAdapter(getParent(), false));
                ((MGalleryAdapter) (mGridView.getAdapter()))
                        .notifyDataSetChanged();
				}
            } else {
              /*  display logInNow button*/
				if (isAdapterRequired){
					mGridView.setAdapter(new MGalleryAdapter(getParent(), true));
//					((MGalleryAdapter) (mGridView.getAdapter()))
//							.notifyDataSetChanged();
				}
                mChargeBtn.setText("Login to Charge");
                mChargeBtn.setBackground(getResources().getDrawable(R.drawable.loginnowbtn));
            }
        }catch (Exception e){

        }
    }

	private void initView() {

		mPos = 0;
		fullPage = (ScrollView) findViewById(R.id.st_detail_page);

		station_supportbtn = (ImageButton) findViewById(R.id.station_supportbtn);
		station_reportbtn = (ImageButton) findViewById(R.id.station_reportbtn);

		city = (TextView) findViewById(R.id.city);

		mTitle = (TextView) findViewById(R.id.top_title_txt);
		mTitle.setText(R.string.location_details);

		mTop_text = (TextView) findViewById(R.id.title);
		mAdd1 = (TextView) findViewById(R.id.address1);
		mAdd2 = (TextView) findViewById(R.id.address2);
		mMiles = (TextView) findViewById(R.id.milesTxt);

		charge = (TextView) findViewById(R.id.station_charge);

		mon = (TextView) findViewById(R.id.mon);
		tue = (TextView) findViewById(R.id.tue);
		wed = (TextView) findViewById(R.id.wed);
		thu = (TextView) findViewById(R.id.thu);
		fri = (TextView) findViewById(R.id.fri);
		sat = (TextView) findViewById(R.id.sat);
		sun = (TextView) findViewById(R.id.sun);

		mData = new ArrayList<String>();
		mStations = new ArrayList<ArrayList<String>>();
		mCords = new ArrayList<String>();
		mStatCords = new ArrayList<String>();
		mAvailable = new ArrayList<String>();
		mHour = new ArrayList<String>();
		mPriceList = new ArrayList<ArrayList<String>>();

		mGridView = (Gallery) findViewById(R.id.grid_item);

		station_notes = (TextView) findViewById(R.id.station_notes);
		station_notes_head = (TextView) findViewById(R.id.station_notes_head);

		// Price List :::

		mMsgBox1 = (LinearLayout) findViewById(R.id.msg_type_box1);
		mStOnePrice = (TextView) findViewById(R.id.station_charge);
		mStOneMsg1 = (TextView) findViewById(R.id.station_charge_msg1);
		mStTwoMsg1 = (TextView) findViewById(R.id.station_charge_msg2);

		mMsgBox2 = (RelativeLayout) findViewById(R.id.msg_type_box2);
		mStTwoPrice = (TextView) findViewById(R.id.station_charge2);
		mStOneMsg2 = (TextView) findViewById(R.id.station_charge2_msg1);
		mStTwoMsg2 = (TextView) findViewById(R.id.station_charge2_msg2);

		mMsgBox3 = (RelativeLayout) findViewById(R.id.msg_type_box3);
		mStThreePrice = (TextView) findViewById(R.id.station_charge3);
		mStOneMsg3 = (TextView) findViewById(R.id.station_charge3_msg1);
		mStTwoMsg3 = (TextView) findViewById(R.id.station_charge3_msg2);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.station_detail);

        settings = getSharedPreferences("session_auth", 0);

		initView();

		TextView titleTxt = (TextView) findViewById(R.id.top_title_txt);
		Bundle args = getIntent().getExtras();

		titleTxt.setText(args.get("title").toString());
		mId = args.getString("id");
		mGet_Miles = args.getString("miles");
		lat = args.getString("lat");
		longi = args.getString("longi");
		name = args.getString("name");

		total = args.getString("total");
		status = args.getString("status");
		available = args.getString("available");

		Log.i("semaconnect", "Current Latitude: " + lat);
		Log.i("semaconnect", "Current Longitude: " + longi);

		Double latDouble = 0.0;
		Double longiDouble = 0.0;
		try {
			latDouble = Double.parseDouble(lat);
			longiDouble = Double.parseDouble(longi);
		} catch (Exception e) {
			latDouble = 0.0;
			longiDouble = 0.0;
		}

		SINGLE_LOCATION = new LatLng(latDouble, longiDouble);

		DisplayMetrics metrics = new DisplayMetrics();
		getParent().getWindowManager().getDefaultDisplay().getMetrics(metrics);

		mStationGallery = (Gallery) findViewById(R.id.station_gallery);
		stationGridLay = (RelativeLayout) findViewById(R.id.station_gridrel_lay);

		mStationGallery.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> view, View v, int pos,
									long id) {
				if (mPhotoList.size() > 0) {
					ImageActivity f = new ImageActivity();
					Bundle bundle = new Bundle();
					bundle.putString("photo_id", "" + mPhotoList.get(pos));
					f.setArguments(bundle);

					//StackGallery
					Intent i = new Intent(getParent(), StackGallery.class);
					i.putExtra("photo_id", "" + mPhotoList.get(pos));
					TabGroupActivity parentActivity = (TabGroupActivity) getParent();
					parentActivity.startChildActivity("station_gallery", i);

					// ((ActivityInTab) getActivity()).navigateTo(f);
				}
			}
		});

		station_supportbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					startActivity(new Intent(ACTION_DIAL, Uri
							.parse(getResources().getString(R.string.tel_no))));
				} catch (Exception e) {
				}
			}
		});
		station_reportbtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent mIntent = new Intent(StationDetails.this, StackReport.class);
				mIntent.putExtra("title", "Report Problem");
				mIntent.putExtra("navigate", "stationDetails");
				TabGroupActivity parentActivity = (TabGroupActivity) getParent();
				parentActivity.startChildActivity("report_problem", mIntent);
			}
		});

		/*
		 * MarginLayoutParams mlp = (MarginLayoutParams) mStationGallery
		 * .getLayoutParams(); mlp.setMargins(-((metrics.widthPixels / 2) + 30),
		 * mlp.topMargin, mlp.rightMargin, mlp.bottomMargin);
		 */

		new GetData().execute();

		ImageButton directionBtn = (ImageButton) findViewById(R.id.station_dirBtn);

		directionBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mCords != null && mCords.size() > 0) {
					/*
					 * Intent intent = new
					 * Intent(android.content.Intent.ACTION_VIEW,
					 * Uri.parse("http://maps.google.com/maps?saddr="
					 * +mCords.get(0)+","+mCords.get(1)));
					 * startActivity(intent);
					 */
					try {
						/*
						 * Intent intent = new Intent(
						 * android.content.Intent.ACTION_VIEW, Uri
						 * .parse("geo:0,0?q=" + mCords.get(0) + "," +
						 * mCords.get(1) + ""));
						 */

						Intent intent = new Intent(
								android.content.Intent.ACTION_VIEW,
								Uri.parse("http://maps.google.com/maps?saddr="
										+ Config.mLat + "," + Config.mLong
										+ "&daddr=" + mCords.get(0) + ","
										+ mCords.get(1) + ""));
						startActivity(intent);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});

		mGridView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int pos,
									long id) {
				/*
				 * mStationId = mStations.get(pos).get(0); if (!Config.loginChk)
				 * { authError(
				 * "You Must have to login before before start new charging session."
				 * ); } else { chargStation = mStations.get(pos).get(1);
				 * authDialog("Authorize charging session at " + chargStation +
				 * " ?"); }
				 */
			}
		});

		// New Map implementation starts here
		mTagText = (TextView) findViewById(R.id.tag_text);
		if (mMap == null){
			SupportMapFragment mapFragment =
					(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
		mapFragment.getMapAsync(this);
	}
}


	public class LazyAdapter extends BaseAdapter {

		int mGalleryItemBackground;
		private Context mContext;

		private String[] data;
		private LayoutInflater inflater = null;

		public LazyAdapter(Context c, String[] d) {
			mContext = c;
			data = d;
			inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			imageLoader = new ImageLoader(getParent());
		}

		public int getCount() {
			return data.length;
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {

			ImageView i = new ImageView(mContext);
			ProgressBar pBar = new ProgressBar(getParent(), null,
					android.R.attr.progressBarStyleSmall);

			i.setLayoutParams(new Gallery.LayoutParams(70, 150));
			i.setScaleType(ImageView.ScaleType.CENTER_CROP);
			i.setBackgroundResource(mGalleryItemBackground);

			imageLoader.DisplayImage(data[position], i, pBar);

			return i;
		}
	}

    /**
     *
     * @return pi_view
     */
	private View showPiChartView() {
        mGalleryPos = 0;
		String chart_data1 = "";
		pi_View = LayoutInflater.from(getParent()).inflate(
				R.layout.pi_graph_view, null);

		mAvail_status = (TextView) pi_View.findViewById(R.id.pi_avail_station);
		pi_Graph = (WebView) pi_View.findViewById(R.id.pi_graph);
        mChargeBtn = (Button) pi_View.findViewById(R.id.pi_charge_now_btn);

		// Adapter call is required to change the GridView and Gallery
        changeChargingButton(true);

		mChargeBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// mViewChanger.setVisibility(View.GONE);
				// stationGridLay.setVisibility(View.VISIBLE);

                if (isUserLoggedIn()) {
				((MGalleryAdapter) (mGridView.getAdapter()))
						.notifyDataSetChanged();
				mGridView.setSelection(mGalleryPos + 1);
                    mGalleryPos = mGalleryPos + 1;
                    ((MGalleryAdapter) (mGridView.getAdapter()))
                            .notifyDataSetChanged();
                } else {
                    editor = settings.edit();
                    editor.putBoolean("showLogin", false);
                    editor.putBoolean("donotshowMA", true);
                    editor.commit();
                    Intent intent = new Intent(StationDetails.this, StackHome.class);
                    startActivity(intent);
                }
			}
		});

		Log.v("mAvailable :: ", "" + mAvailable);
		mAvail_status.setText(mAvailable.get(2) + "/" + mAvailable.get(0));

		try {
			chart_data1 = "t:" + mAvailable_st + "," + mInuse + "," + mOffline
					+ "," + mOutOfService;

		} catch (Exception e) {
			e.printStackTrace();
		}

		String mUrl = "http://chart.apis.google.com/chart?cht=p&chs="
				+ Config.pi_Graph + "&chd=" + chart_data1
				+ "&chco=0054A6,39B54A,898989,AF0C10";

		Log.v("Graph Url", "" + mUrl);

		pi_Graph.getSettings().setJavaScriptEnabled(true);
		pi_Graph.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
//        pi_Graph.loadUrl(mUrl);
		pi_Graph.setWebViewClient(new MyWebView());
        String dataString = "<html><head><style type='text/css'>body{margin:auto auto;text-align:center;}</style></head><body><img src='" + mUrl + "'/></body></html>";
        pi_Graph.loadData( dataString ,"text/html",  "UTF-8");

		// Go to the Second Gallery i.e. position 1 if User is already logged in
		if (isUserLoggedIn()) {
			((MGalleryAdapter) (mGridView.getAdapter())).notifyDataSetChanged();
			mGridView.setSelection(1);
			mGalleryPos = 1;
			((MGalleryAdapter) (mGridView.getAdapter()))
					.notifyDataSetChanged();
		}

		return pi_View;
	}

	/*
	returns true if user is already logged in else it will return false
    */
	private boolean isUserLoggedIn() {
		boolean loggedIn;
		settings = getSharedPreferences("session_auth", 0);
		final String user = settings.getString("username", "");
		final String password = settings.getString("password", "");
		if (!TextUtils.isEmpty(user) && !TextUtils.isEmpty(password) && user.length() > 0 && password.length() > 0) {
			loggedIn = true;
		} else {
			loggedIn = false;
		}
		return loggedIn;
	}

	private class MyWebView extends WebViewClient {
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
	}

	class GetData extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			Config.ViewShow();
		}

		@Override
		protected Void doInBackground(Void... params) {
			try {
				String url = Config.BASE_URL + "locations/" + mId + "?key="
						+ Config.KEY;
				Log.i("anisha", "url : " + url);
				RestClient client = new RestClient(url);
				client.AddHeader(
						"Authorization",
						"Basic "
								+ Base64.encodeToString(
										Config.auth_para.getBytes(),
										Base64.NO_WRAP));

				client.Execute(RequestMethod.GET);
				String response = client.getResponse();

				if (response != null) {
					Log.i("anisha", "GetData:response " + response);
					JSONObject json = new JSONObject(response);

					mData.add(json.getString("id"));
					mData.add(json.getString("name"));
					mData.add(json.getString("address1"));
					mData.add(json.getString("address2"));
					mData.add(json.getString("city"));
					mData.add(json.getString("state"));
					mData.add(json.getString("zip"));

					JSONArray jCords = json.getJSONArray("coordinates");

					mCords.add(jCords.getString(0));
					mCords.add(jCords.getString(1));

					JSONObject jPrice = null;
					try {
						jPrice = json.getJSONObject("pricing");
					} catch (Exception e) {

					}

					if (jPrice != null) {
						JSONArray priceArray = jPrice.getJSONArray("m");

						for (int i = 0; i < priceArray.length(); i++) {
							JSONArray pArray = (JSONArray) priceArray.get(i);
							pItem = new ArrayList<String>();
							for (int j = 0; j < pArray.length(); j++) {
								pItem.add(pArray.getString(j));
							}
							mPriceList.add(pItem);
							Log.v("", "" + mPriceList);
						}
					}

					JSONObject jAvails = json.getJSONObject("availability");
					mAvailable.add(jAvails.getString("total"));
					mAvailable.add(jAvails.getString("status"));
					mAvailable.add(jAvails.getString("available"));

					JSONObject jHours = json.getJSONObject("hours");
					mHour.add(jHours.getString("mo"));
					mHour.add(jHours.getString("tu"));
					mHour.add(jHours.getString("we"));
					mHour.add(jHours.getString("th"));
					mHour.add(jHours.getString("fr"));
					mHour.add(jHours.getString("sa"));
					mHour.add(jHours.getString("su"));

					mPhotoList = new ArrayList<String>();

					notes = json.getString("notes");

					JSONArray mPhotos = json.getJSONArray("photos");
					for (int k = 0; k < mPhotos.length(); k++) {
						mPhotoList.add(mPhotos.getString(k));
					}

					JSONArray jStations = json.getJSONArray("stations");

					for (int i = 0; i < jStations.length(); i++) {

						item = new ArrayList<String>();

						JSONObject jItem = jStations.getJSONObject(i);

						item.add(jItem.getString("id"));
						item.add(jItem.getString("name"));
						item.add(jItem.getString("status"));

						if (jItem.getString("status").equalsIgnoreCase(
								"available")) {
							mAvailable_st++;
						} else if (jItem.getString("status").equalsIgnoreCase(
								"in use")) {
							mInuse++;
						} else if (jItem.getString("status").equalsIgnoreCase(
								"offline")) {
							mOffline++;
						} else {
							mOutOfService++;
						}

						JSONArray jStCordArr = jItem
								.getJSONArray("coordinates");

						item.add(jStCordArr.getString(0));
						item.add(jStCordArr.getString(1));

						item.add(jItem.getString("status_note"));

						mStations.add(item);
//						Log.v("anisha", "" + mStations);
					}
//					Log.v("anisha", "" +item);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);

			Config.ViewDismiss();

			Log.i("anisha", "GetData:response " +  mData.get(1) + mData.get(1));
			setViews();
			// mGridView.setAdapter(new LocationGrid(getActivity()));
            mGridView.setAdapter(new MGalleryAdapter(getParent(),false));

			// mViewChanger = (RelativeLayout) view.findViewById(R.id.view_changer);
			/*
			 * try { mViewChanger.addView(showPiChartView()); } catch (Exception
			 * e) { }
			 */

			//mStationWebView = (ImageView) findViewById(R.id.station_webview);
			//String url = "http://maps.googleapis.com/maps/api/staticmap?center="
			//		+ mCords.get(0)
			//		+ ","
			//		+ mCords.get(1)
			//		+ "&size="
			//		+ Config.mapSize
			//		+ "&zoom=18&"
			//		+ "maptype=satellite"
			//		+ "&markers=size:large|color:green|"
			//		+ mCords.get(0)
			//		+ ","
			//		+ mCords.get(1) + "&sensor=false";


	//	new DownLoadImageTask().execute(url);

			fullPage.setVisibility(ScrollView.VISIBLE);

			String[] mStrings = new String[mPhotoList.size()];
			for (int i = 0; i < mPhotoList.size(); i++) {
				mStrings[i] = Config.BASE_URL + "photos/" + mPhotoList.get(i)
						+ "/thumb?key=" + Config.KEY;
			}
			adapter = new LazyAdapter(getParent(), mStrings);
			mStationGallery.setAdapter(adapter);
			adapter.notifyDataSetChanged();
		}
	}

	public void setViews() {

		try {
			if (notes.trim().equalsIgnoreCase("null")) {
				station_notes_head.setVisibility(View.INVISIBLE);
				station_notes.setVisibility(View.INVISIBLE);
			} else {
				station_notes.setText(notes.toString());
				station_notes.setVisibility(View.VISIBLE);
				station_notes_head.setVisibility(View.VISIBLE);
			}
		} catch (Exception e) {
			station_notes_head.setVisibility(View.INVISIBLE);
			station_notes.setVisibility(View.INVISIBLE);
		}

		mTop_text.setText(mData.get(1));

		mAdd1.setText(mData.get(2));
		if (mData.get(3).length() > 0) {
			mAdd2.setText(mData.get(3));
		} else {
			mAdd2.setVisibility(View.GONE);
		}
		city.setText(mData.get(4) + ", " + mData.get(5) + " - " + mData.get(6));
		mMiles.setText(mGet_Miles);

		if (mHour.size() > 0 && mHour != null) {
			mon.setText(mHour.get(0));
			tue.setText(mHour.get(1));
			wed.setText(mHour.get(2));
			thu.setText(mHour.get(3));
			fri.setText(mHour.get(4));
			sat.setText(mHour.get(5));
			sun.setText(mHour.get(6));
		}

		if (mPriceList.size() > 0 && mPriceList != null) {
			if (mPriceList.size() > 1) {
				mMsgBox2.setVisibility(View.VISIBLE);
				mMsgBox3.setVisibility(View.VISIBLE);
				mMsgBox1.setVisibility(View.GONE);

				mStTwoPrice.setText(mPriceList.get(0).get(0));
				mStOneMsg2.setText(mPriceList.get(0).get(1));
				mStTwoMsg2.setText(mPriceList.get(0).get(2));

				mStThreePrice.setText(mPriceList.get(1).get(0));
				mStOneMsg3.setText(mPriceList.get(1).get(1));
				mStTwoMsg3.setText(mPriceList.get(1).get(2));

			} else {
				mMsgBox2.setVisibility(View.GONE);
				mMsgBox3.setVisibility(View.GONE);
				mMsgBox1.setVisibility(View.VISIBLE);

				mStOnePrice.setText(fetchString(0, 0));
				mStOneMsg1.setText(fetchString(0, 1));
				mStTwoMsg1.setText(fetchString(0, 2));
			}
		} else {
			mMsgBox2.setVisibility(View.GONE);
			mMsgBox3.setVisibility(View.GONE);
			mMsgBox1.setVisibility(View.INVISIBLE);
		}
	}

	private String fetchString(int index, int pos) {
		try {
			return mPriceList.get(index).get(pos);
		} catch (Exception e) {
			return " ";
		}
	}

    /**
     * Short description of fetchStationData()
     *
     * @param index           Start index of the gallery
     * @param pos             Position of the station
     * @param gallaryPosition Position of the gallery
     * @return station position
     */
    private String fetchStationData(int index, int pos, int gallaryPosition) {
		try {
            if (gallaryPosition > 1){
				int idPosition = (index) + 8 * (gallaryPosition-1);
                remainingSize = mStations.size() - ((index) + 8 * (gallaryPosition-1));
//				Log.i("anisha","IF "+index + " POS: " + pos + " INDEX:  " + idPosition);
				//Log.i("anisha","index 1 "+mStations.get((index) + 8 * (gallaryPosition-1)).get(pos));
                return mStations.get((index) + 8 * (gallaryPosition-1)).get(pos);
            }else {
                remainingSize = mStations.size() - index;
//				Log.i("anisha","ELSE  "+index + " POS: " + pos);
			return mStations.get(index).get(pos);
            }

		} catch (Exception e) {
			return " ";
		}
	}

	private class LocationGrid extends BaseAdapter {

		private Context mContext;
		private LayoutInflater mInflater;
        private int gallaryPosition;
        private ImageView mNxtBtn;
        public LocationGrid(Context ctx , int gallaryPosition, ImageView mNxtBtn) {
			mContext = ctx;
			mInflater = LayoutInflater.from(ctx);
            this.gallaryPosition = gallaryPosition;
            this.mNxtBtn = mNxtBtn;
		}


		@Override
		public int getCount() {
                try{
                    if ( gallaryPosition == 1 ){
                        if (mStations.size() <= 8){
                            mNxtBtn.setVisibility(View.INVISIBLE);
                            return mStations.size();
                        }else {
                            mNxtBtn.setVisibility(View.VISIBLE);
                            return  8;
                        }
                    }else {
                        if (remainingSize > 8){
                            mNxtBtn.setVisibility(View.VISIBLE);
                            return 8;
                        }else {
                            mNxtBtn.setVisibility(View.INVISIBLE);
                            return remainingSize;
                        }
                    }
                }catch (Exception exe){
                    return 0;
                }
		}

		@Override
		public Object getItem(int position) {
            return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			ViewHolder holder;
			if (convertView == null || convertView.getTag() == null) {
				convertView = mInflater.inflate(R.layout.grid_view, null);
				holder = new ViewHolder();

				holder.stationNmTxt = (TextView) convertView
						.findViewById(R.id.st_grid_title);

                /** Remove charging session hours. */
//                holder.stationTmTxt = (TextView) convertView
//                        .findViewById(R.id.st_grid_time);
				holder.stationImg = (ImageView) convertView
						.findViewById(R.id.st_grid_image);

			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			//Draw the image based on the Station status
			holder.stationNmTxt.setText(fetchStationData(position, 1, gallaryPosition));
//			Log.i("anisha", "gallaryPosition" + gallaryPosition);
//			+ " - " + fetchStationData(position, 2, gallaryPosition)); // ("Station1 - Available ")

            if (fetchStationData(position, 2, gallaryPosition).equalsIgnoreCase("available")) {
				holder.stationImg.setBackgroundDrawable(getResources()
						.getDrawable(R.drawable.circle_available));
            } else if (fetchStationData(position, 2, gallaryPosition).equalsIgnoreCase("offline")) {
				holder.stationImg.setBackgroundDrawable(getResources()
						.getDrawable(R.drawable.circle_offline));
            } else if (fetchStationData(position, 2, gallaryPosition).equalsIgnoreCase("in use")) {
				holder.stationImg.setBackgroundDrawable(getResources()
						.getDrawable(R.drawable.circle_in_use));
			} else {
				holder.stationImg.setBackgroundDrawable(getResources()
						.getDrawable(R.drawable.circle_oos));
			}
			return convertView;
		}
	}

	static class ViewHolder {
		TextView stationNmTxt;
//        TextView stationAvlTxt;
//        TextView stationTmTxt;
		ImageView stationImg;
	}

	private void authDialog(String message) {
		AlertDialog.Builder dialog = new AlertDialog.Builder(getParent());
		dialog.setMessage(message);
		dialog.setIcon(R.drawable.ic_launcher);
		dialog.setTitle(chargStation);


		dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// Remote Authorize
				new GetChargingSession().execute();
			}
		});

		dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});

		dialog.create().show();
	}

	private void authError(String message) {
		AlertDialog.Builder dialog = new AlertDialog.Builder(getParent());
		dialog.setMessage(message);
		dialog.setIcon(R.drawable.ic_launcher);


		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});

		dialog.create().show();
	}

	class GetChargingSession extends AsyncTask<Void, Void, Void> {

		int mResponse_code;
		String currentKey = "";
		String currentValue = "";
		ProgressDialog pDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = ProgressDialog.show(getParent(), "", "Authorizing....");
		}

		@Override
		protected Void doInBackground(Void... arg0) {

			String url = Config.BASE_URL + "charging-sessions" + "?key="
					+ Config.KEY;

			String mEntity = "{ \"station_id\" : " + mStationId + " }";
		

			Log.v("URL and Entity :: ", "" + url + ":: " + mEntity);

			try {

				HttpPost httpost = new HttpPost(url);
				httpost.setEntity(new StringEntity(mEntity));
				httpost.setHeader(
						"Authorization",
						"Basic "
								+ Base64.encodeToString(
										Config.auth_para.getBytes(),
										Base64.NO_WRAP));

				HttpResponse httpResponse = null;

				if (Config.client != null) {
					httpResponse = Config.client.execute(httpost);
				} else {
					httpResponse = Config.getThreadSafeClient()
							.execute(httpost);
				}

				mResponse_code = httpResponse.getStatusLine().getStatusCode();

				Log.v("STATUS CODE :: ", ":: " + mResponse_code);

				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {

					InputStream input = null;
					input = entity.getContent();
					mResponse = convertStreamToString(input);

					input.close();
					Log.v("response ", "" + mResponse);
//					Log.v("anisha ", "GetChargingSession" + mResponse);

					if (mResponse != null) {
						JSONObject jObject = new JSONObject(mResponse);

						// myStatics = jObject.getString("statistics");
						Iterator keys = jObject.keys();

						while (keys.hasNext()) {
							// loop to get the dynamic key
							currentKey = (String) keys.next();

							// get the value of the dynamic key
							currentValue = jObject.getString(currentKey);

							Log.v("dynamic key", currentKey + "****"
									+ currentValue);

						}

						JSONObject jsObject = jObject
								.getJSONObject("statistics");
						JSONArray powerArray = jsObject.getJSONArray("power");
						PowerList = new StringBuilder(powerArray.length());
						for (int i = 0; i < powerArray.length(); i++) {
							PowerList.append(powerArray.getString(i));
							if (i == powerArray.length() - 1) {
								//
							} else {
								PowerList.append(",");
							}
						}
						Log.v("PowerList", "" + PowerList);

						JSONArray timeArray = jsObject.getJSONArray("times");
						timeList = new ArrayList<String>();
						for (int i = 0; i < timeArray.length(); i++) {
							timeList.add(i, timeArray.getString(i));
						}
						Log.v("timeList", "" + timeList);

						JSONArray energyArray = jsObject.getJSONArray("energy");
						energyList = new StringBuilder(energyArray.length());
						for (int i = 0; i < energyArray.length(); i++) {
							energyList.append(energyArray.getString(i));
							if (i == energyArray.length() - 1) {
								//
							} else {
								energyList.append(",");
							}
						}
						Log.v("energyList", "" + energyList);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				pDialog.dismiss();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			pDialog.dismiss();

			AlertDialog.Builder dialog = new AlertDialog.Builder(getParent());
			if (mResponse_code == 201) {
				dialog.setMessage("Charging session authorized." + "\nPlug in your car to begin charging.");
				dialog.setIcon(R.drawable.ic_launcher);
				dialog.setTitle(chargStation);
				dialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								Config.authorize = true;
								// Move to the My Account section ....

								/*
								 * FragmentManager fm = getFragmentManager();
								 * for (int i = 0; i <
								 * fm.getBackStackEntryCount(); ++i) {
								 * fm.popBackStack(); }
								 */
								/*
								 * MyAccount f = new MyAccount(); Bundle args =
								 * new Bundle();
								 * args.putString("title","My Account");
								 * f.setArguments(args);
								 * 
								 * ((ActivityInTab)
								 * getActivity()).navigateTo(f);
								 */

								TabsFragmentActivity.switchTab(0);

								dialog.dismiss();


							}
						});

			} else if (mResponse_code == 406) {
				dialog.setMessage(currentValue);
				dialog.setTitle(chargStation);
				dialog.setIcon(R.drawable.ic_launcher);

				dialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
							}
						});
			} else if (mResponse_code == 503) {
				dialog.setMessage(currentValue);
				dialog.setTitle(chargStation);
				dialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
							}
						});
			} else {
				dialog.setMessage("Authorization Failed:");
				dialog.setTitle(chargStation);
				dialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
							}
						});
			}

			dialog.create().show();

		}
	}

	private static String convertStreamToString(InputStream is) {
		Log.i("Inside convertstream", "hello");
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	private class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {

		private Bitmap bMap;
		ProgressBar pBar;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pBar = (ProgressBar) findViewById(R.id.login_web_progress);
			pBar.setVisibility(View.VISIBLE);
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			return loadImgFromNetwork(params[0]);
		}

		public Bitmap loadImgFromNetwork(String url) {

			Log.d("ImageManager", "download begining");
			Log.d("ImageManager", "download url:" + url);

			try {
				URL imgurl = new URL(url);
				URLConnection ucon = imgurl.openConnection();
				if (ucon == null) {
					Toast.makeText(getParent(), "Connection Problem",
							Toast.LENGTH_LONG).show();
				}

				InputStream is = null;
				try {
					is = ucon.getInputStream();
				} catch (Exception e) {
				}

				if (is != null) {
					BufferedInputStream bis = new BufferedInputStream(is);

					bMap = BitmapFactory.decodeStream(bis);

					if (is != null) {
						is.close();
					}
					if (bis != null) {
						bis.close();
					}
				}

			} catch (IOException e) {
				e.printStackTrace();
				pBar.setVisibility(View.INVISIBLE);
			}

			return bMap;
		}

		protected void onPostExecute(Bitmap result) {
			if (result != null) {
			//	mStationWebView.setScaleType(ImageView.ScaleType.CENTER_CROP);
			//	mStationWebView.setImageBitmap(result);
			}
			pBar.setVisibility(View.INVISIBLE);
		}
	}

	@Override
	public void onPause() {
		super.onPause();
		if (imageLoader != null) {
			imageLoader.clearCache();
		}
	}

	public class MGalleryAdapter extends BaseAdapter {

		private LayoutInflater mInflater;
		Context c;
        private boolean firstPageOnly;
        public MGalleryAdapter(Context context, boolean firstPageOnly) {
			mInflater = LayoutInflater.from(context);
			c = context;
            this.firstPageOnly = firstPageOnly;
		}

		public int getCount() {

            if (firstPageOnly){
                return 1;
				}
        //If number of stations is more than 8,Display 8 stations in each page
            try {
                mChargeBtn.setVisibility(View.VISIBLE);
                return ((mStations.size() % 8) != 0 ? (mStations.size() / 8) + 1
                        : (mStations.size() / 8)) + 1;
            } catch (Exception e) {
				return 1;
			}

		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			GridViewHolder mHolder;
			if (convertView == null || convertView.getTag() == null) {

				convertView = mInflater.inflate(R.layout.station_grid, null);
				mHolder = new GridViewHolder();

				mHolder.mStrionsGrid = (GridView) convertView
						.findViewById(R.id.grid_item);
				mHolder.mViewChanger = (RelativeLayout) convertView
						.findViewById(R.id.view_changer);

				mHolder.mNxtBtn = (ImageButton) convertView
						.findViewById(R.id.station_nxt_btn);
				mHolder.mPrvBtn = (ImageButton) convertView
						.findViewById(R.id.station_prv_btn);
				mHolder.station_grid_head = (TextView) convertView
						.findViewById(R.id.station_grid_head);

				convertView.setTag(mHolder);
			} else {
				mHolder = (GridViewHolder) convertView.getTag();
			}

            /**
             * If gallary position is 0,display pi_chat & hide next & previous button
             * else show stationGrid
             */
			if (position == 0) {
				// mHolder.mStrionsGrid.setVisibility(View.GONE);
				mHolder.mPrvBtn.setVisibility(View.INVISIBLE);
				mHolder.station_grid_head.setVisibility(View.GONE);
				mHolder.mViewChanger.addView(showPiChartView());

				try {
						mChargeBtn.setVisibility(View.VISIBLE);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return convertView;
			} else {
				mHolder.station_grid_head.setVisibility(View.VISIBLE);

				// Remove the previos button if the position is 1. i.e. First Page should not have previous button
				if (position == 1) {
					mHolder.mPrvBtn.setVisibility(View.INVISIBLE);
				}else {
					mHolder.mPrvBtn.setVisibility(View.VISIBLE);
				}


				// mHolder.mStrionsGrid.setVisibility(View.VISIBLE);

                mHolder.mStrionsGrid.setAdapter(new LocationGrid(c , position, mHolder.mNxtBtn));

				mHolder.mPrvBtn.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {

                        if (mGalleryPos == 0){
                            mGalleryPos = 1;
                        }

						mGridView.setSelection(mGalleryPos - 1);
                        mGalleryPos = mGalleryPos - 1;
						((BaseAdapter) mGridView.getAdapter())
								.notifyDataSetChanged();
					}
				});

				mHolder.mNxtBtn.setOnClickListener(new OnClickListener() {
					public void onClick(View arg0) {
						mGridView.setSelection(mGalleryPos + 1);
                        mGalleryPos = mGalleryPos + 1;
						((BaseAdapter) mGridView.getAdapter())
								.notifyDataSetChanged();
					}
				});

				mHolder.mStrionsGrid
						.setOnItemClickListener(new OnItemClickListener() {
							public void onItemClick(AdapterView<?> parent,
									View view, int pos, long id) {
								mStationId = mStations.get(pos).get(0);
                                //User not logged-in
								if (!Config.loginChk) {
                                    authError("You Must have to login before start new charging session.");
								} else {
                                    //User logged-in
//									Log.v("anisha", "" + mAvailable.get(1) + ","
//											+ mStationId);
									chargStation = mStations.get( (mGalleryPos - 1) * 8 + pos ).get(1);
//									Log.v("anisha", "" + mAvailable.get(2) + "," + mStationId );
//									Log.v("anisha", "mGalleryPos : " + mGalleryPos );
									authDialog("Authorize a charging session here?");

								}
							}
						});
    /** Display next button,if stations are more than 8. */

                if (mStations.size() > 8) {
					mHolder.mNxtBtn.setVisibility(View.VISIBLE);
				}
				return convertView;
			}

		}
	}

	private static class GridViewHolder {
		GridView mStrionsGrid;
		RelativeLayout mViewChanger;
		ImageButton mNxtBtn, mPrvBtn;
		TextView station_grid_head;
	}

	public void onItemSelected(AdapterView<?> view, View arg1, int pos,
			long arg3) {
		mGalleryPos = pos;
		Log.v("onItemSelected()" + view.getSelectedItemPosition(),
				"pos" + pos);
		if (pos > 0) {
			firstFlag = false;
		}
		if (pos == 0) {
			firstFlag = true;
		}
		((BaseAdapter) mGridView.getAdapter()).notifyDataSetChanged();
	}

	public void onNothingSelected(AdapterView<?> arg0) {
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return mGridView.onTouchEvent(event);
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}

	// New Map implementation starts here
	/**
	 * Demonstrates customizing the info window and/or its contents.
	 */
	class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

		// These are both viewgroups containing an ImageView with id "badge" and two TextViews with id
		// "title" and "snippet".
		private final View mWindow;

		private final View mContents;

		CustomInfoWindowAdapter() {
			mWindow = getLayoutInflater().inflate(R.layout.custom_info_window, null);
			mContents = getLayoutInflater().inflate(R.layout.custom_info_contents, null);
		}

		@Override
		public View getInfoWindow(Marker marker) {
			render(marker, mWindow);
			return mWindow;
		}

		@Override
		public View getInfoContents(Marker marker) {
			render(marker, mContents);
			return mContents;
		}

		private void render(Marker marker, View view) {
			int badge;
			// Use the equals() method on a Marker to check for equals.  Do not use ==.
			if (marker.equals(mBrisbane)) {
//				badge = R.drawable.badge_qld;
			} else if(marker.equals(currentLocation)){
//				badge = R.drawable.badge_qld;
			}else {
				// Passing 0 to setImageResource will clear the image view.
				badge = 0;
			}
//			((ImageView) view.findViewById(R.id.badge)).setImageResource(badge);

			String title = marker.getTitle();
			TextView titleUi = ((TextView) view.findViewById(R.id.title));
			if (title != null) {
				// Spannable string allows us to edit the formatting of the text.
				SpannableString titleText = new SpannableString(title);
				titleText.setSpan(new ForegroundColorSpan(Color.RED), 0, titleText.length(), 0);
				titleUi.setText(titleText);
			} else {
				titleUi.setText("");
			}

//			String snippet = marker.getSnippet();
//			TextView snippetUi = ((TextView) view.findViewById(R.id.snippet));
//			if (snippet != null && snippet.length() > 12) {
//				SpannableString snippetText = new SpannableString(snippet);
//				snippetText.setSpan(new ForegroundColorSpan(Color.MAGENTA), 0, 10, 0);
//				snippetText.setSpan(new ForegroundColorSpan(Color.BLUE), 12, snippet.length(), 0);
//				snippetUi.setText(snippetText);
//			} else {
//				snippetUi.setText("");
//			}
		}
	}

	@Override
	public void onMapReady(GoogleMap map) {
		try {
			if (map != null) {
				mMap = map;

				// Hide the zoom controls as the button panel will cover it.
				mMap.getUiSettings().setZoomControlsEnabled(false);

				// Add lots of markers to the map.
				addMarkersToMap();


				// Setting an info window adapter allows us to change the both the contents and look of the
				// info window.
				mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter());

				// Set listeners for marker events.  See the bottom of this class for their behavior.
				mMap.setOnMarkerClickListener(this);
				mMap.setOnInfoWindowClickListener(this);
				mMap.setOnMarkerDragListener(this);
				mMap.setOnInfoWindowCloseListener(this);
				mMap.setOnInfoWindowLongClickListener(this);
				mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
				// Override the default content description on the view, for accessibility mode.
				// Ideally this string would be localised.
				map.setContentDescription("Map with lots of markers.");

				// Pan to see all markers in view.
				// Cannot zoom to bounds until the map has a size.
				final View mapView = getSupportFragmentManager().findFragmentById(R.id.map).getView();

				if (mapView.getViewTreeObserver().isAlive()) {

					mapView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
						@SuppressWarnings("deprecation") // We use the new method when supported
						@SuppressLint("NewApi") // We check which build version we are using.
						@Override
						public void onGlobalLayout() {
							LatLngBounds bounds = new LatLngBounds.Builder()
									.include(SINGLE_LOCATION)
									.build();
							if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
								mapView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
							} else {
								mapView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
							}
							//mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 50));

							mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(SINGLE_LOCATION.latitude, SINGLE_LOCATION.longitude), 16.0f));
						}
					});
				}
			}
		}catch (Exception e){
			e.printStackTrace();
			Log.e("Error" , "GOOGLE MAPS NOT LOADED");
		}


		//mMap.moveCamera( CameraUpdateFactory.newLatLngZoom(new LatLng(SINGLE_LOCATION.latitude,SINGLE_LOCATION.longitude) , 16.0f) );
		}


	private void addMarkersToMap() {
		// Uses a colored icon.
//
//		Toast.makeText(StationDetails.this, "total: "+total, Toast.LENGTH_SHORT).show();
//		Toast.makeText(StationDetails.this, "status: "+status, Toast.LENGTH_SHORT).show();
//		Toast.makeText(StationDetails.this, "available: "+available, Toast.LENGTH_SHORT).show();

		if (status.equals("available")) {
			drawable = getResources().getDrawable(
					R.drawable.map_pin_available);

			mBrisbane = mMap.addMarker(new MarkerOptions()
					.position(SINGLE_LOCATION)
					.title(name)
					.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
		} else if (status.equals("offline")) {
			drawable = getResources().getDrawable(
					R.drawable.map_pin_offline);
			BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(R.drawable.graymappeddot);
			mBrisbane = mMap.addMarker(new MarkerOptions()
					.position(SINGLE_LOCATION)
					.title(name)
					.icon(icon));
//				.icon(BitmapDescriptorFactory.defaultMarker(0.0f)));
		} else if (status.equals("in use")) {
			drawable = getResources().getDrawable(
					R.drawable.map_pin_in_use);

			mBrisbane = mMap.addMarker(new MarkerOptions()
					.position(SINGLE_LOCATION)
					.title(name)
					.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
		} else {
			drawable = getResources().getDrawable(
					R.drawable.map_pin_oos);
			mBrisbane = mMap.addMarker(new MarkerOptions()
					.position(SINGLE_LOCATION)
					.title(name)
					.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
		}



		currentLocation = mMap.addMarker(new MarkerOptions()
				.position(CURRENT_LOCATION)
				.title("Current Location")
				.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));

//
		/*
	int numMarkersInRainbow = 12;
		for (int i = 0; i < numMarkersInRainbow; i++) {
			Marker marker = mMap.addMarker(new MarkerOptions()
					.position(new LatLng(
							-30 + 10 * Math.sin(i * Math.PI / (numMarkersInRainbow - 1)),
							135 - 10 * Math.cos(i * Math.PI / (numMarkersInRainbow - 1))))
					.title("Marker " + i)
					.icon(BitmapDescriptorFactory.defaultMarker(i * 360 / numMarkersInRainbow))
					.flat(true)
					.rotation(360));
			marker.setTag(0);
			mMarkerRainbow.add(marker);
		}
		*/
	}

	/**
	 * Demonstrates converting a {@link Drawable} to a {@link BitmapDescriptor},
	 * for use as a marker icon.
	 */
	private BitmapDescriptor vectorToBitmap(@DrawableRes int id, @ColorInt int color) {
		Drawable vectorDrawable = ResourcesCompat.getDrawable(getResources(), id, null);
		Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),
				vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);
		vectorDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
		DrawableCompat.setTint(vectorDrawable, color);
		vectorDrawable.draw(canvas);
		return BitmapDescriptorFactory.fromBitmap(bitmap);
	}

	private boolean checkReady() {
		if (mMap == null) {
//			Toast.makeText(this, R.string.map_not_ready, Toast.LENGTH_SHORT).show();
			return false;
		}
		return true;
	}

	/**
	 * Called when the Clear button is listButtonClicked.
	 */
	public void onClearMap(View view) {
		if (!checkReady()) {
			return;
		}
		mMap.clear();
	}

	/**
	 * Called when the Reset button is listButtonClicked.
	 */
	public void onResetMap(View view) {
		if (!checkReady()) {
			return;
		}
		// Clear the map because we don't want duplicates of the markers.
		mMap.clear();
		addMarkersToMap();
	}

	/**
	 * Called when the Reset button is listButtonClicked.
	 */
	public void onToggleFlat(View view) {
		if (!checkReady()) {
			return;
		}

		for (Marker marker : mMarkerRainbow) {
			marker.setFlat(true);
		}
	}

	//
	// Marker related listeners.
	//

	@Override
	public boolean onMarkerClick(final Marker marker) {
		// Markers have a z-index that is settable and gettable.
		float zIndex = marker.getZIndex() + 1.0f;
		marker.setZIndex(zIndex);
//		Toast.makeText(this, marker.getTitle() + " z-index set to " + zIndex,
//				Toast.LENGTH_SHORT).show();

		// Markers can store and retrieve a data object via the getTag/setTag methods.
		// Here we use it to retrieve the number of clicks stored for this marker.
		Integer clickCount = (Integer) marker.getTag();
		// Check if a click count was set.
		if (clickCount != null) {
			clickCount = clickCount + 1;
			// Markers can store and retrieve a data object via the getTag/setTag methods.
			// Here we use it to store the number of clicks for this marker.
			marker.setTag(clickCount);
			mTagText.setText(marker.getTitle() + " has been listButtonClicked " + clickCount + " times.");
		} else {
			mTagText.setText("");
		}

		mLastSelectedMarker = marker;
		// We return false to indicate that we have not consumed the event and that we wish
		// for the default behavior to occur (which is for the camera to move such that the
		// marker is centered and for the marker's info window to open, if it has one).

		if (marker.isInfoWindowShown()){
			marker.hideInfoWindow();
		}else{
			marker.showInfoWindow();
		}

		return false;
	}

	@Override
	public void onInfoWindowClick(Marker marker) {
//		Toast.makeText(this, "Click Info Window", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onInfoWindowClose(Marker marker) {
//		Toast.makeText(this, "Close Info Window", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onInfoWindowLongClick(Marker marker) {
//		Toast.makeText(this, "Info Window long click", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onMarkerDragStart(Marker marker) {
		mTopText.setText("onMarkerDragStart");
	}

	@Override
	public void onMarkerDragEnd(Marker marker) {
		mTopText.setText("onMarkerDragEnd");
	}

	@Override
	public void onMarkerDrag(Marker marker) {
		mTopText.setText("onMarkerDrag.  Current Position: " + marker.getPosition());
	}


}
