package com.semaconnect;

import android.os.Bundle;

public class StackMore extends ActivityInTab {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		navigateTo(new MoreScreen());
	}
}

