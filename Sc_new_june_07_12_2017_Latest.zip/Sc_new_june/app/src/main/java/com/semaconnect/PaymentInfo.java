package com.semaconnect;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.text.method.LinkMovementMethod;
import android.text.style.UnderlineSpan;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.braintreegateway.encryption.Braintree;
import com.semaconnect.utility.Config;
import com.semaconnect.utility.CustomTextView;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import io.card.payment.*;

import io.card.payment.ui.ViewUtil;

public class PaymentInfo extends Fragment {
	private static final int MY_SCAN_REQUEST_CODE = 1;
	// scan card
//	private Button scanCardId;
	Button submitBtn;
	ViewGroup view;
	ImageButton mCheck;
	Boolean chkFlag = false;
	static Boolean fieldFlag = false;
	private static final int editTextIdBase = 100;
	private int editTextIdCounter = editTextIdBase;
	public Validator numberValidator;
	private ImageView carTypeimage;
	EditText card_no;
	EditText payinfo_number_star;
	CustomTextView terms;
	LinearLayout errorBox;

	static EditText expir;
	EditText expiryyear;
	EditText cvv;
    TextView changeCCInfo;
	CustomTextView payment_msg;
	CustomTextView payment_msg_login;
	String mEntity;
	String username;
	private ImageView scancard;
	String encryptedCreditCardNumber;
	String encryptedCvv;
	String encryptedExpiryMonth;
	String encryptedExpiryYear;


	//BraintreeKey Live
//	private String braintreeKey = "MIIBCgKCAQEA1907nZGVU84+93suhlMDak+ZlP1whrSHvTkr0dtJT30YjgI3/ohnz6tw3Vq0ZShrgAIqaZFBjR6Rl87+ZC8k3l3bBsieL6lxO6hdqMixTLoDQfBH9z1WwSJumiW9WxrhWIDUr/XJ4JRLou806xMqdZ733bOAb4OjwyWUQRtl05QrX8jEM2Osq7q6+mhdQRwvT8IulnNMdmhIp6wWuKYfOdb3VuRJXUT7+iLBsgSlDUytCTa73PF+eOzNpTkb2SlnafrMc45c8TnIBMB123i/7iSK9tbkgf1qK+LUDio7BWclX4hdYH+Pf1OjgUKE+c3fRJUpCgSF+TxlmXuX00s6dQIDAQAB";

	//BraintreeKey for Demo
	private String braintreeKey = "MIIBCgKCAQEArvaq4aD5oQEXNWqtHCRFAIH4NtD815fptqX9W5WGaYB8un2b5P96L490f2f5yFMD2VO44ZEnBqtWuxadx93W08bAFDZTygjjS0SdJiy6+Xh1tmXM0YOfx34zRTVAk1dhB3n0tiVDT9yga/BNDyrFfc6f6qhakJbEzvnPXBYjcNwUB1SK6esAcym+qQGDp4/IZatvgAkJxcowKInwVMVzbZVDGTf5I5Nq0OOWvrDY19T0O2vMU/I5YxnrvJQOd7rfGbGoQ+k3pk/j/OfvrS4OTo4F7RBel/xypH9UL5QtyONAS3rMyZLM3D0qB4GG+tLRKDd9WLI2BjR3ndGHKGpulQIDAQAB";

	private static String mYear, mMonth;
	String currentKey = "";
	String currentValue = "";
	private ScrollView mPayForm;

	TextView errorTxt;
	TextView scan;

	HashMap<String, Integer> payBoxes;

	ArrayAdapter<CharSequence> adapter;

	private String mResponse = "";
	private int mResponse_code;
	//Current date
	Calendar calendar = Calendar.getInstance();
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm aa");
	String getCurrentDateTime = sdf.format(calendar.getTime());

	int year = Calendar.getInstance().get(Calendar.YEAR);
	private String last4;

	protected void setColor(String lbl_name, String txt_color){

		try{
			TextView lbl = (TextView) view.findViewById(payBoxes.get(lbl_name));
			if (txt_color.equals("red")){
				lbl.setTextColor(Color.RED);
//				lbl.setBackgroundResource(R.drawable.paymentinfotextbox_error);
			}
			else if(txt_color.equals("black")){
				lbl.setTextColor(Color.BLACK);
//				lbl.setBackgroundResource(R.drawable.paymentinfotextbox);
			}
		}
			catch(Exception e){
				e.printStackTrace();
		}

	}

	private void resetColor(){
		for ( String key : payBoxes.keySet())
		    setColor(key, "black");
	}

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {


		if (container == null) {
			return null;
		}
		view = (ViewGroup) inflater
				.inflate(R.layout.payment_test, container, false);

		return view;
	}
	// scan card
	public void onScanPress() {
		Intent scanIntent = new Intent(getActivity(), CardIOActivity.class);

		scanIntent.putExtra(CardIOActivity.EXTRA_RETURN_CARD_IMAGE,true); // default: false
		scanIntent.putExtra(CardIOActivity.EXTRA_USE_CARDIO_LOGO, true); // default:
		scanIntent.putExtra(CardIOActivity.EXTRA_REQUIRE_EXPIRY, true); // default: false
		scanIntent.putExtra(CardIOActivity.EXTRA_SUPPRESS_MANUAL_ENTRY, true); // default: false
//		scanIntent.putExtra(CardIOActivity.EXTRA_SUPPRESS_SCAN, false); // default: false
//		scanIntent.putExtra(CardIOActivity.EXTRA_KEEP_APPLICATION_THEME, false);
		// MY_SCAN_REQUEST_CODE is arbitrary and is only used within this activity.
		startActivityForResult(scanIntent, MY_SCAN_REQUEST_CODE);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == MY_SCAN_REQUEST_CODE) {
			String resultDisplayStr;
			if (data != null && data.hasExtra(CardIOActivity.EXTRA_SCAN_RESULT)) {
				CreditCard scanResult = data.getParcelableExtra(CardIOActivity.EXTRA_SCAN_RESULT);
//				String cardNumber = scanResult.cardNumber;
//				card_no.setText(cardNumber);

//				// Never log a raw card number. Avoid displaying it, but if necessary use getFormattedCardNumber()
//				resultDisplayStr = "Card Number: " + scanResult.getRedactedCardNumber() + "\n";
//
//				// Do something with the raw number, e.g.:
				card_no.setText( scanResult.cardNumber );

				if (scanResult.isExpiryValid()) {
//					resultDisplayStr += "Expiration Date: " + scanResult.expiryMonth + "/" + scanResult.expiryYear + "\n";
//					Toast.makeText(getActivity(), "Month: "+scanResult.expiryMonth, Toast.LENGTH_SHORT).show();
//					Toast.makeText(getActivity(), "Year: "+scanResult.expiryYear, Toast.LENGTH_SHORT).show();
					int expiryMonth = scanResult.expiryMonth;

					mMonth = ""+scanResult.expiryMonth;

					String monthString = ""+expiryMonth;
					if (monthString.length() == 1){
						monthString ="0"+expiryMonth;
					}

					expir.setText(monthString);

					int expiryYear = scanResult.expiryYear;
					mYear = ""+scanResult.expiryYear;
					String yearString = ""+expiryYear;
					if (yearString.length() == 4){
						yearString = yearString.substring(2);
					}
					expiryyear.setText(yearString);

				}
//
				if (scanResult.cvv != null) {
					// Never log or display a CVV
//					resultDisplayStr += "CVV has " + scanResult.cvv.length() + " digits.\n";
					cvv.setText(scanResult.cvv);
				}

				if (scanResult.getCardType().imageBitmap(getActivity())!=null) {
					// Never log or display a CVV
//					resultStr += "Card Type Image " + scanResult.getCardType().imageBitmap(getActivity());
					carTypeimage.setImageBitmap(scanResult.getCardType().imageBitmap(getActivity()));

				}
//
//				if (scanResult.postalCode != null) {
//					resultDisplayStr += "Postal Code: " + scanResult.postalCode + "\n";
//				}
			}
			else {
				resultDisplayStr = "Scan was canceled.";
			}
			// do something with resultDisplayStr, maybe display it in a textView
			// resultTextView.setText(resultDisplayStr);
		}
	}

	private void init() {
		payment_msg = (CustomTextView) view.findViewById(R.id.payment_msg);
		payment_msg_login = (CustomTextView) view.findViewById(R.id.payment_msg_login);
// scan card
		scancard = (ImageView) view.findViewById(R.id.scanCardId);
		scancard.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onScanPress();
			}
		});

		submitBtn = (Button) view.findViewById(R.id.payinfo_submit);
		carTypeimage = (ImageView) view.findViewById(R.id.carTypeimage);
		numberValidator = new CardNumberValidator();
		card_no = (EditText) view.findViewById(R.id.payinfo_number);
		payinfo_number_star = (EditText) view.findViewById(R.id.payinfo_number_star);
		card_no.setMaxLines(1);
		card_no.setImeOptions(EditorInfo.IME_ACTION_DONE);
//		card_no.setTextAppearance(getActivity(),android.R.attr.textAppearanceLarge);
		card_no.setInputType(InputType.TYPE_CLASS_PHONE);
//		card_no.setHint("Enter CreditCard No");
//		card_no.setHintTextColor(Appearance.TEXT_COLOR_EDIT_TEXT_HINT);

		card_no.addTextChangedListener(numberValidator);
		card_no.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable et) {

				if (card_no != null && et == card_no.getText()) {
					if (card_no.getText().toString().equalsIgnoreCase("34") || card_no.getText().toString().equalsIgnoreCase("37")){
						carTypeimage.setImageBitmap(ViewUtil.base64ToBitmap(Base64EncodedImages.paypal_sdk_icon_amex_large, getActivity()));
					}else if (card_no.getText().toString().equalsIgnoreCase("6")){
						carTypeimage.setImageBitmap(ViewUtil.base64ToBitmap( Base64EncodedImages.paypal_sdk_icon_discover, getActivity()));
					}else if (card_no.getText().toString().equalsIgnoreCase("35")){
						carTypeimage.setImageBitmap(ViewUtil.base64ToBitmap( Base64EncodedImages.paypal_sdk_icon_jcb_large, getActivity()));
					}else if (card_no.getText().toString().equalsIgnoreCase("51")|| card_no.getText().toString().equalsIgnoreCase("52")|| card_no.getText().toString().equalsIgnoreCase("53")|| card_no.getText().toString().equalsIgnoreCase("54")|| card_no.getText().toString().equalsIgnoreCase("55")){
						carTypeimage.setImageBitmap(ViewUtil.base64ToBitmap(  Base64EncodedImages.paypal_sdk_icon_mastercard_large, getActivity()));
					}else if (card_no.getText().toString().equalsIgnoreCase("4")) {
						carTypeimage.setImageBitmap(ViewUtil.base64ToBitmap(Base64EncodedImages.paypal_sdk_icon_visa_large, getActivity()));
					}else if (TextUtils.isEmpty(card_no.getText().toString())) {
						carTypeimage.setImageResource(R.drawable.card_image);
					}else if (card_no.getText().toString().length()== 1) {
						carTypeimage.setImageResource(R.drawable.card_image);
					}
					if (numberValidator.hasFullLength()) {
						if (!numberValidator.isValid()) {
							card_no.setTextColor(Appearance.TEXT_COLOR_ERROR);
						} else {
							setDefaultColor(card_no);

						}
					} else {
						setDefaultColor(card_no);
					}
				}
			}
		});
		card_no.setFilters(new InputFilter[] { new DigitsKeyListener(), numberValidator });

		mPayForm = (ScrollView) view.findViewById(R.id.payment_scroll);

		errorBox = (LinearLayout) view.findViewById(R.id.payinfo_errorbox);
		errorTxt = (TextView) view.findViewById(R.id.error_txt_child);

		expir = (EditText) view.findViewById(R.id.payinfo_expires);
		expiryyear = (EditText) view.findViewById(R.id.payinfo_expiresyy);
		cvv = (EditText) view.findViewById(R.id.payinfo_cvv);
        scan = (TextView) view.findViewById(R.id.scan);
        changeCCInfo = (TextView) view.findViewById(R.id.changeCCInfo);
		SpannableString content = new SpannableString("Change Credit Card");
		content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
		changeCCInfo.setText(content);

//		phone = (EditText) view.findViewById(R.id.payinfo_phone);
//
//		country = (Spinner) view.findViewById(R.id.payinfo_country);
		terms	= (CustomTextView) view.findViewById(R.id.terms_link);
		terms.setMovementMethod(LinkMovementMethod.getInstance());

		//Create HashMap for payBox highlighting
		payBoxes =  new HashMap<String, Integer>();
		payBoxes.put("number", R.id.payinfo_number);
		payBoxes.put("expires_month",R.id.payinfo_expires);
		payBoxes.put("expires_year",R.id.payinfo_expires);
		payBoxes.put("cvv", R.id.payinfo_cvv);

		Bundle args = getArguments();
		if (args !=null){
			last4 = args.getString("last4");
//			Log.i("anisha","last4: "+last4);
			if (!TextUtils.isEmpty(last4)){
                changeCCInfo.setVisibility(View.VISIBLE);

                changeCCInfo.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
						payinfo_number_star.setVisibility(View.GONE);
						card_no.setVisibility(View.VISIBLE);
						card_no.setEnabled(true);
                        expir.setVisibility(View.VISIBLE);
                        expiryyear.setVisibility(View.VISIBLE);
                        cvv.setVisibility(View.VISIBLE);
                        card_no.setText("");
						scancard.setVisibility(View.VISIBLE);
						scan.setVisibility(View.VISIBLE);
						changeCCInfo.setVisibility(View.INVISIBLE);
						submitBtn.setVisibility(View.VISIBLE);


                        return false;
                    }
                });

				expir.setVisibility(View.INVISIBLE);
				expiryyear.setVisibility(View.INVISIBLE);
				cvv.setVisibility(View.INVISIBLE);
				card_no.setVisibility(View.GONE);
				payinfo_number_star.setVisibility(View.VISIBLE);
				payinfo_number_star.setText("**** **** **** "+last4);
				payinfo_number_star.setEnabled(false);
				scancard.setVisibility(View.INVISIBLE);
				submitBtn.setVisibility(View.INVISIBLE);
				scan.setVisibility(View.INVISIBLE);
				payment_msg.setVisibility(View.INVISIBLE);
				payment_msg_login.setVisibility(View.VISIBLE);

			}else{
				changeCCInfo.setVisibility(View.INVISIBLE);
				payment_msg.setVisibility(View.VISIBLE);
				payment_msg_login.setVisibility(View.INVISIBLE);
			}
		}
	}

	private void setDefaultColor(EditText editText) {
		editText.setTextColor(Appearance.TEXT_COLOR_EDIT_TEXT);
	}
	private void switchToNext() {

		getFragmentManager().popBackStack();

		MyAccount f = new MyAccount();
		Bundle args = new Bundle();
		args.putString("title", "MyAccount");
		f.setArguments(args);
		((ActivityInTab) getActivity()).navigateTo(f);
	}

	void showDialog() {

		FragmentTransaction ft = getFragmentManager().beginTransaction();
		Fragment prev = getFragmentManager().findFragmentByTag("dialog");
		if (prev != null) {
			ft.remove(prev);
		}
		ft.addToBackStack(null);

		// Create and show the dialog.
		DialogFragment newFragment = newDateInstance();
		newFragment.show(ft, "dialog");
	}

	private MyDatePicker newDateInstance() {
		MyDatePicker f = new MyDatePicker();

		return f;
	}

	private class SpinnerClickListener implements OnItemSelectedListener {
		@Override
	    public void onItemSelected(AdapterView<?> adapter, View view,
	            int pos, long id) {
				adapter.getItemAtPosition(pos);
	    }
		@Override
	    public void onNothingSelected(AdapterView<?> parent) {
	    }
	}

	public String toastIfEmpty(TextView T)
	{
		String s = T.getText().toString();
		if (s.isEmpty()){
			Toast.makeText(getActivity(),
					"Please provide valid card details.",
					Toast.LENGTH_SHORT).show();
			makeAllViewsEnabled();

			T.setTextColor(Color.RED);
//			T.setBackgroundResource(R.drawable.paymentinfotextbox_error);
			mPayForm.fullScroll(ScrollView.FOCUS_UP);
			T.requestFocus();
			fieldFlag = false;
		}
		else{
			T.setTextColor(Color.BLACK);
//			T.setBackgroundResource(R.drawable.paymentinfotextbox);
		}
		return s;
	}

	public String toastIfEmptyCCNumber(TextView T)
	{

		String s = T.getText().toString();

		if (s.isEmpty()){
			Toast.makeText(getActivity(),
					"Please provide valid card details.",
					Toast.LENGTH_SHORT).show();
			T.setTextColor(Color.RED);

			makeAllViewsEnabled();

//			T.setBackgroundResource(R.drawable.paymentinfotextbox_error);
			mPayForm.fullScroll(ScrollView.FOCUS_UP);
			fieldFlag = false;
		}
		else{
			T.setTextColor(Color.BLACK);
//			T.setBackgroundResource(R.drawable.paymentinfotextbox);
			s = s.replace(" ","");
		}

		return s;
	}

	@Override
	public void onActivityCreated(Bundle arg0) {
		super.onActivityCreated(arg0);

		Config.ViewDismiss();

		TextView titleTxt = (TextView) view.findViewById(R.id.top_title_txt);

		init();

		Bundle args = getArguments();
		titleTxt.setText(args.get("title").toString());

		mCheck = (ImageButton) view.findViewById(R.id.payinfo_check);
		mCheck.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (chkFlag) {
					mCheck.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.uncheckbox));
					chkFlag = false;
				} else {
					mCheck.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.checkedbox));
					chkFlag = true;
				}
			}
		});

		 submitBtn = (Button) view
				.findViewById(R.id.payinfo_submit);
		submitBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				try{

					expir.setEnabled(false);
					card_no.setEnabled(false);
					expiryyear.setEnabled(false);
					cvv.setEnabled(false);

					mMonth = expir.getText().toString();
					if ((!TextUtils.isEmpty(mMonth)) && mMonth.length() == 2 && mMonth.charAt(0)=='0'){
						mMonth = mMonth.substring(1);
					}

					mYear = expiryyear.getText().toString();
					if ((!TextUtils.isEmpty(mYear)) && mYear.length() == 2){
						mYear = "20"+mYear;
					}

//					if (TextUtils.isEmpty(last4)){
						int year = Calendar.getInstance().get(Calendar.YEAR);
						int month = Calendar.getInstance().get(Calendar.MONTH) + 1;

						int mYearUser = Integer.parseInt(mYear);
						int mMonthUser = Integer.parseInt(mMonth);
//						Log.i("anisha" ,"Month" + mMonthUser +""+ month + "Year" + mYearUser + ""+year);
//					if(mYearUser < year && mMonthUser < month){
//						Toast.makeText(getActivity(), "enter a Expire Info", Toast.LENGTH_SHORT).show();
//						return;
//					}

						if((mYearUser < year) || (mYearUser == year && mMonthUser < month)){
							Toast.makeText(getActivity(), "Please provide a valid card expiry info.", Toast.LENGTH_SHORT).show();
							makeAllViewsEnabled();
							return;
						}
//					}

					fieldFlag = true;
					resetColor();
					Braintree braintree = new Braintree(braintreeKey);
					encryptedCreditCardNumber = braintree.encrypt(toastIfEmptyCCNumber(card_no));
					encryptedCvv = braintree.encrypt(toastIfEmpty(cvv));
					encryptedExpiryMonth = braintree.encrypt(mMonth);
					encryptedExpiryYear = braintree.encrypt(mYear);

					mEntity = "{\"creditcard\":{\"number\":" + "\"" + encryptedCreditCardNumber
							+ "\"" + ",\"expires_year\":" + "\"" + encryptedExpiryYear
							+ "\"" + ",\"expires_month\":" + "\""
							+ encryptedExpiryMonth + "\"" + ",\"cvv\":" + "\""
							+ encryptedCvv + "\"}}";


				}catch(Exception e){
					Toast.makeText(getActivity(),
							"Please provide valid card details.",
							Toast.LENGTH_SHORT).show();

					makeAllViewsEnabled();

					String cvvEntered = cvv.getText().toString();
					if(TextUtils.isEmpty(cvvEntered)){
						cvv.requestFocus();
					}

					String expiryyearEntered = expiryyear.getText().toString();
					if (TextUtils.isEmpty(expiryyearEntered)){
						expiryyear.requestFocus();
					}

					String expirEntered = expir.getText().toString();
					if (TextUtils.isEmpty(expirEntered)){
						expir.requestFocus();
					}

					String card_noEntered = card_no.getText().toString();
					if (TextUtils.isEmpty(card_noEntered)){
						card_no.requestFocus();
					}

					fieldFlag = false;
				}


				if (fieldFlag){
					if(chkFlag){
						new ParseData().execute();
					}else{
						Toast.makeText(getActivity(),
								"Please agree with terms & conditions",
								Toast.LENGTH_SHORT).show();
					}
				}
			}
		});

	}

	private void makeAllViewsEnabled(){

		cvv.setEnabled(true);
		expir.setEnabled(true);
		card_no.setEnabled(true);
		expiryyear.setEnabled(true);
	}

	public class ParseData extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			Config.ViewShow();
			String url = Config.BASE_URL + "users/" + Config.username
					+ "/payment_info" + "?key="+Config.KEY;

		}

		@Override
		protected Void doInBackground(Void... params) {

			Log.v("ENTITY", "" + mEntity);

			String url = Config.BASE_URL + "users/" + Config.username
					+ "/payment_info" + "?key="+Config.KEY;

			try {

				String parameter = Config.username + ":" + Config.pwd;

				Log.v("parameter", "" + parameter);
				Log.v("url", "" + url);

				HttpPut httput = new HttpPut(url);

				httput.setHeader(
						"Authorization",
						"Basic "
								+ Base64.encodeToString(parameter.getBytes(),
										Base64.NO_WRAP));
				httput.setEntity(new StringEntity(mEntity));
				// httput.setHeader("Content-Type", "application/json");

				Log.v("ENTITY", "" + mEntity);

				HttpResponse httpResponse = null;

				httpResponse = Config.client.execute(httput);

				mResponse_code = httpResponse.getStatusLine().getStatusCode();

		

				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					InputStream input = null;
					input = entity.getContent();
					mResponse = convertStreamToString(input);

					input.close();

					if (mResponse != null){

		

						JSONObject json = new JSONObject(mResponse);

						Iterator keys = json.keys();

						while (keys.hasNext()) {
							// loop to get the dynamic key
							currentKey = (String) keys.next();

							// get the value of the dynamic key
							currentValue = json.getString(currentKey);

							Log.v("dynamic key", currentKey + "****"
									+ currentValue);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(Void... values) {
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			Config.ViewDismiss();
	

			JSONObject json, cc_json;
			String cc_err;
			if (mResponse_code != 200) {
//				errorTxt.setText(mResponse);
				errorTxt.setVisibility(View.GONE);
				errorBox.setVisibility(View.GONE);
				expir.setEnabled(true);
				card_no.setEnabled(true);
				expiryyear.setEnabled(true);
				cvv.setEnabled(true);


				try{

					expir.setEnabled(true);
					card_no.setEnabled(true);
					expiryyear.setEnabled(true);
					cvv.setEnabled(true);


//					errorBox.setVisibility(View.VISIBLE);
					json	= new JSONObject(mResponse);
//					Log.i("anisha", "mResponse1" +mResponse);
//					errorTxt.setText("");
					errorTxt.setVisibility(View.GONE);
					errorBox.setVisibility(View.GONE);
					if( currentKey.equals("error")){
						errorTxt.setText(currentValue.replaceAll("",""));
						errorTxt.setVisibility(View.GONE);
						errorBox.setVisibility(View.GONE);
						Toast.makeText(getActivity(), ""+currentValue.replaceAll("",""), Toast.LENGTH_SHORT).show();
					}

					if( json.has("creditcard")){
						cc_err	= json.getString("creditcard");
						cc_json	= new JSONObject(cc_err);
						Iterator keys = cc_json.keys();
						while(keys.hasNext()){
							String curr_key = keys.next().toString();
							errorTxt.append("\n"+cc_json.getString(curr_key));
							errorTxt.setVisibility(View.GONE);
							errorBox.setVisibility(View.GONE);

							Toast.makeText(getActivity(), cc_json.getString(curr_key), Toast.LENGTH_SHORT).show();
							setColor(curr_key,"red");


						}
					}
				} catch (JSONException e) {
						e.printStackTrace();
					
						Toast.makeText(getActivity(), getString(R.string.server_error), Toast.LENGTH_SHORT).show();
				}

				mPayForm.post(new Runnable() {
					@Override
					public void run() {
						mPayForm.fullScroll(ScrollView.FOCUS_UP);
					}
				});

			} else {

				errorBox.setVisibility(View.GONE);
				Toast.makeText(getActivity(), R.string.cc_info_updated, Toast.LENGTH_SHORT)
						.show();
				switchToNext();
			}
		}
	}

	private static String convertStreamToString(InputStream is) {
//		Log.i("Inside convertstream method", "hello");
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	public static class MyDatePicker extends DialogFragment implements
			OnDateSetListener {
		/** find a member field by given name and hide it */
		private void findAndHideField(DatePicker dp, String name) {
		    try {
		        Field field = DatePicker.class.getDeclaredField(name);
		        field.setAccessible(true);
		        View fieldInstance = (View) field.get(dp);
		        fieldInstance.setVisibility(View.GONE);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}

		@Override
		public Dialog onCreateDialog(final Bundle savedInstanceState) {
			// Use the current date as the default date in the picker
			final Calendar c = Calendar.getInstance();
			final int year = c.get(Calendar.YEAR);
			final int month = c.get(Calendar.MONTH);
			final int day = c.get(Calendar.DAY_OF_MONTH);
			int sdkVersion = Build.VERSION.SDK_INT;

			// if Day field name changes in later API, add name below.
			DatePickerDialog dpd	= new DatePickerDialog(getActivity(), (OnDateSetListener) this, year, month, day);
			try {
				if(sdkVersion >=11){
					DatePicker dp	= dpd.getDatePicker();
					//Honeycomb(+) fields:
					findAndHideField(dp, "mDaySpinner");
					findAndHideField(dp, "mDayPicker");
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			return dpd;
		}

		@Override
		public void onDateSet(DatePicker view, int year, int month, int day) {

			mMonth = "" + month;
			mYear = "" + year;
			expir.setText(getMonth(month) + ", " + mYear);


		}

		public String getMonth(int month) {
			return new DateFormatSymbols().getMonths()[month];
		}
	}
	}

